@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  where py >nul 2>nul
  if errorlevel 1 (
    echo Python 3.12 topilmadi. https://www.python.org/downloads/windows/
    pause
    exit /b 1
  )
  py -3.12 -m venv .venv
  if errorlevel 1 (
    echo Python 3.12 talab qilinadi.
    pause
    exit /b 1
  )
)
".venv\Scripts\python.exe" -c "import fastapi,uvicorn,docx,fitz,PIL,webview" >nul 2>nul
if errorlevel 1 (
    echo Birinchi ishga tushirish: kerakli kutubxonalar o'rnatilmoqda...
    ".venv\Scripts\python.exe" -m pip install -r requirements.txt
    if errorlevel 1 (echo Kutubxonalarni o'rnatib bo'lmadi.& pause& exit /b 1)
)
".venv\Scripts\python.exe" desktop_webview.py
if errorlevel 1 (
 echo Dastur ishga tushmadi. Log: %%LOCALAPPDATA%%\CyberPark\DocumentInspector\desktop-startup.log
 pause
 exit /b 1
)
