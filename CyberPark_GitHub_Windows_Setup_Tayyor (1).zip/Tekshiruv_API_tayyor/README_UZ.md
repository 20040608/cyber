# Cyber Park Document Inspector v6.4 — 3× / 6× / 9× stress sinovdan o‘tgan versiya

**Asosiy vazifa:** bitta kompaniyaning ZIP hujjatlarini dastlabki texnik va qoidaviy tekshiruvdan o'tkazish; dalil bilan aniqlangan kamchiliklarni kompaniya nomi va tekshiruv sanasi bilan Word xulosaga chiqarish.

Bu dastur **rezidentlikni tasdiqlamaydi**, xodimning huquqiy va iqtisodiy ekspertizasini to'liq almashtirmaydi. Tekshiruv 100% bo'lishi barcha hujjatlar to'liq mos degani emas.

## Windows 10/11 ishga tushirish

1. ZIPni alohida papkaga **to'liq arxivdan chiqaring**.
2. Python **3.11/3.12 x64** o'rnatilgan bo'lsin.
3. `START_WINDOWS.bat` — lokal, tashqi API o'chiq. Birinchi ishga tushirishda Python paketlarini yuklash uchun internet talab qilinishi mumkin.
4. `API_ULASH_WINDOWS.bat` — ixtiyoriy **CCVibe**; faqat kalitni kiritasiz. Bazaviy manzil `https://cc-vibe.com`, Anthropic Messages protokoli, oldindan ko'rsatilgan model `claude-sonnet-4-6`. Model APIda ishlashi provayder va kalitingizga bog'liq.
5. `START_WITH_LOCAL_AI_WINDOWS.bat` — ixtiyoriy lokal Ollama modeli allaqachon o'rnatilgan bo'lsa.
6. `QA_TESTLAR_WINDOWS.bat` — kompyuteringizda sinovlar. Ilk marta `pytest` kutubxonasini o'rnatishi mumkin.

Brauzer manzili: `http://127.0.0.1:8765`. Boshqa Cyber Park nusxasi ishlayotgan bo'lsa, uni yoping.

## O'zgartirilmagan foydalanuvchi talablari

- **Faqat 2 sahifa:** Tekshirish va Natijalar tarixi. Qoidalar va Sozlamalar sahifalari yo'q.
- **Faqat 3 natija:** jami fayl, qoidaviy tekshiruvdan o'tgan, aniqlangan kamchilik.
- **Faqat Word yuklash:** `Kompaniya_YYYY-MM-DD.docx`. PDF, Excel, CSV va asl faylni qayta yuklash yo'q.
- ZIP papkasi va fayl nomi o'zgarishi mumkin; mazmun va papka dalillari uyg'un ishlatiladi.
- Hujjatlarning asosiy tili o'zbek lotin, o'zbek kirill yoki rus bo'lsa, Word shu tilda yoziladi.
- Hisobotda **aniq xato → dalil → manba → tuzatish** beriladi. Ishonchsiz AI taklifi rasmiy e'tirozga kirmaydi.

## Maxfiylik

ZIPning asl baytlari va o'qilgan hujjat matnlari diskda alohida ko'chirma sifatida saqlanmaydi. Endi hujjat matnlari **doimiy xotira keshida ham saqlanmaydi**. Tekshiruv metama'lumotlari va dalillari lokal shifrlangan tarixda saqlanadi; u ham maxfiy hisoblanadi. Xodim Windows akkaunti va diskini himoya qilishi zarur.

**CCVibe sukut bo'yicha o'chiq.** API ulansa, faqat alohida rozilikdan o'tgan, maxfiy identifikatorlardan filtrlangan **biznes-reja parchalari** yuborilishi mumkin. Asl ZIP, boshqa hujjatlar, STIR, pasport va bank rekvizitlari jo'natilmaydi. Shu bilan birga anonimlashtirish barcha noyob tijoriy ma'lumotlarni avtomatik yashirishni mutlaq kafolatlamaydi. Ishlatishdan oldin tashqi provayderning ma'lumot saqlash siyosatini tekshiring.

## Cheklovlar

- O'qilmaydigan yoki ochib bo'lmaydigan fayl **to'g'ri deb sanalmaydi**. To'liq avtomatik ekspertiza yetishmasa, qoidaviy tekshiruvdan o'tgan fayllar soni 0 chiqishi ham mumkin.
- Moliyaviy modul faqat ishonchli ajratilgan jadvaldagi arifmetik tengliklarni tekshiradi; investitsiya prognozining real asoslanganligini emas.
- Katta skanlarda Tesseract va kerakli tillar (`uzb`, `uzb_cyrl`, `rus`, `eng`) mavjud bo'lishi kerak; OCR vaqti cheklangan.
- Jonli davlat reyestri tekshiruvi, barcha biznes-reja bandlarining ekspert xulosasi, haqiqiy CCVibe kaliti va Windows kompyuteringizda ishlashi bu muhitda tasdiqlanmagan.
- **90% / 98% aniqlik tasdiqlanmagan.** Mutaxassis tuzgan etalon e'tirozlar bilan precision/recall o'lchanmaguncha bunday foiz aytilmaydi.

## Testlar

`tests/test_quality.py` va `tests/test_v62_hardened.py` — ZIP yo'llari va xavfsizligi, maxfiylik, API ruxsati, arifmetik sonlar, Word, faqat ikki sahifa, hisobot nomi, noaniq faylni yashil deb belgilamaslik va integratsion tekshiruvlar. Asl korxona ZIP fayllari sinov paketiga **kiritilmagan**.

Qo'shimcha ma'lumot uchun `QA_V6_1_UZ.md`ni o'qing.


## v6.2 da yangilangan funksiyalar

- DOCX matni, sarlavhalari va jadvallari asl **ketma-ketligida** o‘qiladi. Oldingi parser barcha paragraflarni jadvaldan oldin yig‘gani uchun biznes-reja bo‘limlari noto‘g‘ri bog‘lanishi mumkin edi.
- Boshqa maqsadga tegishli «договор поставки», «договор аренды», «приказ об увольнении директора», «заявление на отпуск» majburiy xizmat shartnomasi, tayinlash buyrug‘i yoki rezidentlik arizasi deb sanalmaydi. Hujjatning ichki mazmuni ustun.
- CCVibe tokeni brauzer, lokal OCR va LibreOffice yordamchi jarayonlariga meros qilib berilmaydi. Server jarayonida u faqat ruxsat etilgan API chaqiruvi uchun mavjud.
- 0 baytli fayl interfeysda noto‘g‘ri «1 KB» deb emas, «0 bayt» deb ko‘rsatiladi.
- 168 ta yangi va regressiya avtomatik testi; 4 ta haqiqiy ZIPni **OCR o‘chiq** holda qayta o‘qish; Word xulosa tekshiruvlari.

## Ehtiyot chorasi

Dastur qoidaviy aniqlikni yaxshilaydi, lekin tasdiqlanmagan bandlar «o‘tdi» bo‘lmaydi. CCVibe haqiqiy modeli va Windows kompyuteringiz bu muhitda jonli tekshirilmagan. Real xodimlar tomonidan baholangan hujjatlar to‘plamisiz **98% aniqlikni da’vo qilish mumkin emas**.

## v6.3: iqtisodiy ekspertiza va LENO xulosasi

v6.3 versiyada `inspector/expert_dossier.py` qo‘shildi. U biznes-rejani faqat fayl nomi/sarlavhasi orqali emas, aniq iqtisodiy bayonotlar va ilovalar bor-yo‘qligi orqali tekshiradi. Kadr resurslari, marketing KPIlari, SaaS bosqichi, raqobatchilar, savdo tariflari, eksport, kelajakdagi soliqlar, amortizatsiya va ijara bo‘yicha manbaga bog‘langan to‘ldirish so‘rovlari ishlab chiqildi.

LENO ZIPidagi 11 ta xodim e’tiroz yo‘nalishi dasturda qayta aniqlangan; boshqa korxonalar uchun ushbu natijani avtomatik 98% sifat ko‘rsatkichi deb bo‘lmaydi. Vaqtga bog‘liq soliq/huquqiy talablar har doim amaldagi qonunchilik asosida tekshirilishi kerak.

Tegishli sinovlar: `tests/test_expert_dossier.py`. Natijalar va chegaralar: `QA_V6_3_LENO_BENCHMARK_UZ.md`.


## v6.4: 3× / 6× / 9× QA darajalari

Ushbu nomlar oldingi sinovlarga nisbatan **murakkablik toifalari**, 3, 6 yoki 9 baravar statistik aniqlik kafolati emas.

- **3×:** aralash nom, papka, DOCX jadval tartibi, noto‘g‘ri moliyaviy sonlar, uzun matn
- **6×:** kadr–loyiha mutanosibligi, iqtisodiy da’volar, ikki xil moliyaviy qator, to‘liq bo‘lmagan hujjatlar, mazmun/fayl nomi ziddiyati
- **9×:** ZIP yo‘li, siqish bombasi, CRC buzilishi, Unicode nom kolliziyasi, parallel yuklash, soxta CCVibe dalili, API roziligi va korxonalar tarixini noto‘g‘ri bog‘lash

Dastur buzilgan ZIP a’zosini mahalliy kamchilik sifatida qayd etadi va boshqa sog‘lom fayllarni tekshirishni davom ettiradi. Ikki korxonaning bir xil namunaviy fayli tekshiruv tarixlarini birlashtirish uchun yetarli asos emas.

**Diqqat:** 253/253 texnik/regressiya testi ekspert aniqligini o‘lchamaydi. OCR sifati, jonli CCVibe, davlat reyestri va xodim tomonidan belgilangan yangi etalon kamchiliklar bo‘yicha qo‘shimcha qabul sinovi zarur.
