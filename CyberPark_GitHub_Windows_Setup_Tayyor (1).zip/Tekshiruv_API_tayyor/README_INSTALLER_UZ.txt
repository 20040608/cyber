WINDOWS O'RNATISH PAKETINI YARATISH

1. Arxivni Windows 10/11 x64 kompyuterda oching.
2. Python 3.11 yoki 3.12 (64-bit) o'rnating va PATH/py launcher yoqilgan bo'lsin.
3. Inno Setup 6 ni rasmiy saytdan o'rnating: https://jrsoftware.org/isdl.php
4. BUILD_INSTALLER_WINDOWS.bat ni ishga tushiring (internet kerak).
5. Yaratilgan installer\CyberPark_Tekshiruv_Setup.exe ni ikki marta bosib o'rnating.
6. Keyingi ishga tushirishlarda Python talab etilmaydi.

MUHIM: API KALITINI_SHU_YERGA_YOZING.txt fayliga haqiqiy kalitni
setup yaratish papkasida ham kiritmang. Dastur ichida
"API ulanishi" bo'limida boshqa, shaxsiy TXT faylni tanlang.

O'rnatkich API kalitini o'z ichiga olmaydi; lokal tarixni o'chirmaydi.
BUILD_WINDOWS_EXE.bat va Inno Setup amallari Windowsda bajarilishi lozim.
Bu paket Linux muhitida tayyorlangan; Windows exe/setup ishga tushishi
shu muhitda sinov qilinmagan. API jonli ulanishi ham tekshirilmagan.
