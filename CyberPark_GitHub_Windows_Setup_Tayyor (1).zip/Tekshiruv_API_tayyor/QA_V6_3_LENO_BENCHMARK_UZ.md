# Cyber Park Document Inspector v6.3 — LENO iqtisodiy audit mezonlari

**Sana:** 18.11.2026  
**Maqsad:** kod haqiqiy iqtisodchi topgan kamchiliklarni dastur o‘zi aniqlashi, dalil va tuzatish bilan Word xulosaga chiqarishi.

## Qanday tekshirildi

- Manba: foydalanuvchi yuborgan `LENO.zip` (13 ta fayl) va iqtisodchi tomonidan yozilgan `Замечания  ООО LENO - 16.11.docx` (11 ta mazmuniy e’tiroz).
- Avvalgi v6.2 asosiy texnik tekshiruvda **0/11** e’tirozni mazmuniy kamchilik sifatida chiqargan; ko‘proq umumiy ichki signallar qaytargan.
- v6.3ning yangi `inspector/expert_dossier.py` moduli xodim e’tirozining **11/11 yo‘nalishini LENO hujjatlaridagi faktlar asosida** avtomatik topdi. Har bir band manba biznes-reja bo‘limi va aniq tuzatish tavsiyasi bilan qaytarildi.
- Bu **bitta korxona uchun etalon qamrov**. Har xil korxonalar bo‘yicha 98% aniqlik, mustaqil huquqiy ekspertiza yoki barcha iqtisodiy xatolarni topish ko‘rsatkichi emas.

## 11 yo‘nalish bo‘yicha mantiqiy tekshiruvlar

1. Joriy 9 oylik buxgalteriya balansi va moliyaviy natijalar ilovasi.
2. Joriy IT xodimlari soni va ilgari bajarilgan loyihalar / mijozlar ko‘lamining resurs izohi.
3. Marketingda kanallar bilan birga raqamli mijoz jalb qilish rejasi.
4. SaaS mahsulotlarining mavjud/prototip/kelajakdagi bosqichlari.
5. Nomi ma’lum raqobatchilar va dalilli solishtirish.
6. Litsenziya va texnika savdosi, hajm, tarif va IT faoliyati bilan bog‘liqlik.
7. Eksport loyihalari, xorijiy hamkor va buyurtma dalillari.
8. Kelajakdagi soliq imtiyozini qo‘llash uchun huquqiy asos yoki muqobil ssenariy.
9. Asosiy vosita va NMA bo‘yicha amortizatsiyaning aktivlar kesimidagi hisoblari.
10. Amortizatsiya o‘zgarsa xarajat, moliyaviy natija, pul oqimi va balansning moslashtirilishi.
11. Ijara xarajati uchun ijara shartnomasi.

Bu tekshiruvlar **matnda muayyan shartlar mavjud bo‘lgandagina ishlaydi**. Ular «qonun buzilgan» hukmi emas, qo‘shimcha dalil yoki hisob talab qilinadigan aniq holatlar. Soliq stavkasi va imtiyoz muddatlari amaldagi qonunchilik hamda kompaniyaning maqomiga ko‘ra alohida tasdiqlanishi kerak; dastur ularni o‘zicha qat’iy huquqiy fakt deb olmaydi.

## Ishlash va qayta sinov

- 181 ta sintetik unit/regressiya va ish jarayoni testi o‘tdi.
- LENO uchun lokal API sinovida ZIP → tekshiruv → tarix → Word yaratish ishladi, Wordda 11 ta dalilli band mavjud.
- Word ikki sahifaga sig‘di va sahifalar vizual ko‘rikdan o‘tkazildi.
- MILLIY POCHTA TO‘LOVLARI, MAXSUS ALOQA TAMIRLASH, CLOUDNOVA TECH va NexaGrid namunalari yangi ekspert moduli bilan qayta sinovdan o‘tkazildi; ularga mazkur modul tomonidan yangi asossiz e’tirozlar kiritilmadi. Bu ularning barcha hujjatlari qonuniy/to‘g‘ri degani emas.
- Ishga tushirish fayllari Windows foydalanuvchisining haqiqiy kompyuterida hali sinovdan o‘tkazilmadi.
- CCVibe modeli bilan jonli API testi bajarilmadi: haqiqiy token mavjud emas va maxfiy kompaniya hujjatlari tashqi servisga yuborilmagan.

## Saqlangan talablar

- Faqat **Tekshirish** va **Natijalar tarixi** sahifalari; Qoidalar/Sozlamalar yo‘q.
- Natijada faqat jami fayl, avtomatik tekshiruvdan o‘tgan fayl, dalilli kamchiliklar soni.
- Faqat Word xulosa yuklash; hisobot tekshirilgan korxona nomi va tekshiruv sanasi bilan nomlanadi.
- Worddagi muammolar manbaga bog‘liq, tuzatish ko‘rsatmasi aniq; taxminiy OCR cheklovi korxonaga ayb qilib yuborilmaydi.
- Asl ZIP hamda shaxsiy va bank ma’lumotlari CCVibe’ga yuborilmaydi; opt-in rejimida faqat cheklangan anonimlashtirilgan biznes-reja matni uzatilishi mumkin. Anonimlashtirish mutlaq maxfiylik kafolati emas.

## Qolgan cheklovlar / rasmiy foydalanish mezoni

**Hali to‘liq yopilmagan:** barcha shakllardagi erkin matn va skanlarni sifatli ajratish; hujjatlararo to‘liq ekspert audit; davrga mos huquqiy va soliq tekshiruvi; haqiqiy CCVibe ulanishi; Windows E2E; mustaqil baholangan ko‘p korxonali `precision/recall` sinovi.

Hozirgi holat dastlabki tekshiruvning dalillangan iqtisodiy qamrovini yaxshilaydi, lekin xodimning yakuniy ekspertizasini to‘liq almashtirishi tasdiqlanmagan.
