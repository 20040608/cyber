$ErrorActionPreference = 'Stop'
$exe = Join-Path $PSScriptRoot '..\dist\CyberPark_Tekshiruv\CyberPark_Tekshiruv.exe'
$setup = Join-Path $PSScriptRoot '..\installer\CyberPark_Tekshiruv_Setup.exe'
if (!(Test-Path $exe)) { throw "EXE topilmadi: $exe" }
Write-Host '1/3: Bundled EXE backend + original frontend smoke-test'
$p = Start-Process -FilePath $exe -ArgumentList '--smoke-test' -Wait -PassThru
if ($p.ExitCode -ne 0) {
  $log = Join-Path $env:LOCALAPPDATA 'CyberPark\DocumentInspector\desktop-startup.log'
  if (Test-Path $log) { Get-Content $log -Tail 60 }
  throw "Bundled EXE smoke-test failed: $($p.ExitCode)"
}
if (!(Test-Path $setup)) { throw "Setup topilmadi: $setup" }
Write-Host '2/3: Silent installer test'
$dest = Join-Path $env:LOCALAPPDATA 'Programs\CyberParkTekshiruv'
$p = Start-Process -FilePath $setup -ArgumentList '/VERYSILENT','/SUPPRESSMSGBOXES','/NORESTART' -Wait -PassThru
if ($p.ExitCode -ne 0) { throw "Installer failed: $($p.ExitCode)" }
$installed = Join-Path $dest 'CyberPark_Tekshiruv.exe'
if (!(Test-Path $installed)) { throw "Installed EXE topilmadi: $installed" }
Write-Host '3/3: Installed application smoke-test'
$p = Start-Process -FilePath $installed -ArgumentList '--smoke-test' -Wait -PassThru
if ($p.ExitCode -ne 0) {
  $log = Join-Path $env:LOCALAPPDATA 'CyberPark\DocumentInspector\desktop-startup.log'
  if (Test-Path $log) { Get-Content $log -Tail 60 }
  throw "Installed EXE smoke-test failed: $($p.ExitCode)"
}
$hash = (Get-FileHash $setup -Algorithm SHA256).Hash
$hash | Set-Content (Join-Path $PSScriptRoot '..\installer\SHA256.txt')
Write-Host "SETUP_SHA256=$hash"
Write-Host 'PASS: packaged EXE, silent installation, installed backend/frontend startup'
