﻿# CCVibe is optional. All ZIPs, OCR, financial tables and source documents remain local.
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

try {
    $python = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
    # An already-running local server cannot receive the new environment variables.
    $tcp = New-Object System.Net.Sockets.TcpClient
    try {
        $async = $tcp.BeginConnect('127.0.0.1',8765,$null,$null)
        $connected = $async.AsyncWaitHandle.WaitOne(500)
        if ($connected) {
            try { $tcp.EndConnect($async) } catch { $connected = $false }
        }
        if ($connected) {
            throw '8765-port band. Eski Cyber Park dastur oynasi va START_WINDOWS konsolini yoping, keyin API_ULASH_WINDOWS.bat ni qayta oching.'
        }
    } finally { $tcp.Close() }

    # A fresh extracted ZIP has no venv. Bootstrap before asking for the API key.
    if (-not (Test-Path $python)) {
        Write-Host 'Python muhiti tayyorlanmoqda (birinchi marta)...'
        & py -3.12 -m venv '.venv'
        if (-not (Test-Path $python)) { & py -3.11 -m venv '.venv' }
        if (-not (Test-Path $python)) {
            throw 'Python 3.12 yoki 3.11 x64 topilmadi. Python o`rnating va qayta urinib ko`ring.'
        }
    }
    $depsMarker=Join-Path $PSScriptRoot '.venv\cp_deps_61.ok'
    if (-not (Test-Path $depsMarker)) {
        Write-Host 'Kutubxonalar birinchi marta o`rnatilmoqda...'
        & $python -m pip install -r 'requirements.txt' --disable-pip-version-check
        if ($LASTEXITCODE -ne 0) { throw 'Python kutubxonalari o`rnatilmadi. Internet va pip ni tekshiring.' }
        'installed' | Set-Content -Path $depsMarker -Encoding ASCII
    }

    # Approved fixed parameters. Only the token is entered by the operator.
    $env:ANTHROPIC_BASE_URL = 'https://cc-vibe.com'
    $env:CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC = '1'
    $env:ANTHROPIC_MODEL = 'claude-sonnet-4-6'
    $env:ANTHROPIC_API_KEY = ''
    Write-Host ''
    Write-Host 'CCVibe: https://cc-vibe.com | Model: claude-sonnet-4-6'
    Write-Host 'Kalit lokal TXT fayldan olinadi; bu faylni hech kimga yubormang.'
    Write-Host 'Sinov uchun hujjat yuborilmaydi; faqat umumiy OK so`rovi yuboriladi.'
    Write-Host 'Eslatma: sinov so`rovi provayderda kichik to`lovga sabab bo`lishi mumkin.'
    Write-Host 'Haqiqiy hujjatdan faqat filtrlangan biznes-reja parchalari uzatilishi mumkin.'
    Write-Host ''
    # The operator fills this file locally. Never put the actual secret in a shared ZIP.
    $keyPath = Join-Path $PSScriptRoot 'API_KALITINI_SHU_YERGA_YOZING.txt'
    if (-not (Test-Path -LiteralPath $keyPath -PathType Leaf)) {
        throw 'API kaliti fayli topilmadi: API_KALITINI_SHU_YERGA_YOZING.txt'
    }
    $token = ([System.IO.File]::ReadAllText($keyPath, [System.Text.Encoding]::UTF8)).Trim().Trim([char]0xFEFF)
    if ([string]::IsNullOrWhiteSpace($token) -or $token -eq 'KALITNI_SHU_YERGA_YOZING') {
        throw 'API kaliti hali kiritilmagan. TXT faylga faqat kalitni yozing.'
    }
    if ($token.Contains("`r") -or $token.Contains("`n")) {
        throw 'API kaliti bitta qatorda bo`lishi kerak.'
    }
    try {
        $env:ANTHROPIC_AUTH_TOKEN = $token
        $env:CYBERPARK_API_PROTOCOL = 'anthropic'
        $env:CYBERPARK_ALLOW_SANITIZED_CONTENT = '1'
        Write-Host 'CCVibe API xavfsiz sinovi boshlanmoqda...' -ForegroundColor Cyan
        $probeOutput = & $python -m inspector.ccvibe_probe 2>&1
        $probeExit = $LASTEXITCODE
        foreach ($line in $probeOutput) {
            if ($line -match '^AUTH_STYLE=([a-zA-Z-]+)$') {
                $env:CYBERPARK_CCVIBE_AUTH_STYLE = $Matches[1]
            } else { Write-Host $line }
        }
        if ($probeExit -ne 0) {
            Write-Host 'API sinovdan o`tmadi. Hech qanday hujjat CCVibe ga yuborilmaydi.' -ForegroundColor Yellow
            Write-Host 'Dastur lokal rejimda ishga tushadi. Kalitni/paneldagi modelni tekshirib qayta urinib ko`ring.'
            $env:CYBERPARK_ENABLE_REMOTE_AI = '0'
            $env:CYBERPARK_ALLOW_SANITIZED_CONTENT = '0'
            Remove-Item 'Env:ANTHROPIC_AUTH_TOKEN' -ErrorAction SilentlyContinue
        } else {
            Write-Host 'API ulanishi tasdiqlandi. Filtrlangan matn rejimi faol.' -ForegroundColor Green
            $env:CYBERPARK_ENABLE_REMOTE_AI = '1'
        }
        Write-Host 'Cyber Park lokal serveri ishga tushmoqda...'
        & $python 'run_local.py'
        if ($LASTEXITCODE -ne 0) { Write-Host 'Server xato bilan to`xtadi. Avvalgi konsol va 8765-portni tekshiring.' -ForegroundColor Yellow }
    } finally {
        $token = $null
        foreach ($var in @('ANTHROPIC_AUTH_TOKEN','ANTHROPIC_BASE_URL','ANTHROPIC_MODEL','ANTHROPIC_API_KEY',
          'CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC','CYBERPARK_API_PROTOCOL',
          'CYBERPARK_ENABLE_REMOTE_AI','CYBERPARK_ALLOW_SANITIZED_CONTENT','CYBERPARK_CCVIBE_AUTH_STYLE')) {
            Remove-Item ('Env:'+$var) -ErrorAction SilentlyContinue
        }
    }
} catch {
    # Never print raw exception objects that might contain an authentication header.
    $publicMessage = [string]$_.Exception.Message
    if ($publicMessage -match 'token|key=|authorization|bearer' -and $publicMessage -notmatch 'API kaliti kiritilmadi') {
        $publicMessage = 'Ulanishda texnik xato. Kalit yoki maxfiy qator konsolga yozilmadi.'
    }
    Write-Host ('XATO: '+$publicMessage) -ForegroundColor Red
} finally {
    Read-Host 'Konsolni yopish uchun Enter bosing'
}
