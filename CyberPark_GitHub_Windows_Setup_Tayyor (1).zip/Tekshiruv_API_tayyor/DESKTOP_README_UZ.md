# Cyber Park — Windows kompyuter ilovasi

## Ishga tushirish

1. ZIP arxivni kompyuterga chiqaring.
2. `START_DESKTOP_WINDOWS.bat` faylini bosing. Birinchi ishga tushirishda Python 3.11/3.12 va internet (kutubxonalarni o‘rnatish uchun) zarur. Keyin dastur alohida Windows oynasida ishlaydi, brauzer yoki server kerak emas.
3. ZIP tanlang va «Tekshirishni boshlash» tugmasini bosing.
4. Word xulosani «Xulosani Word formatida saqlash» tugmasi orqali oling.

## API kaliti — menga yuborilmaydi

Kalitni kompyuteringizda alohida TXT faylga **bitta qatorda** yozib saqlang. Ilovada «API ulanishi» bo‘limini ochib «Kalit TXT tanlash» tugmasi orqali faylni belgilang. **To‘ldirilgan kalit faylini hech qachon ZIP/ChatGPT/email bilan yubormang.** Tarqatma paketda haqiqiy kalit yo‘q; faqat `API_KALITINI_SHU_YERGA_YOZING.txt` uchun bo‘sh namunaviy fayl mavjud.

«API ni sinash» alohida rozilik so‘raydi va faqat minimal sinov xabarini CCVibe ga yuboradi. Sinov pullik bo‘lishi mumkin. So‘ng «Filtrlangan biznes-reja parchalarini API ga yuborishga ruxsat beraman» katagiga alohida rozilik talab qilinadi. Rozilik bo‘lmasa yoki API sinovi muvaffaqiyatsiz bo‘lsa, hujjatlar tashqariga yuborilmaydi.

**Cheklov:** anonimlashtirish mutlaq kafolat emas; haqiqiy kompaniya ma’lumotlarini tashqi provayderga uzatishdan oldin tashkilot ruxsatini oling. Model javoblari faqat tasdiqlanmagan tavsiya.

## Mustaqil EXE yaratish

Windows x64 kompyuterda `BUILD_WINDOWS_EXE.bat` ni ishga tushiring. Python 3.11/3.12 va internet talab etiladi. Muvaffaqiyatli tugagach `dist\CyberPark_Tekshiruv.exe` paydo bo‘ladi. Keyin ilova uchun alohida Python o‘rnatish talab etilmaydi. EXE shu muhitda Windows ustida yaratilmagan yoki sinovdan o‘tmagan — natijani Windowsda tekshiring.

## Natijalar va xavfsizlik

- Dastur bir oynada ZIP tanlash, tekshirish, progress, Word hisobot, oldingi tekshiruvlar va API sozlamalariga ega.
- Original ZIP o‘zgarmaydi; bir foydalanuvchining lokal hisoboti shifrlangan tarixda saqlanadi.
- Windowsda `LOCALAPPDATA\CyberPark\DocumentInspector` ichida lokal tarix saqlanadi.
- API token dastur ishlayotgan paytda faqat xotirada muhit o‘zgaruvchisi sifatida ishlatiladi; EXE ga kiritilmaydi. Kalitni tanlagan TXT faylingizni o‘zingiz xavfsiz joyda saqlang.
- 253 ta mavjud avtomatik test tekshirildi; Windows native EXE, real OCR va pullik API ning jonli sinovi bu muhitda bajarilmadi.

## Sinovlar

Asl loyihaning 253 testi va ish stoli uchun qo‘shimcha 4 test: 257/257 muvaffaqiyatli. Linux virtual oynasida tanlangan namunaviy ZIP tekshirilib, Word hisobot generatsiyasi sinovdan o‘tgan. Real Windows `.exe` yig‘ilishi faqat Windows tizimida `BUILD_WINDOWS_EXE.bat` orqali amalga oshiriladi.
