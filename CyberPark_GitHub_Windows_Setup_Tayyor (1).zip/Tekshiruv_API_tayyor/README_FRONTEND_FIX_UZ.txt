Yangilanish:
- Soddalashtirilgan Tkinter frontend olib tashlandi.
- Endi desktop ilova asl web frontendni ichki oynada (webview) ko‘rsatadi.
- Quyon iconka qo‘shildi: assets/rabbit_icon.ico
- Build skript EXE va Setup uchun yangi iconkani ishlatadi.
