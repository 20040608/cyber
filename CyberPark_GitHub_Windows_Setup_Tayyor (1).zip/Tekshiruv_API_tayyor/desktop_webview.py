"""Original Cyber Park HTML desktop window, backed by a verified private HTTP server."""
from __future__ import annotations
import json
import os
import secrets
import socket
import sys
import threading
import time
from pathlib import Path
from urllib.request import urlopen

HOST = '127.0.0.1'
INSTANCE = secrets.token_urlsafe(24)


def log_path():
    root = Path(os.environ.get('LOCALAPPDATA') or Path.home()) / 'CyberPark' / 'DocumentInspector'
    root.mkdir(parents=True, exist_ok=True)
    return root / 'desktop-startup.log'


def write_error(message, exc=None):
    import traceback
    with log_path().open('a', encoding='utf-8') as stream:
        stream.write(f'\n[{time.strftime("%Y-%m-%d %H:%M:%S")}] {message}\n')
        if exc:
            traceback.print_exception(type(exc), exc, exc.__traceback__, file=stream)


def alert(message):
    if os.name == 'nt':
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(None, message, 'Cyber Park — Xatolik', 0x10)
            return
        except Exception:
            pass
    print(message, file=sys.stderr)


def ready(url, instance=INSTANCE):
    try:
        with urlopen(url + '/api/status', timeout=1.5) as resp:
            result = json.load(resp)
            return resp.status == 200 and result.get('instance') == instance
    except (OSError, ValueError, TypeError):
        return False


def main():
    os.environ['CYBERPARK_ENABLE_REMOTE_AI'] = '0'
    os.environ['CYBERPARK_ALLOW_SANITIZED_CONTENT'] = '0'
    os.environ['CYBERPARK_RUNTIME_NONCE'] = INSTANCE
    server = None
    listener = None
    try:
        # Own the socket before starting the server; port conflicts cannot open an
        # unrelated service's web page. Port is dynamically selected per launch.
        listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        listener.bind((HOST, 0))
        listener.listen(128)
        port = listener.getsockname()[1]
        os.environ['CYBERPARK_HTTP_PORT'] = str(port)
        url = f'http://{HOST}:{port}'
        import uvicorn
        from app import app
        from inspector import api_settings
        api_settings.disconnect()  # each launch defaults to local-only
        server = uvicorn.Server(uvicorn.Config(app, host=HOST, port=port,
            log_level='warning', access_log=False, server_header=False, lifespan='on'))
        backend = threading.Thread(target=server.run, kwargs={'sockets': [listener]},
                                   name='CyberPark HTTP backend', daemon=True)
        backend.start()
        deadline = time.monotonic() + 30
        while time.monotonic() < deadline and backend.is_alive():
            if ready(url): break
            time.sleep(0.15)
        if not ready(url):
            raise RuntimeError('Backend HTTP tayyorlik tekshiruvidan o‘tmadi')
        if '--smoke-test' in sys.argv:
            # Runs the real packaged backend without a GUI; CI verifies embedded static files.
            for page, token in (('/', b'page-check'), ('/static/app.js', b'fetch'),
                                ('/static/style.css', b'{')):
                with urlopen(url + page, timeout=10) as response:
                    content = response.read()
                    if response.status != 200 or token not in content:
                        raise RuntimeError('Frontend smoke-test muvaffaqiyatsiz: ' + page)
            with urlopen(url + '/favicon.ico', timeout=10) as response:
                if response.status != 200 or response.read(4) != b'\x00\x00\x01\x00':
                    raise RuntimeError('Quyon ikonkasini yuklash muvaffaqiyatsiz')
            return 0
        import webview
        webview.create_window('Cyber Park — Hujjatlar tekshiruvi', url,
            width=1440, height=920, min_size=(1000, 660), text_select=True)
        webview.start(debug=False)
        return 0
    except Exception as exc:
        write_error('Desktop ishga tushmadi', exc)
        alert('Dastur oynasi ishga tushmadi. Jurnal: ' + str(log_path()))
        return 1
    finally:
        if server:
            server.should_exit = True
        if listener:
            try: listener.close()
            except OSError: pass


if __name__ == '__main__':
    raise SystemExit(main())
