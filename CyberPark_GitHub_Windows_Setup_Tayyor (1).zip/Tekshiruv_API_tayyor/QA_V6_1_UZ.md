# Cyber Park Inspector v6.1 — mustaqil kod, funksional va mantiqiy audit

**Sana:** 2026-11-18. **Asos:** aynan v6.0 manba ZIPi, 4 ta avval berilgan real korxona arxivi, ONEDESK e'tiroz namunasi va rasmiy talablar katalogi.

## Tekshirish natijasi

| Yo'nalish | Qayta sinov | Holati |
|---|---|---|
| Lokal Windows server kodi | Python modullari kompilyatsiyasi, lokal FastAPI yuklash | Linux sinovida o'tdi; Windows jonli ishga tushirish sinovi qilinmadi |
| Ikki sahifali frontend | CSS/HTML/JS haqiqiy Chromium'da sahifa almashish, xatolik konsoli | Statik ko'rinish va navigatsiya o'tdi; brauzer → localhost jonli navigatsiyasi sinov muhiti tomonidan bloklandi |
| ZIP xavfsizligi | Traversal, takroriy nomlar, buzilgan va bo'sh arxiv, yaroqsiz kengaytmalar | O'tdi |
| ZIP ichidagi umumiy fayl soni | Noma'lum formatdagi fayllar ham sanaladi | O'tdi |
| Hujjatni qayta ishlash | Real ZIPni offline OCR o'chiq rejimda ajratish | 4/4 ochildi |
| Xodim qarorisiz Word | ZIP → API → tarix → DOCX qaytarish | O'tdi |
| Kompaniya nomi/sana | Yuklama nomi va sanani to'g'ri shakllantirish | O'tdi |
| Moliyaviy son sintaksisi | Noto'g'ri 1,2,3 soni va noto'g'ri manfiy qavsni rad etish | O'tdi; bu nuqsonlar shu auditda aniqlandi |
| Maxfiylik | Begona Host/Origin, POST uchun lokal header, API sukut bo'yicha o'chiq, noto'g'ri CCVibe host/model | O'tdi (mock/sintetik); jonli provayder sinovidan o'tmagan |
| OCR | Sintetik rasmli PDFdagi matnni lokal Tesseract bilan ajratish | 1 sahifada o'tdi; ko'p sahifali real OCR kafolatlanmagan |
| Barcha ekspert kamchiliklarini topish | Mustaqil ekspertlarning etalon natijasi yo'q | **Tasdiqlanmagan** |

## Real korxona ZIPlari — OCR o'chirilgan sinov

| Arxiv | ZIPdagi fayl | Texnik jihatdan to'liq o'tgan deb tasdiqlangan | Aniqlangan qat'iy kamchilik | Ochiq/noaniq signallar |
|---|---:|---:|---:|---:|
| NexaGrid | 24 | 0 | 3 | 17 |
| MILLIY POCHTA TO'LOVLARI | 20 | 0 | 0 | 17 |
| MAXSUS ALOQA TAMIRLASH | 12 | 0 | 0 | 20 |
| CLOUDNOVA TECH | 17 | 0 | 0 | 17 |

**NexaGrid uchta aniq topilmasi:** 0 baytli ijtimoiy tarmoq fayli; anketa uchun ajratilgan bo'sh papka; 2172×724 bannerning 1192×226 talabga mos kelmasligi. Boshqa to'plamlar xatosizligi isbotlanmagan.

## Ixchamlashtirish

- Eski, ishlatilmaydigan PDF/CSV/XLSX eksport APIlari, asl faylni vaqtinchalik xotiradan qayta yuklab olish, eski qoida tahrirlash, xodim qarorlari, namunadan fayl nomini o'rgatish va registr CSVni qo'lda import qilish endpointlari olib tashlandi.
- Qayta ishlangan asl ZIPning RAMdagi nusxasini sessiyalar oralig'ida saqlovchi kesh olib tashlandi.
- Avvalgi qoidalardan faqat **o'qish** yo'li saqlandi; Qoidalar sahifasi yo'q. Maxsus qoida tahrirlash va eski registry-snapshot mexanizmlari o'chirildi.
- CCVibe protokoli bitta Anthropic Messages formatigacha soddalashtirildi; boshqa API shemalari olib tashlandi.
- Lokal tarix saqlanadi, Word hisobot kompaniya + tekshiruv sanasi bilan nomlanadi.

## Halol chegaralar

- Sinovlar kodi/texnik mantiqni qamrab oladi, ammo xodim tekshiruvini almashtirish yoki **98% aniqlik** uchun dalil emas.
- Dastur to'liq o'qiy olmagan hujjatlar “Tekshirildi” deb ko'rsatilmasligi uchun konservativ mezon qo'llaydi. Shu sabab oldingi versiyalarga nisbatan yashil hisob **kamayishi mumkin**.
- CCVibe kalitga mosligi, haqiqiy Windows GUI, 100 sahifalik OCR va jonli davlat reyestri **to'liq tekshirilmagan**.
- Rasmiy ishlashdan oldin haqiqiy xodimlar e'tirozlari bilan ko'r-ko'rona sinov va aniqlikni o'lchash zarur.
