@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Avval START_WINDOWS.bat bilan Python muhitini tayyorlang.
  pause
  exit /b 1
)
echo Lokal xavfsizlik, tekshiruv mantiqi va eksport testlari...
".venv\Scripts\python.exe" -m pip show pytest >nul 2>&1
if errorlevel 1 ".venv\Scripts\python.exe" -m pip install pytest --disable-pip-version-check
set PYTHONPATH=%CD%
".venv\Scripts\python.exe" -m pytest -q tests
if errorlevel 1 (echo Testlar orasida xatolar bor.) else (echo QA sinovlari muvaffaqiyatli.)
pause
