@echo off
setlocal
REM Ordinary/Local-AI startup must never contact an external AI provider.
set CYBERPARK_ENABLE_REMOTE_AI=0
set CYBERPARK_ALLOW_SANITIZED_CONTENT=0
cd /d "%~dp0"
rem Only an already-installed Ollama running on this PC is supported.
set CYBERPARK_ENABLE_LOCAL_AI=1
set CYBERPARK_LOCAL_MODEL=qwen3:4b
call START_OFFLINE_WINDOWS.bat
