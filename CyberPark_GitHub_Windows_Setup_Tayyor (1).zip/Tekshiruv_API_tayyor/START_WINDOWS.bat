@echo off
setlocal
REM Ordinary/Local-AI startup must never contact an external AI provider.
set CYBERPARK_ENABLE_REMOTE_AI=0
set CYBERPARK_ALLOW_SANITIZED_CONTENT=0
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo [1/3] Lokal Python muhiti yaratilmoqda...
 py -3.12 -m venv .venv
 if errorlevel 1 py -3.11 -m venv .venv
 if errorlevel 1 (echo Python 3.12 yoki 3.11 x64 kerak. & pause & exit /b 1)
)
if not exist ".venv\cp_deps_61.ok" (
 echo [2/3] Kutubxonalar birinchi marta o'rnatilmoqda. Faqat shu bosqichda internet kerak.
 ".venv\Scripts\python.exe" -m pip install -r requirements.txt --disable-pip-version-check
 if errorlevel 1 (echo Kutubxonalarni o'rnatish tugamadi. & pause & exit /b 1)
 echo installed > ".venv\cp_deps_61.ok"
) else (
 echo [2/3] Kutubxonalar tayyor. Internetga murojaat qilinmaydi.
)
echo [3/3] Lokal server ishga tushmoqda (API o'chiq)...
".venv\Scripts\python.exe" run_local.py
pause
