from pathlib import Path
from unittest.mock import patch
import pytest
import desktop

def test_no_remote_enabled_by_default(monkeypatch):
    monkeypatch.setenv('CYBERPARK_ENABLE_REMOTE_AI', '1')
    monkeypatch.setenv('CYBERPARK_ALLOW_SANITIZED_CONTENT', '1')
    desktop.disable_api()
    assert 'CYBERPARK_ENABLE_REMOTE_AI' not in __import__('os').environ
    assert 'CYBERPARK_ALLOW_SANITIZED_CONTENT' not in __import__('os').environ

def test_key_read_locally(tmp_path):
    f=tmp_path/'mytoken.txt'
    f.write_text('  ABCDE12345\n',encoding='utf-8')
    assert desktop.read_key_file(str(f))=='ABCDE12345'

def test_placeholders_rejected(tmp_path):
    f=tmp_path/'mytoken.txt'
    for value in ('', 'KALITNI_SHU_YERGA_YOZING', 'one\ntwo'):
        f.write_text(value,encoding='utf-8')
        with pytest.raises(ValueError):desktop.read_key_file(str(f))

def test_remote_requires_explicit_switch(monkeypatch):
    desktop.setup_api('local-test-token', False)
    assert __import__('os').environ['CYBERPARK_ENABLE_REMOTE_AI']=='0'
    assert __import__('os').environ['CYBERPARK_ALLOW_SANITIZED_CONTENT']=='0'
    desktop.disable_api()
