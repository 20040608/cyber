"""Current v6.1 contract, not legacy tests of removed exports/settings.

All real-company documents stay out of the distributed project.
"""
import os
import io
import re
import sys
import json
import stat
import zipfile
import tempfile
from pathlib import Path
from datetime import datetime
from collections import Counter
from urllib.parse import quote

# Isolate QA writes from the user's encrypted working history.
TEST_HOME = tempfile.mkdtemp(prefix='cyberpark_qa_')
os.environ['CYBERPARK_DATA_DIR'] = TEST_HOME
os.environ['CYBERPARK_ENABLE_REMOTE_AI'] = '0'
os.environ['CYBERPARK_ALLOW_SANITIZED_CONTENT'] = '0'

import pytest
from fastapi.testclient import TestClient
from docx import Document
from inspector.engine import safe_zip_members, UnsafeArchive, analyze_zip, DocFile
from inspector.download_naming import safe_company_name, report_filename
from inspector.finance_v4 import number, check as check_finance
from inspector.remote_reviewer import _config, review_content
from inspector.document_validation import assess_file
from app import app

client=TestClient(app)
AUTH={'X-Cyberpark-Local':'1'}

def zip_bytes(**files):
    buf=io.BytesIO()
    with zipfile.ZipFile(buf,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for name,content in files.items():z.writestr(name,content)
    return buf.getvalue()

# Every accepted or rejected archive path is a different hostile input.
@pytest.mark.parametrize('bad',[
    '../secret.txt','x/../../a.pdf','/absolute.pdf','C:/a.pdf','x:y.docx',
    'x/\x01a.pdf','a\\..\\secret.docx','../../init.bat','a/../b.txt',
    './../x.png', 'x/../../../../etc/passwd'])
def test_zip_path_rejected(bad):
    if '\x00' in bad:
        with pytest.raises(ValueError):zip_bytes(**{bad:'x'})
        return
    with pytest.raises(UnsafeArchive):
        z,_=safe_zip_members(zip_bytes(**{bad:'x'}));z.close()

@pytest.mark.parametrize('file', [
  'a.pdf','b.docx','v.tar','a.png','b.jpg','x.rtf','formula.xlsx','тест.txt',
  'nexa/grid/annual_report.pdf','nested/ANKETA.docx', 'foo/bar.pdf',
])
def test_safe_normal_zip(file):
    z,m=safe_zip_members(zip_bytes(**{file:b'A'}))
    with z:assert m[0].filename==file

def test_duplicate_file_rejected():
    b=io.BytesIO()
    with zipfile.ZipFile(b,'w') as z:
        z.writestr('ONE.pdf','first');z.writestr('one.PDF','second')
    with pytest.raises(UnsafeArchive):safe_zip_members(b.getvalue())

def test_empty_zip_rejected():
    b=io.BytesIO()
    with zipfile.ZipFile(b,'w'):pass
    with pytest.raises(UnsafeArchive):safe_zip_members(b.getvalue())

@pytest.mark.parametrize('raw', [b'',b'garbage',b'PK\x03\x04',bytes(100)])
def test_corrupt_zip_rejected(raw):
    with pytest.raises((UnsafeArchive,ValueError)):safe_zip_members(raw)

@pytest.mark.parametrize('original', [
    'AUX','CON','NUL','PRN','COM1','LPT1','../BAD','ACME:INC','bad*name',
    'a?b','bad|name','bad<name','bad>name','bad"name','bad\\name',
    '  My  Company  ','  ..  ','',' X'*70,'sana/2026',
])
def test_safe_report_company_name(original):
    got=safe_company_name(original)
    assert got and len(got)<=95
    assert not re.search(r'[<>:"/\\|?*\x00-\x1f]',got)
    assert not got.startswith(' ') and not got.endswith(' ')

@pytest.mark.parametrize('extension', ['exe','bat','pdfx','', 'DOCX','../zip','xlsx'])
def test_nonword_report_extension_rejected(extension):
    if extension=='xlsx':
        assert report_filename({'company_name':'AAA','created_at':'2026-11-18T02:00:00+00:00'},extension).endswith('.xlsx')
    else:
        with pytest.raises(ValueError):report_filename({'company_name':'AAA'},extension)

def test_history_date_is_inspection_date():
    assert report_filename({'company_name':'NexaGrid','created_at':'2026-11-17T20:30:00Z'},'docx')=='NexaGrid_2026-11-18.docx'

@pytest.mark.parametrize('number_string,expected',[
    ('1',1),('0',0),('1 000',1000),('1,5',1.5),('1.234,56',1234.56),
    ('1,234.56',1234.56),('(-5)',None),('(5)',-5),('−12',-12),('2.5',2.5),
    ('  24  ',24),('+1',1),('-1',-1),('1000',1000),('12.35',12.35),
])
def test_finance_number_valid(number_string,expected):
    assert number(number_string)==expected

@pytest.mark.parametrize('invalid', [
    '=1+2','+ 1','1+2','1-2','=SUM(A1:B1)','year 2026', '2025 год','12%',
    '100UZS', '5/6','123a','1,2,3', 'nan', 'inf', '5*3','{10}','1 USD','',
    '  -  ','1_000', '5:30', 'a1','0x10','+ 10','- 24'
])
def test_finance_number_not_evaluated(invalid):
    assert number(invalid) is None

def test_finance_detects_real_arithmetic_mismatch():
    f=DocFile('business_plan.docx','.docx',250,kind='business_plan',extraction='ok')
    f.tables=[[
        ['Выручка','10','20'],['Себестоимость реализованных услуг','5','10'],
        ['Валовая прибыль','100','10'],
    ]]
    issues=[];diagnostics=check_finance([f],issues)
    assert diagnostics and any(x['level']=='error' and x['id'].startswith('finance_v4_') for x in issues)

def test_false_empty_file_rejected():
    r=analyze_zip(zip_bytes(**{'empty.docx':b''}), 'Test.zip',ocr_mode='off')
    assert r['files_count']==1 and r['errors']>=1
    assert r['passed_files']==0

def test_unsupported_file_included_in_count_not_passed():
    r=analyze_zip(zip_bytes(**{'document.xyz':b'123','ariza.txt':b'abc'}),'Test.zip',ocr_mode='off')
    assert r['files_count']==len(r['documents'])==2
    assert r['unsupported_count']==1 and r['passed_files']==0

def test_renamed_zip_not_proof_of_company():
    r=analyze_zip(zip_bytes(**{'blank.txt':b'example text'}),'Fake International Company.zip',ocr_mode='off')
    assert r['company_name']!='Fake International Company'

def test_report_finance_error_is_publicly_actionable():
    from inspector.actionable_report import resident_items
    r={'language':'uz_lat','issues':[{'id':'finance_v4_gross_margin_1_0_docx','level':'error','title':'Arifmetik farq',
       'description':'Jadval 1, ustun 2: hisoblangan 5, hujjatda 100.',
       'solution':'Formulani tuzating','file':'biznes.docx','source':'Moliya'}]}
    items=resident_items(r)
    assert len(items)==1 and items[0]['fix']

def test_readable_application_with_only_keywords_not_falsely_passed():
    f=DocFile('ariza.docx','.docx',300,kind='application',text=('Ariza rezidentlik '+('test matn '*35)),extraction='ok')
    f.quality='content_present'
    assert assess_file(f,[],{})!='validated'

def test_disabled_api_never_sends(monkeypatch):
    monkeypatch.setenv('CYBERPARK_ENABLE_REMOTE_AI','0')
    assert review_content([], 'Test')['sent'] is False

def test_api_needs_explicit_consent(monkeypatch):
    monkeypatch.setenv('CYBERPARK_ENABLE_REMOTE_AI','1')
    monkeypatch.delenv('CYBERPARK_ALLOW_SANITIZED_CONTENT',raising=False)
    assert review_content([], 'Test')['sent'] is False

@pytest.mark.parametrize('bad_url',[
    'http://cc-vibe.com','https://evil.com','https://cc-vibe.com.evil.org',
    'https://cc-vibe.com:8080','https://cc-vibe.com@evil.com',
    'file:///etc/passwd','https://cc-vibe.com/other',
    'https://cc-vibe.com?steal=yes','https://localhost:8080',
])
def test_ccvibe_wrong_address_blocked(monkeypatch,bad_url):
    monkeypatch.setenv('CYBERPARK_API_PROTOCOL','anthropic')
    monkeypatch.setenv('ANTHROPIC_BASE_URL',bad_url)
    monkeypatch.setenv('ANTHROPIC_AUTH_TOKEN','SYNTHETIC_TEST_ONLY')
    assert _config() is None

@pytest.mark.parametrize('bad_model',['../../key','../x','a'*100,'', 'model\nunsafe','model?host','../safe'])
def test_ccvibe_bad_model_rejected(monkeypatch,bad_model):
    monkeypatch.setenv('CYBERPARK_API_PROTOCOL','anthropic')
    monkeypatch.setenv('ANTHROPIC_BASE_URL','https://cc-vibe.com')
    monkeypatch.setenv('ANTHROPIC_AUTH_TOKEN','SYNTHETIC_TEST_ONLY')
    monkeypatch.setenv('ANTHROPIC_MODEL',bad_model)
    assert _config() is None

@pytest.mark.parametrize('url',[
 '/', '/api/status', '/api/history', '/api/jobs/missing', '/api/checks/missing',
 '/api/rules','/api/requirements','/api/diagnostics','/api/example-preview',
 '/api/checks/abc/files-xlsx', '/api/checks/abc/report-pdf',
 '/api/checks/abc/files/0', '/api/checks/abc/files-csv',
])
def test_endpoint_protected_or_intentionally_removed(url):
    r=client.get(url)
    assert r.status_code in (200,404)
    if url in ('/api/rules','/api/requirements','/api/diagnostics','/api/example-preview',
               '/api/checks/abc/files-xlsx','/api/checks/abc/report-pdf','/api/checks/abc/files/0',
               '/api/checks/abc/files-csv'):
        assert r.status_code==404

@pytest.mark.parametrize('host',['evil.com','cc-vibe.com','a.localhost','127.0.0.1:7777'])
def test_web_host_protection(host):
    assert client.get('/',headers={'host':host}).status_code==403

@pytest.mark.parametrize('origin',['https://evil.com','null','https://localhost:8765'])
def test_upload_bad_origin(origin):
    r=client.post('/api/check',data=b'123',headers={'X-Cyberpark-Local':'1','Content-Type':'application/zip','Origin':origin})
    assert r.status_code==403

@pytest.mark.parametrize('stir',['123ABC789','123','1234567890','123456789'])
def test_removed_manual_stir_rejected(stir):
    r=client.post('/api/check',data=b'BAD',headers={'X-Cyberpark-Local':'1','Content-Type':'application/zip','X-Cyberpark-STIR':stir})
    assert r.status_code==400

@pytest.mark.parametrize('mode',['internal','confirmed','resident','manual','all'])
def test_removed_report_modes_rejected(mode):
    assert client.get(f'/api/checks/no/report?mode={mode}').status_code==400

def test_end_to_end_local_word_export():
    from time import sleep
    raw=zip_bytes(**{'application.txt':'Application test','document.abc':'unknown'})
    r=client.post('/api/check',data=raw,headers={**AUTH,'Content-Type':'application/zip',
       'X-Cyberpark-Filename':'Sample.zip','X-Cyberpark-OCR-Mode':'off'})
    assert r.status_code==200
    jid=r.json()['job_id'];p=None
    for _ in range(150):
        p=client.get('/api/jobs/'+jid).json()
        if p['status'] in ('done','error'):break
        sleep(.05)
    assert p['status']=='done',p
    assert p['progress']==100
    detail=client.get('/api/checks/'+jid).json()
    assert detail['files_count']==2 and detail['unsupported_count']==1
    assert any(x['id']==jid for x in client.get('/api/history').json())
    doc=client.get(f'/api/checks/{jid}/report')
    assert doc.status_code==200
    assert doc.content[:2]==b'PK'
    Document(io.BytesIO(doc.content))
    assert 'filename*=' in doc.headers['Content-Disposition']

def test_only_two_pages_and_one_report_link():
    html=client.get('/').text
    js=client.get('/static/app.js').text
    assert 'page-check' in html and 'page-history' in html
    assert 'page-rules' not in html and 'page-settings' not in html
    assert 'id="word-btn"' in html
    assert 'data-file-get' not in js and 'files-xlsx' not in js and 'report-pdf' not in js
    assert 'showDetails' not in js
