"""Adversarial document identity, DOCX reading order, and report integrity.

Tests are synthetic; no company ZIP content is shipped with the application.
"""
import io
import zipfile
from docx import Document
from inspector.engine import _read_docx, DocFile, identify_kind, analyze_zip
from inspector.report import generate_docx


def _docx_bytes(doc):
    b=io.BytesIO();doc.save(b);return b.getvalue()


def test_docx_table_interleaving_preserved():
    d=Document()
    d.add_paragraph('Biznes-reja: loyiha maqsadi')
    d.add_paragraph('1.1 Tashabbuskor')
    t=d.add_table(rows=1,cols=2)
    t.cell(0,0).text='Kompaniya maqsadi'
    t.cell(0,1).text='Mahalliy dasturiy mahsulot ishlab chiqish'
    d.add_paragraph('1.2 Amalga oshirish bosqichlari')
    text,_,status=_read_docx(_docx_bytes(d))
    assert status=='ok'
    assert text.index('1.1')<text.index('Mahalliy dasturiy')<text.index('1.2')


def test_docx_hyperlinks_and_table_text_are_retained():
    d=Document();d.add_paragraph('1.1 Loyihaning nomi va asoslari')
    t=d.add_table(rows=1,cols=1);t.cell(0,0).text='Maqsad va moliyalashtirish'
    text,_,status=_read_docx(_docx_bytes(d))
    assert 'Maqsad va moliyalashtirish' in text and status=='ok'


def _make(f, name, text, suffix='.docx'):
    return DocFile(name,suffix,len(text.encode()),text=text,extraction='ok')


def test_supplier_contract_is_not_applicant_service_contract():
    doc=_make(None,'Договор поставки оборудования.docx',
        'ДОГОВОР ПОСТАВКИ. Поставщик обязуется передать оборудование, покупатель оплачивает поставку. '+ 'Оборудование ' * 15)
    assert identify_kind(doc)!='contract'


def test_lease_is_not_service_contract():
    doc=_make(None,'Договор аренды.pdf',
        'Договор аренды нежилого помещения с регистрацией прав аренды. '+ 'Стороны договора ' * 12, '.pdf')
    assert identify_kind(doc)!='contract'


def test_real_service_contract_stays_service_contract():
    doc=_make(None,'Договор об оказании услуг.docx',
        'ДОГОВОР ОБ ОКАЗАНИИ УСЛУГ\nИсполнитель выполняет услуги для заказчика. '+'Оказание услуг ' * 15)
    assert identify_kind(doc)=='contract'


def test_dismissal_order_does_not_satisfy_director_order():
    doc=_make(None,'Приказ_12.docx',
        'ПРИКАЗ ОБ УВОЛЬНЕНИИ СОТРУДНИКА ИЗ КОМПАНИИ\n'+ 'Освободить от работы ' * 14)
    assert identify_kind(doc)!='director_order'


def test_director_appointment_order_stays_recognized():
    doc=_make(None,'Приказ_12.docx',
        'ПРИКАЗ О НАЗНАЧЕНИИ ДИРЕКТОРА\n'+ 'Назначить руководителя организации ' * 12)
    assert identify_kind(doc)=='director_order'


def test_renamed_business_plan_is_classified_by_title():
    doc=_make(None,'ariza.docx',
        'БИЗНЕС-ПЛАН\n' + 'Основная цель проекта — информационные технологии. ' * 20)
    assert identify_kind(doc)=='business_plan'


def test_zip_with_only_supply_agreement_still_lacks_service_offer():
    d=Document();d.add_paragraph('ДОГОВОР ПОСТАВКИ');d.add_paragraph('Поставщик продает товары покупателю. '+'Поставка продуктов ' * 30)
    b=io.BytesIO()
    with zipfile.ZipFile(b,'w') as z:z.writestr('Договор поставки.docx',_docx_bytes(d))
    result=analyze_zip(b.getvalue(),'korxona.zip',ocr_mode='off')
    assert not any(x['type']=='contract' for x in result['documents'])
    assert any(i['id']=='missing_contract' for i in result['issues'])


def test_lack_of_evidence_never_counted_as_passed():
    d=Document();d.add_paragraph('АРИЗА');d.add_paragraph('Требуется рассмотреть заявку на резидентство. '+'Прошу принять заявление ' * 20)
    b=io.BytesIO()
    with zipfile.ZipFile(b,'w') as z:z.writestr('Ariza.docx',_docx_bytes(d))
    result=analyze_zip(b.getvalue(),'one.zip',ocr_mode='off')
    assert result['passed_files']==0
    assert result['errors']>0


def test_final_word_contains_no_generic_staff_instruction():
    r={'company_name':'Test MCHJ','language':'uz_lat','files_count':1,'passed_files':0,
       'issues':[{'id':'zero_byte_x','level':'error','title':'Bo‘sh fayl',
                  'description':'Fayl hajmi 0 bayt','solution':'To‘ldiring',
                  'source':'Texnik','file':'anketa.docx'}], 'errors':1,'reviews':0}
    content=generate_docx(r,mode='automatic')
    text=' '.join(p.text for p in Document(io.BytesIO(content)).paragraphs).casefold()
    assert 'xodim tekshirishi kerak' not in text
    assert 'anketa.docx' in text


def test_leave_application_is_not_residency_application():
    doc=_make(None,'Заявление_12.docx',
        'ЗАЯВЛЕНИЕ НА ОТПУСК\nПрошу предоставить ежегодный отпуск с оплатой за дни. '+ 'Отпуск работника ' * 15)
    assert identify_kind(doc)!='application'


def test_helper_process_does_not_receive_ccvibe_key(monkeypatch):
    from inspector.engine import helper_env
    monkeypatch.setenv('ANTHROPIC_AUTH_TOKEN','DO_NOT_PASS_TO_HELPERS')
    monkeypatch.setenv('ANTHROPIC_API_KEY','DO_NOT_PASS_TO_HELPERS')
    monkeypatch.setenv('CYBERPARK_ENABLE_REMOTE_AI','1')
    env=helper_env()
    assert 'ANTHROPIC_AUTH_TOKEN' not in env
    assert 'ANTHROPIC_API_KEY' not in env
    assert env['CYBERPARK_ENABLE_REMOTE_AI']=='1'


def test_browser_process_does_not_receive_ccvibe_key(monkeypatch):
    import run_local
    monkeypatch.setenv('ANTHROPIC_AUTH_TOKEN','DO_NOT_PASS_TO_BROWSER')
    monkeypatch.setenv('ANTHROPIC_API_KEY','DO_NOT_PASS_TO_BROWSER')
    assert 'ANTHROPIC_AUTH_TOKEN' not in run_local.browser_env()
    assert 'ANTHROPIC_API_KEY' not in run_local.browser_env()


def test_director_dismissal_order_is_not_appointment():
    doc=_make(None,'Приказ.docx',
        'ПРИКАЗ ОБ УВОЛЬНЕНИИ ДИРЕКТОРА\n'+ 'Расторгнуть трудовой договор с директором организации ' * 12)
    assert identify_kind(doc)!='director_order'


def test_remote_ai_receives_only_filtered_business_plan_text(monkeypatch):
    import json
    import inspector.remote_reviewer as remote
    seen=[]
    class FakeResponse:
        status=200
        def read(self,n):
            return json.dumps({'content':[{'type':'text','text':'{"findings":[]}'}]}).encode()
    class FakeConnection:
        def __init__(self,host,port,timeout,context):
            assert host=='cc-vibe.com' and port==443
        def request(self,method,path,body,headers):
            seen.append(json.loads(body))
            assert method=='POST' and path=='/v1/messages'
            assert headers['Authorization']=='Bearer FAKE_KEY_FOR_TEST'
        def getresponse(self):return FakeResponse()
        def close(self):pass
    monkeypatch.setattr(remote.http.client,'HTTPSConnection',FakeConnection)
    monkeypatch.setenv('CYBERPARK_ENABLE_REMOTE_AI','1')
    monkeypatch.setenv('CYBERPARK_ALLOW_SANITIZED_CONTENT','1')
    monkeypatch.setenv('CYBERPARK_API_PROTOCOL','anthropic')
    monkeypatch.setenv('ANTHROPIC_BASE_URL','https://cc-vibe.com')
    monkeypatch.setenv('ANTHROPIC_MODEL','claude-sonnet-4-6')
    monkeypatch.setenv('ANTHROPIC_AUTH_TOKEN','FAKE_KEY_FOR_TEST')
    monkeypatch.delenv('CYBERPARK_CCVIBE_AUTH_STYLE',raising=False)
    plan='Platforma raqamli tizimlarni avtomatlashtirishga qaratilgan bo‘lib, foydalanuvchilar uchun xizmatni rivojlantirish rejalashtirilgan.'
    sensitive='Kompaniya STIR 123456789, bank hisobvaraq 20208000000000000000, direktori ALI BOB.'
    f=DocFile('TOP_SECRET_BIZNES_REJA.docx','.docx',1200,text=plan+'\n'+sensitive+'\n'+plan,kind='business_plan',extraction='ok')
    info=remote.review_content([f],company_name='ALI BOB')
    assert info['sent'] is True and seen
    payload=json.dumps(seen[0],ensure_ascii=False)
    assert 'Platforma raqamli tizimlarni' in payload
    for secret in ('123456789','20208000000000000000','TOP_SECRET','ALI BOB'):
        assert secret not in payload


def test_remote_api_is_never_called_without_explicit_opt_in(monkeypatch):
    import inspector.remote_reviewer as remote
    def forbidden(*a,**kw):raise AssertionError('Network call without opt-in')
    monkeypatch.setattr(remote.http.client,'HTTPSConnection',forbidden)
    monkeypatch.setenv('CYBERPARK_ENABLE_REMOTE_AI','1')
    monkeypatch.setenv('CYBERPARK_ALLOW_SANITIZED_CONTENT','0')
    doc=DocFile('plan.docx','.docx',500,text='Platforma biznes loyiha tizimlari. '*20,kind='business_plan',extraction='ok')
    assert remote.review_content([doc])['sent'] is False
