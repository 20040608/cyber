"""Synthetic economic-expertise benchmark, not a company-specific fixture.

The 11 linked reviewer categories use invented names and data; no applicant ZIP,
account number, personal data, or expert document is bundled with the release.
"""
import io
import zipfile
from datetime import date

from docx import Document

from inspector.engine import DocFile, analyze_zip, issue, _add
from inspector.expert_dossier import examine
from inspector.actionable_report import resident_items, report_overview
from inspector.resident_workflow import apply_workflow
from inspector.report import generate_docx

PLAN='''BIZNES-REJA
Loyiha maqsadlari: zamonaviy xizmatlar, dastur ishlab chiqish va marketing.
Jamiyat 2025-yil avgustida tashkil etilgan va tijorat faoliyatini 2026-yildan boshlagan.
1.7. Loyihaning hozirgi holati
Faol biznes. 50 dan ortiq loyiha va 30 mijoz bor; hozirda 1 nafar IT mutaxassis — frontend dasturchi ishlaydi. Boshqa mutaxassislar shartnoma bo‘yicha jalb qilinadi.
1.9. Loyihaning kutilayotgan ko‘lami
2027–2028-yillarda o‘z SaaS mahsulotlarini yaratish rejalashtirilgan.
3.3. Mualliflik huquqi va himoya
SaaS platformasini 2027–2028-yillarda ro‘yxatdan o‘tkazish rejalashtirilgan.
4.3. Raqobatbardoshlik
Raqobatchilar — mahalliy veb-studiyalar va IT-agentliklar, frilanserlar. Ustunlik: tez ishlash va standart xizmatlar.
4.5. Narxlar
Veb-sayt uchun 20000 so‘m, AI assistent uchun 25000 so‘m, botlar uchun 8000 so‘m.
4.6. Marketing rejasi
Kanallar: Instagram, Telegram va reklama. Marketing budjeti — tushumning 3 foizi. Eksport uchun hamkor agentliklar va frilans platformalar orqali bozorga chiqish rejalashtirilgan.
5.1. Ishlab chiqarish rejasi
Ishlab chiqarish, shundan eksport uchun, birlik 0 0 8. Litsenziya va texnika yetkazib berish, ming so‘m 20000 250000 350000.
6.1. Tashkiliy tuzilma
Boshqaruv, xodimlar, ijara haqi oyiga 3000 ming so‘m.
7.4. Xarajatlar hisobi
Amortizatsiya — 20% yillik me’yor. Boshqa xarajatlar va faoliyat.
7.6. To‘lanadigan soliqlar
2028-yilga oid hisob-kitoblar imtiyozlar saqlanib qolishi sharti bilan tuzilgan.
7.7. To‘liq xarajatlar
Ishlab chiqarish tannarxi, amortizatsiya, 2026 2027 2028 yil jadvallari.
7.9. Moliyaviy natijalar prognozi
Yalpi foyda, sof foyda va soliq prognozi, yil kesimida.
7.10. Pul oqimi prognozi
Sof pul oqimi va davrlar kesimida harakat.
7.11. Prognoz balansi
JAMI AKTIVLAR va JAMI PASSIVLAR prognozi.
'''


def make_docs(text=PLAN, extras=()):
    main=DocFile('Biznes-reja.pdf','.pdf',len(text.encode()),text=text,
                 extraction='ok',kind='business_plan')
    return [main] + [DocFile(name,'.pdf',200,text=txt,extraction='ok',kind=kind)
                      for name,kind,txt in extras]


def expert_docs(files):
    issues=[]
    results=examine(files,issues,issue,_add,as_of=date(2026,11,18))
    return results,issues


def test_eleven_distinct_grounded_expert_requests():
    records,items=expert_docs(make_docs())
    assert len(records)==11
    assert len({x['id'] for x in records})==11
    assert all(x['id'].startswith('expert_') and x['file']=='Biznes-reja.pdf'
               and x['source'] and x['solution'] for x in items)
    assert all(x['resident_actionable'] for x in items)
    assert all(x['level']=='review' for x in items)  # Not a fabricated legal verdict.


def test_no_expert_flags_without_business_plan():
    assert not expert_docs([DocFile('test.txt','.txt',12,text='hello',extraction='ok',kind='')])[0]


def test_real_marketing_targets_prevent_false_positive():
    text=PLAN.replace('Marketing budjeti — tushumning 3 foizi.',
          'Marketing budjeti — tushumning 3 foizi. Har oy 25 yangi mijoz jalb etiladi.')
    findings,_=expert_docs(make_docs(text))
    assert 'marketing_targets' not in [f['id'] for f in findings]


def test_rent_contract_and_financial_support_suppress_missing_attachments():
    extras=[('Ijara shartnomasi.pdf','supporting_contract','IJARA SHARTNOMASI\nIjaraga oluvchi...'),
            ('Balans_9_oy_2026.pdf','financial_statement','2026 9 oy moliyaviy natijalar va buxgalteriya balansi')]
    findings,_=expert_docs(make_docs(extras=extras))
    ids={f['id'] for f in findings}
    assert 'lease_agreement' not in ids and 'accounting_9m' not in ids


def test_tax_hypothesis_is_not_a_conclusive_tax_assessment():
    _,issues=expert_docs(make_docs())
    tax=next(x for x in issues if x['id']=='expert_future_tax_assumptions')
    assert tax['level']=='review'
    assert 'huquqiy asos' in tax['solution']
    assert 'amaldagi qonunchilik' in tax['solution']


def test_report_and_workflow_include_grounded_clarifications():
    _,issues=expert_docs(make_docs())
    result={'issues':issues,'company_name':'NAMUNA MCHJ','language':'uz_lat',
            'files_count':1,'passed_files':0,'documents':[]}
    apply_workflow(result)
    assert result['workflow']['stage']=='correction_required'
    assert len(resident_items(result))==11
    assert report_overview(result)['defects_count']==11
    data=generate_docx(result,mode='automatic')
    text='\n'.join(p.text for p in Document(io.BytesIO(data)).paragraphs)
    assert 'Marketing rejasida' in text
    assert '2028-yil prognozida' in text
    assert 'Amortizatsiya' in text
    assert 'xodim tekshirishi kerak' not in text.casefold()


def test_sanitized_zip_never_turns_full_business_plan_into_compliance():
    doc=Document()
    for line in PLAN.splitlines():doc.add_paragraph(line)
    output=io.BytesIO();doc.save(output)
    archive=io.BytesIO()
    with zipfile.ZipFile(archive,'w') as z:z.writestr('Dossier/main_plan.docx',output.getvalue())
    r=analyze_zip(archive.getvalue(),'different_archive_name.zip',ocr_mode='off')
    assert len(r['detailed']['expert_dossier'])==11
    assert r['passed_files']==0
    assert len(resident_items(r))>=11


def test_company_profile_filename_without_underscores_is_identified():
    from inspector.engine import identify_kind
    f=DocFile('files/06_Tashkilot_haqida_malumot_UZ_RU_v2.docx','.docx',2200,
              text='TASHKILOT HAQIDA MA’LUMOT\nKompaniya faoliyati va xizmatlari\n'+'Matn '*40,
              extraction='ok')
    assert identify_kind(f)=='company_info'


def test_director_entry_order_not_ignored_as_generic_file():
    from inspector.engine import identify_kind
    f=DocFile('docs/03b_Direktor_buyrugi_1-son.pdf','.pdf',300,
       text='BUYRUQ №1\nDirektor lavozimiga kirishish to‘g‘risida\n'+
            'Men, namunaviy shaxs, direktor lavozimiga kirishdim. '*6,
       extraction='ok')
    assert identify_kind(f)=='director_order'


def test_dismissal_order_is_not_accepted_as_appointment():
    from inspector.engine import identify_kind
    f=DocFile('docs/Direktor_buyrugi.pdf','.pdf',400,
       text='ISHДАН BO‘SHATISH\nIshdan bo‘shatish haqida buyruq. '+
            'Ishdan bo‘shatish tasdiqlandi. '*10,
       extraction='ok')
    assert identify_kind(f)!='director_order'


def test_future_tax_benefit_not_flagged_when_no_2028_assumption():
    text=PLAN.replace('2028-yilga oid hisob-kitoblar imtiyozlar saqlanib qolishi sharti bilan tuzilgan.',
       'Soliqlar amaldagi qonunchilik bo‘yicha muqobil ssenariyda hisoblangan.')
    records,_=expert_docs(make_docs(text))
    assert 'future_tax_assumptions' not in {r['id'] for r in records}


def test_acquisition_targets_and_named_export_contract_avoid_unfounded_objections():
    text=PLAN.replace('Marketing budjeti — tushumning 3 foizi.',
       'Marketing budjeti — tushumning 3 foizi. Har oy 25 ta yangi mijoz maqsad qilingan.')
    attachments=[('Eksport_shartnoma_2028.pdf','supporting_contract','Imzolangan eksport shartnomasi')]
    records,_=expert_docs(make_docs(text,attachments))
    ids={r['id'] for r in records}
    assert 'marketing_targets' not in ids
    assert 'export_partners' not in ids


def test_report_respects_approved_two_page_navigation_and_only_word():
    from pathlib import Path
    root=Path(__file__).resolve().parents[1]
    html=(root/'static/index.html').read_text(encoding='utf-8')
    js=(root/'static/app.js').read_text(encoding='utf-8')
    assert 'data-page="check"' in html and 'data-page="history"' in html
    assert 'data-page="rules"' not in html and 'data-page="settings"' not in html
    assert 'stat-files' in html and 'stat-passed' in html and 'stat-errors' in html
    assert 'word-btn' in html
    assert 'automated_explanation?.defects_count' in js
