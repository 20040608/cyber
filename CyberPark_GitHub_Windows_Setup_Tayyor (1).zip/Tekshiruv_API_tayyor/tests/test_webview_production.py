"""Regression checks for the original web UI and safe optional CCVibe controls."""
import os
import pytest
from fastapi.testclient import TestClient
from app import app
from inspector import api_settings

client = TestClient(app)
AUTH = {'X-Cyberpark-Local': '1'}


def test_original_frontend_routes_and_rabbit_icon():
    for path in ('/', '/static/app.js', '/static/style.css', '/favicon.ico'):
        assert client.get(path).status_code == 200
    html = client.get('/').text
    assert 'page-check' in html and 'page-history' in html and 'page-api' in html
    assert 'ccvibe-consent' in html
    assert client.get('/favicon.ico').content[:4] == b'\x00\x00\x01\x00'


def test_api_keyless_stays_offline():
    api_settings.disconnect()
    state = client.get('/api/ccvibe').json()
    assert state['enabled'] is False and state['consent'] is False
    result = client.post('/api/ccvibe/test', headers=AUTH).json()
    assert result['ok'] is False
    assert client.get('/api/status').json()['mode'] == 'offline'


def test_explicit_consent_required():
    api_settings.disconnect()
    response = client.post('/api/ccvibe/consent', headers=AUTH, json={'allow': True})
    assert response.status_code == 400
    assert client.get('/api/ccvibe').json()['enabled'] is False


def test_secret_cannot_be_stored_without_windows_dpapi():
    if os.name == 'nt':
        pytest.skip('Only applicable to non-Windows QA environment')
    response = client.post('/api/ccvibe/key', headers=AUTH, json={'key': 'SYNTHETIC_TEST_ONLY'})
    assert response.status_code == 400
    assert 'SYNTHETIC_TEST_ONLY' not in response.text


def test_local_post_guard_remains_active():
    response = client.post('/api/ccvibe/disconnect')
    assert response.status_code == 403
    response = client.post('/api/ccvibe/disconnect', headers={**AUTH, 'Origin': 'https://untrusted.example'})
    assert response.status_code == 403
