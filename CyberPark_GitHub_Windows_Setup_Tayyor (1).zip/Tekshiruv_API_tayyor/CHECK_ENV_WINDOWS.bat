@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo Avval START_WINDOWS.bat ni ishga tushiring.
 pause
 exit /b 1
)
".venv\Scripts\python.exe" -c "from inspector.local_tools import diagnostics; import json; print(json.dumps(diagnostics(),ensure_ascii=False,indent=2))"
echo.
".venv\Scripts\python.exe" -m unittest discover -s tests -q
pause
