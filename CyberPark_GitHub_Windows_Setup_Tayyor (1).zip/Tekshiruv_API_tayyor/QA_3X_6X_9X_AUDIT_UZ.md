# Cyber Park Inspector v6.4 — 3× / 6× / 9× mustahkamlik auditi

**Sana:** 18.11.2026  
**Maqsad:** v6.3 dagi mavjud modullarni qattiqroq sinash, haqiqiy nuqsonlarni tuzatish va avvalgi tashqi ko‘rinishni o‘zgartirmaslik.

## Sinov tushunchasi

3×, 6×, 9× — ssenariylarning **shartli murakkablik darajalari**; aynan necha baravar ko‘p xato topilishi yoki dastur 98% aniqlikka erishgani degani emas. Tekshiruvda haqiqiy korxona fayllari lokal ishlatildi; testlar kutubxonasiga ularning asl matni joylanmadi.

| Daraja | Qarama-qarshi sinovlar | Kuzatilgan xatti-harakat |
|---|---|---|
| 3× | Turlicha ZIP/fayl nomi, DOCX paragraf-jadval tartibi, buzilgan raqam formatlari, uzun matn | Joylashish tartibi majburiy qoidaga aylanmadi, kesilgan matn `partial` deb belgilandi |
| 6× | 47 loyiha/2 IT xodimi, 60/3, 19/1, aniq pudratchilar, bir jadvalda qarama-qarshi qaytarilgan satrlar | Dalilga asoslangan aniqlashtirish, noto‘g‘ri arifmetik e’tirozlardan himoya |
| 9× | ZIP yo‘li, Unicode takror nom, ZIP-bomb, CRC buzilishi, 181 fayl, parallel yuklash, soxta API dalili, identifikatsiyasi boshqa korxonalar | Xavfli arxivlar rad etildi; shikastlangan a’zo alohida kamchilik sifatida qayd qilindi; API soxta dalili rasmiy e’tirozga o‘tmadi |

## Kodda tuzatilgan haqiqiy nuqsonlar

1. `expert_dossier.py`: joriy IT xodimlari soni boshqa bo‘limda bo‘lsa, ko‘p bajarilgan loyihalar bilan mutanosiblik tekshiruvi yo‘qolardi. Hozir joriy xodimlar sonining tegishli kontekstini qidiradi; kelajakdagi rejalashtirilgan xodimlarni hozirgi deb olmaydi.
2. `finance_v4.py`: `1 2 3` kabi raqamlar `123` deb o‘qilishi mumkin edi. Endi minglik guruhlar tekshiriladi.
3. `finance_v4.py`: bitta jadvalda bir xil moliyaviy satr ikki xil raqam bilan takrorlansa, birini tanlab noto‘g‘ri arifmetik e’tiroz chiqarishi mumkin edi. Endi ziddiyatli satr ishonchli formula uchun ishlatilmaydi.
4. `engine.py`: ZIPdagi bitta CRC shikastlangan a’zo barcha tekshiruvni yiqitishi mumkin edi. Endi o‘sha fayl alohida dalilli kamchilik, qolganlari esa qayta ishlanadi.
5. `engine.py`: NFKC orqali bir xil ko‘rinadigan takroriy Unicode ZIP yo‘llari ajratib tekshiriladi.
6. `engine.py`: noto‘g‘ri kiritilgan OCR vaqt budjeti qiymati butun jarayonni xato bilan to‘xtatmasligi uchun standart cheklov qo‘llanadi.
7. `engine.py`: rasmning sarlavhasiga ishonib, uning o‘zini tekshirmaslik bartaraf qilindi — ma’lumotning yaxlitligi `Pillow.verify` bilan sinaladi.
8. `app.py`: bir vaqtda ikki katta ZIPni qabul qilishdagi poyga holati tuzatildi. Ikkinchi yuklash birinchi oqim qabul qilinayotgan vaqtning o‘zida 429 bilan qaytariladi.
9. `store.py`: turli korxonalar bir xil shablon ZIP fayllariga ega bo‘lsa, `content_fingerprint` bir xil bo‘lgani uchun ularning tarixlari birlashtirilmasligi ta’minlandi.

## Haqiqiy, maxfiy ZIPlar bo‘yicha lokal regressiya (OCR o‘chirilgan)

| ZIP | Fayl | Tasdiqlangan texnik xato | Manbali rezident so‘rovi | Eslatma |
|---|---:|---:|---:|---|
| LENO | 13 | 0 | 11 | Iqtisodchi hujjatidagi 11 yo‘nalishga nisbatan qamrov; manbaga bog‘langan so‘rovlar |
| NexaGrid | 24 | 3 | 3 | Bo‘sh fayl, bo‘sh anketa papkasi, banner o‘lchami |
| MILLIY POCHTA TO‘LOVLARI | 20 | 0 | 0 | OCR o‘chiqligi sabab mazmun to‘liq ekspertizadan o‘tmagan |
| MAXSUS ALOQA TAMIRLASH | 12 | 0 | 0 | OCR o‘chiqligi sabab mazmun to‘liq ekspertizadan o‘tmagan |
| CLOUDNOVA TECH | 17 | 0 | 0 | OCR o‘chiqligi sabab mazmun to‘liq ekspertizadan o‘tmagan |

`passed_files` yuqoridagi sinovlarda **0**: dalil yetarli emasligini xatosiz deb yashil ko‘rsatmaslik siyosati saqlangan. Bu texnik jihatdan konservativ va to‘liq avtomatik ekspertiza hali yetilmaganini anglatadi.

## Ish jarayoni sinovi

- **253/253** avtomatik test o‘tdi (avvalgi 181 regressiya + yangi 72 adversarial/test holati).
- Testclient bilan **LENO va NexaGrid**: ZIP yuklash → progress 100 → tarix → Word xulosa — muvaffaqiyatli.
- LENO xulosasi **11 ta** manbaga bog‘langan to‘ldirish talabi bilan chiqdi; Word vizual tekshiruvda ikki sahifa edi.
- API kalitsiz, tashqi xizmatga hujjat yubormasdan sinov bajarildi.
- O‘rnatilgan loyiha papkasidan takroriy avtomatik sinov amalga oshirildi.

## Saqlangan foydalanish talablari

Ikki sahifa: **Tekshirish**, **Natijalar tarixi**. Faqat uchta karta: **jami fayllar**, **tekshiruvdan o‘tganlar**, **kamchiliklar**. Faqat Word xulosa yuklash. Hech qanday Qoidalar/Sozlamalar sahifasi qaytarilmadi. Windows uchun Python 3.11/3.12 kerak. CCVibe manzili oldindan yozilgan, kalit faqat `API_ULASH_WINDOWS.bat`da kiritiladi.

## Tayin cheklovlar

**253 ta kod testi 98% hujjat eksperti aniqligi emas.** Hujjatlar turli OCR sifatida, nostandart jadvallarda, iqtisodiy farazlarda va qonunchilik o‘zgarishlarida avtomatik to‘g‘ri baholanishi isbotlanmagan. LENO etaloni bitta kompaniya; umumlashtirilgan precision/recall uchun xodimning yangi, ilgari ishlatilmagan e’tirozlari zarur. Jonli CCVibe kaliti bilan ulanish va Windows’da to‘liq qabul sinovi bu muhitda bajarilmadi. Dastur tekshiruvni avtomatlashtiradi, rezidentlikning huquqiy yakuniy qarorini bermaydi.
