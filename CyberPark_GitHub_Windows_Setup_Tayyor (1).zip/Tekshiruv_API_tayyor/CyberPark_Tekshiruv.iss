#define MyAppName "Cyber Park Hujjatlar Tekshiruvi"
#define MyAppVersion "1.0.0"
#define MyAppExeName "CyberPark_Tekshiruv.exe"
[Setup]
AppId={{7736F760-74A1-4A7B-9335-17B47775F9A2}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher=Cyber Park
DefaultDirName={localappdata}\Programs\CyberParkTekshiruv
DefaultGroupName={#MyAppName}
PrivilegesRequired=lowest
ArchitecturesAllowed=x64
ArchitecturesInstallIn64BitMode=x64
OutputDir=installer
OutputBaseFilename=CyberPark_Tekshiruv_Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
SetupIconFile=assets\rabbit_icon.ico
UninstallDisplayIcon={app}\{#MyAppExeName}
CloseApplications=yes
RestartApplications=no
DisableProgramGroupPage=yes

[Files]
Source: "dist\CyberPark_Tekshiruv\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\Cyber Park Tekshiruv"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Tasks]
Name: "desktopicon"; Description: "Ish stolida yorliq yaratish"; GroupDescription: "Qo'shimcha vazifalar:"

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Dasturni ishga tushirish"; Flags: nowait postinstall skipifsilent

[UninstallDelete]
; User documents, API secrets and encrypted audit history are deliberately retained.
