@echo off
setlocal
cd /d "%~dp0"
echo Cyber Park CCVibe API (kalit lokal TXT fayldan olinadi).
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0START_WITH_CC_VIBE_WINDOWS.ps1"
echo.
echo Kalit faylini hech kimga yubormang. Xato bo'lsa faqat HTTP kodni yuboring.
pause
