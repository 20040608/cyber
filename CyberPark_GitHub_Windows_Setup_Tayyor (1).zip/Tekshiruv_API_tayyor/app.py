"""Cyber Park: single-user offline-first ZIP inspection service.

Only two pages and one export format. External AI is opt-in and receives
anonymized business-plan excerpts only. A completed run is not legal approval.
"""
import os
import re
import sys
import threading
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from urllib.parse import unquote

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, Response
from starlette.middleware.base import BaseHTTPMiddleware

from inspector.engine import MAX_UPLOAD, UnsafeArchive, analyze_zip
from inspector.report import generate_docx
from inspector.download_naming import attachment_disposition, report_filename
from inspector.rules import load as load_rules
from inspector.store import init, save, get, list_checks
from inspector import api_settings

ROOT = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent))
APP_DIR = Path(__file__).resolve().parent
app = FastAPI(title='Cyber Park Document Inspector', docs_url=None,
              redoc_url=None, openapi_url=None)
init()
JOBS = {}
UPLOAD_IN_PROGRESS = False
LOCK = threading.RLock()
POOL = ThreadPoolExecutor(max_workers=1, thread_name_prefix='cp_check')

class LocalOnly(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        port = os.environ.get('CYBERPARK_HTTP_PORT', '8765')
        if request.headers.get('host','') not in (
            f'localhost:{port}',f'127.0.0.1:{port}','localhost','127.0.0.1','testserver'):
            return JSONResponse({'error':'Faqat lokal manzil.'},status_code=403)
        if request.method not in ('GET','HEAD','OPTIONS'):
            if request.headers.get('origin') not in (None,f'http://localhost:{port}',f'http://127.0.0.1:{port}'):
                return JSONResponse({'error':'Noto‘g‘ri Origin.'},status_code=403)
            if request.headers.get('x-cyberpark-local') != '1':
                return JSONResponse({'error':'Lokal so‘rov belgisi yo‘q.'},status_code=403)
        response = await call_next(request)
        for key,val in {
            'Cache-Control':'no-store', 'X-Content-Type-Options':'nosniff',
            'X-Frame-Options':'DENY',
            'Content-Security-Policy':"default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'",
        }.items():response.headers[key]=val
        return response

app.add_middleware(LocalOnly)

@app.get('/',response_class=HTMLResponse)
async def home():
    return (ROOT/'static'/'index.html').read_text(encoding='utf-8')

@app.get('/static/{name}')
async def static(name:str):
    if name not in ('app.js','style.css'):raise HTTPException(404)
    return Response((ROOT/'static'/name).read_text(encoding='utf-8'),
                    media_type='application/javascript' if name=='app.js' else 'text/css')

@app.get('/favicon.ico')
async def favicon():
    icon = ROOT/'assets'/'rabbit_icon.ico'
    if not icon.exists():
        raise HTTPException(404)
    return Response(icon.read_bytes(), media_type='image/x-icon')

def progress(job, percentage, step):
    with LOCK:
        if JOBS.get(job,{}).get('status')=='running':
            current=JOBS[job].get('progress',0)
            JOBS[job].update(progress=min(99,max(current,int(percentage))),step=step)

def worker(job, data, name, parent, ocr_mode, ocr_lang, preprocess, remote_enabled=False):
    try:
        from inspector.engine import OCR_CONTEXT
        OCR_CONTEXT.language=ocr_lang
        OCR_CONTEXT.preprocess=preprocess
        ai_source=[]
        def capture(f):
            if len(ai_source)<3:ai_source.append(f)
        result=analyze_zip(data,name,rules=load_rules(),
            progress=lambda p,s:progress(job,p,s),ocr_mode=ocr_mode,
            ai_capture=capture if remote_enabled else None)
        progress(job,97,'Mazmun va dalillar jamlanmoqda')
        from inspector.remote_reviewer import review_content
        remote={'enabled':False,'sent':False,'message':'API o‘chiq, ma’lumotlar lokal.'}
        if remote_enabled:
            remote=review_content(ai_source,result.get('company_name',''))
        ai_source.clear()
        result.setdefault('automation',{})['external_ai']={k:v for k,v in remote.items() if k!='suggestions'}
        result['automation']['external_ai']['dossier_semantics_complete']=False
        for i,item in enumerate(remote.get('suggestions',[])):
            result['issues'].append({
                'id':f'ccvibe_review_{i}','level':'review','confidence':'medium',
                'title':'API mazmuniy tavsiyasi (tasdiqlanmagan)',
                'description':item['problem']+' | Dalil: '+item['quote'],
                'solution':item['suggestion'],'file':'',
                'source':'Filtrlangan biznes-reja parchasi '+item['snippet_id'],
                'evidence':item['quote']})
        result['reviews']=sum(x['level']=='review' for x in result['issues'])
        from inspector.resident_workflow import apply_workflow
        from inspector.actionable_report import report_overview
        result=apply_workflow(result)
        result['automated_explanation']=report_overview(result)
        progress(job,99,'Hisobot mahalliy tarixga yozilmoqda')
        save(job,name,result,parent)
        with LOCK:
            JOBS[job].update(status='done',progress=100,step='Tekshiruv jarayoni yakunlandi',result_id=job)
    except UnsafeArchive as exc:
        with LOCK:JOBS[job].update(status='error',error=str(exc),step='ZIP yaroqsiz')
    except Exception:
        # Neither file text nor secrets should appear in client-visible exceptions.
        with LOCK:JOBS[job].update(status='error',error='Tekshiruvda texnik xato. Fayl va OCR sozlamasini tekshiring.',step='Jarayon to‘xtadi')

@app.post('/api/check')
async def check(request:Request):
    if request.headers.get('content-type','').split(';')[0].strip().lower() not in ('application/zip','application/octet-stream'):
        raise HTTPException(415,'Faqat ZIP qabul qilinadi')
    name=unquote(request.headers.get('x-cyberpark-filename','korxona.zip'))
    name=''.join(ch for ch in os.path.basename(name.replace('\\','/'))[:180] if ord(ch)>=32)
    if not name.lower().endswith('.zip'):raise HTTPException(400,'Faqat ZIP')
    ocr=request.headers.get('x-cyberpark-ocr-mode','full')
    language=request.headers.get('x-cyberpark-ocr-lang','auto')
    if ocr not in ('off','quick','full') or language not in ('uz','ru','auto'):
        raise HTTPException(400,'OCR parametrlari noto‘g‘ri')
    preprocess=request.headers.get('x-cyberpark-ocr-preprocess','1')!='0'
    parent=request.headers.get('x-cyberpark-parent-id','')[:80] or None
    if request.headers.get('x-cyberpark-stir','').strip():
        raise HTTPException(400,'Qo‘lda STIR kiritish bekor qilingan; raqam hujjatlardan olinadi.')
    # Reserve the single-worker upload slot BEFORE streaming the body.
    # Otherwise two overlapping slow uploads can both pass the running-job
    # check and exhaust memory on the one-employee Windows workstation.
    global UPLOAD_IN_PROGRESS
    with LOCK:
        if UPLOAD_IN_PROGRESS or any(j['status']=='running' for j in JOBS.values()):
            raise HTTPException(429,'Oldingi ZIP tekshiruvi hali tugamagan.')
        UPLOAD_IN_PROGRESS=True
    try:
        raw=bytearray()
        async for chunk in request.stream():
            raw.extend(chunk)
            if len(raw)>MAX_UPLOAD:raise HTTPException(413,'ZIP 500 MB chegaradan oshdi')
        if len(raw)<22:raise HTTPException(400,'ZIP bo‘sh yoki yaroqsiz')
        job=uuid.uuid4().hex
        with LOCK:
            JOBS[job]={'id':job,'status':'running','progress':2,'step':'ZIP qabul qilindi'}
            if len(JOBS)>100:
                for old in [k for k,v in JOBS.items() if v['status']!='running'][:50]:JOBS.pop(old,None)
        POOL.submit(worker,job,bytes(raw),name,parent,ocr,language,preprocess,api_settings.snapshot()['enabled'])
        return {'job_id':job}
    finally:
        with LOCK:
            UPLOAD_IN_PROGRESS=False

@app.get('/api/jobs/{job}')
async def job_status(job:str):
    with LOCK:
        if job not in JOBS:raise HTTPException(404,'Jarayon topilmadi')
        return JOBS[job].copy()

@app.get('/api/checks/{check_id}')
async def check_detail(check_id:str):
    result=get(check_id)
    if not result:raise HTTPException(404,'Tekshiruv topilmadi')
    return result

@app.get('/api/history')
async def history():return list_checks()

@app.get('/api/checks/{check_id}/report')
async def word_report(check_id:str, mode:str='automatic'):
    if mode != 'automatic':raise HTTPException(400,'Faqat avtomatik Word xulosa mavjud.')
    result=get(check_id)
    if not result:raise HTTPException(404,'Tekshiruv topilmadi')
    content=generate_docx(result,mode='automatic')
    return Response(content,
        media_type='application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        headers={'Content-Disposition':attachment_disposition(report_filename(result,'docx'))})

@app.get('/api/status')
async def status():
    return {'engine':'cyberpark-v6.4-stress-hardened',
        'mode':'hybrid' if os.environ.get('CYBERPARK_ENABLE_REMOTE_AI')=='1' else 'offline',
        'instance':os.environ.get('CYBERPARK_RUNTIME_NONCE', ''),
        'notice':'Faqat filtrlangan biznes-reja parchalari tashqi APIga chiqishi mumkin; boshqa hujjatlar lokal.'}


@app.get('/api/ccvibe')
async def ccvibe_state():
    return api_settings.snapshot()

@app.post('/api/ccvibe/key')
async def ccvibe_save_key(request: Request):
    body = await request.json()
    try:
        api_settings.save_key(str(body.get('key', '')))
    except (ValueError, RuntimeError) as exc:
        raise HTTPException(400, str(exc)) from None
    return api_settings.snapshot()

@app.post('/api/ccvibe/test')
async def ccvibe_test():
    from starlette.concurrency import run_in_threadpool
    return await run_in_threadpool(api_settings.probe)

@app.post('/api/ccvibe/consent')
async def ccvibe_consent(request: Request):
    body = await request.json()
    try: return api_settings.set_consent(body.get('allow') is True)
    except ValueError as exc: raise HTTPException(400, str(exc)) from None

@app.post('/api/ccvibe/disconnect')
async def ccvibe_disconnect():
    api_settings.disconnect()
    return api_settings.snapshot()
