"""Start the localhost server and open a tab-free desktop app window on Windows.

No business document contents are handed to the launcher. If a supported browser is
missing, fall back to the regular browser with a visually blank tab title.
"""
import os
import subprocess
import threading
import time
import webbrowser
from pathlib import Path

import uvicorn

URL = 'http://127.0.0.1:8765'


def browser_env():
    # The browser only opens loopback UI. Never expose a provider API secret
    # through a browser process' environment, even for --app mode.
    secrets={'ANTHROPIC_AUTH_TOKEN','ANTHROPIC_API_KEY',
             'OPENAI_API_KEY','CYBERPARK_API_KEY','CYBERPARK_SECRET_KEY'}
    return {k:v for k,v in os.environ.items() if k.upper() not in secrets
            and not k.upper().startswith('CYBERPARK_AUTH_')}


def open_as_app(url: str) -> bool:
    """Open local Edge/Chrome in --app mode: no browser tab or tab title."""
    if os.name != 'nt':
        return False
    roots = [os.environ.get('PROGRAMFILES(X86)'), os.environ.get('PROGRAMFILES'),
             os.environ.get('LOCALAPPDATA')]
    relative = ['Microsoft/Edge/Application/msedge.exe',
                'Google/Chrome/Application/chrome.exe']
    for root in roots:
        if not root:
            continue
        for name in relative:
            browser = Path(root) / name
            if not browser.is_file():
                continue
            try:
                subprocess.Popen([str(browser), f'--app={url}',
                                  '--no-first-run', '--no-default-browser-check',
                                  '--disable-background-networking'],
                                 stdin=subprocess.DEVNULL,
                                 stdout=subprocess.DEVNULL,
                                 stderr=subprocess.DEVNULL,env=browser_env())
                return True
            except OSError:
                continue
    return False


def open_ui():
    time.sleep(1.8)
    if not open_as_app(URL):
        webbrowser.open(URL)


if __name__ == '__main__':
    threading.Thread(target=open_ui, daemon=True).start()
    uvicorn.run('app:app', host='127.0.0.1', port=8765,
                access_log=False, log_level='warning')
