@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo.
echo [1/3] Cyber Park Windows EXE yaratilmoqda...
call "%~dp0BUILD_WINDOWS_EXE.bat" /quiet
if errorlevel 1 goto :fail
if not exist "%~dp0dist\CyberPark_Tekshiruv\CyberPark_Tekshiruv.exe" goto :fail

echo [2/3] Inno Setup Compiler qidirilmoqda...
set "ISCC="
for %%P in ("%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" "%ProgramFiles%\Inno Setup 6\ISCC.exe" "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe") do (
  if exist "%%~P" set "ISCC=%%~P"
)
if not defined ISCC (
 echo.
 echo Inno Setup 6 o'rnatilmagan.
 echo Rasmiy sahifa: https://jrsoftware.org/isdl.php
 echo Dasturni o'rnatgach BUILD_INSTALLER_WINDOWS.bat ni yana ishga tushiring.
 echo Hozircha EXE tayyor: dist\CyberPark_Tekshiruv\CyberPark_Tekshiruv.exe
 pause
 exit /b 2
)
echo [3/3] Windows Setup yig'ilmoqda...
"%ISCC%" "%~dp0CyberPark_Tekshiruv.iss"
if errorlevel 1 goto :fail
if not exist "%~dp0installer\CyberPark_Tekshiruv_Setup.exe" goto :fail
echo.
echo TAYYOR: installer\CyberPark_Tekshiruv_Setup.exe
echo Uni Windows 10/11 x64 kompyuterga o'rnating.
echo API kalitini hech qachon installer ichiga joylamang.
pause
exit /b 0
:fail
echo XATO: Windows ilovasi yoki o'rnatkichni yaratib bo'lmadi.
pause
exit /b 1
