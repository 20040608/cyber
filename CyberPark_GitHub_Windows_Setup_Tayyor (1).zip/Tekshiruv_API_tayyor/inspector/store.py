"""Privacy-minimal, local-only audit history with no original file storage."""
import json
import os
import sqlite3
import threading
from contextlib import contextmanager
from datetime import datetime,timezone
from pathlib import Path
from .privacy import seal,unseal,index,protection_status

LOCK=threading.RLock()
# Windows: per-user local-app-data inherits the Windows user's NTFS ACL.
# Sensitive audit history should not default to a shared project folder.
DEFAULT_DIR = (Path(os.environ['LOCALAPPDATA'])/'CyberPark'/'DocumentInspector'
               if os.name=='nt' and os.environ.get('LOCALAPPDATA')
               else Path(__file__).resolve().parent.parent/'data')
DATA_DIR=Path(os.environ.get('CYBERPARK_DATA_DIR',str(DEFAULT_DIR)))
DATA_DIR.mkdir(parents=True,exist_ok=True)
DB=DATA_DIR/'inspector.sqlite3'

@contextmanager
def connect():
    con=sqlite3.connect(DB,timeout=12)
    try:
        con.row_factory=sqlite3.Row
        con.execute('PRAGMA journal_mode=WAL')
        con.execute('PRAGMA secure_delete=ON')
        con.execute('PRAGMA busy_timeout=12000')
        with con:
            yield con
    finally:
        con.close()

def init():
    with LOCK,connect() as c:
        c.execute('''CREATE TABLE IF NOT EXISTS checks(
             id TEXT PRIMARY KEY, created_at TEXT NOT NULL, company TEXT NOT NULL,
             company_key TEXT NOT NULL, stir TEXT, file_name TEXT, sha256 TEXT,
             status TEXT, errors INTEGER, reviews INTEGER, parent_id TEXT,
             result_json TEXT NOT NULL)''')
        c.execute('CREATE INDEX IF NOT EXISTS ix_company_key ON checks(company_key,created_at DESC)')
        c.execute('CREATE INDEX IF NOT EXISTS ix_stir ON checks(stir,created_at DESC)')
        if 'content_fingerprint' not in {r['name'] for r in c.execute('PRAGMA table_info(checks)')}:
            c.execute('ALTER TABLE checks ADD COLUMN content_fingerprint TEXT')
        c.execute('CREATE INDEX IF NOT EXISTS ix_content_fingerprint ON checks(content_fingerprint)')
        # Upgrade old plaintext history. All current/next checks are encrypted at rest.
        changed=False
        for row in c.execute('SELECT id,company,company_key,stir,file_name,result_json FROM checks').fetchall():
            if str(row['result_json']).startswith('cp5:'):continue
            changed=True
            company=row['company'] or ''
            stir=row['stir'] or ''
            c.execute('UPDATE checks SET company=?,company_key=?,stir=?,file_name=?,result_json=? WHERE id=?',(
              seal(company,DATA_DIR),index(row['company_key'],DATA_DIR),index(stir,DATA_DIR) if stir else None,
              seal(row['file_name'],DATA_DIR),seal(row['result_json'],DATA_DIR),row['id']))
    # Rebuild SQLite file to discard erased plaintext cells left by earlier versions.
    if changed:
        with LOCK,connect() as c:
            c.execute('VACUUM')
            c.execute('PRAGMA wal_checkpoint(TRUNCATE)')

def previous(company_key,stir=None,parent_id=None,content_fingerprint=None,
             identity_verified=True):
    """Never join different applicants merely because template bytes match."""
    stir_key=index(stir,DATA_DIR) if stir else None
    with LOCK,connect() as c:
        if parent_id and identity_verified:
            row=c.execute('SELECT * FROM checks WHERE id=?',(parent_id,)).fetchone()
            if row and (row['company_key']==company_key or
                        (stir_key and row['stir']==stir_key)):
                return dict(row)
        if stir_key:
            row=c.execute('SELECT * FROM checks WHERE stir=? ORDER BY created_at DESC LIMIT 1',(stir_key,)).fetchone()
            if row:return dict(row)
        if not identity_verified:
            return None
        if content_fingerprint:
            row=c.execute('SELECT * FROM checks WHERE content_fingerprint=? AND company_key=? ORDER BY created_at DESC LIMIT 1',
                          (content_fingerprint,company_key)).fetchone()
            if row:return dict(row)
        row=c.execute('SELECT * FROM checks WHERE company_key=? ORDER BY created_at DESC LIMIT 1',(company_key,)).fetchone()
        return dict(row) if row else None

def save(check_id,file_name,result,parent_id=None):
    from .engine import norm
    key=index(norm(result['company_name']),DATA_DIR)
    known=result.get('company_name')!='Korxona nomi tasdiqlanmadi'
    provenance=result.get('company_identity',{}).get('status')
    identity_verified=bool(result.get('stir') or (known and provenance!='unverified'))
    prev=previous(key,result.get('stir'),parent_id,result.get('content_fingerprint'),
                  identity_verified=identity_verified)
    if prev and prev.get('stir') and result.get('stir') and prev['stir']!=index(result['stir'],DATA_DIR):
        # Explicitly selected prior record cannot connect two distinct STIR entities.
        prev=None
    if prev:
        try:
            prior=json.loads(unseal(prev['result_json'],DATA_DIR));old={i['id'] for i in prior['issues'] if i['level']=='error' or i.get('resident_actionable')}
            now={i['id'] for i in result['issues'] if i['level']=='error' or i.get('resident_actionable')}
            # Disappearing flags are not necessarily FIXED: renamed files, OCR
            # failure or a changed template may also hide them.
            result['comparison']={'previous_id':prev['id'],'no_longer_flagged':len(old-now),'remaining':len(old&now),'new':len(now-old),
                                  'note':'Aniqlanmay qolgan xato avtomatik ravishda tuzatildi degani emas.'}
        except (KeyError,ValueError,TypeError): pass
    result['id']=check_id
    result['created_at']=datetime.now(timezone.utc).astimezone().isoformat(timespec='seconds')
    result['file_name']=file_name
    with LOCK,connect() as c:
        c.execute('''INSERT INTO checks(id,created_at,company,company_key,stir,file_name,sha256,status,errors,reviews,parent_id,result_json,content_fingerprint) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)''',(
            check_id,result['created_at'],seal(result['company_name'],DATA_DIR),key,
            index(result.get('stir'),DATA_DIR) if result.get('stir') else None,
            seal(file_name,DATA_DIR),result['checksum'],result['status'],result['errors'],result['reviews'],
            prev['id'] if prev else None,seal(json.dumps(result,ensure_ascii=False),DATA_DIR),result.get('content_fingerprint')))
    return result

def get(check_id):
    with LOCK,connect() as c:
        r=c.execute('SELECT result_json FROM checks WHERE id=?',(check_id,)).fetchone()
        if not r:return None
        obj=json.loads(unseal(r['result_json'],DATA_DIR))
        return obj

def list_checks(limit=70):
    with LOCK, connect() as db:
        rows=db.execute('SELECT id,created_at,status,errors,reviews,result_json FROM checks ORDER BY created_at DESC LIMIT ?',
            (min(150,max(1,limit)),)).fetchall()
        items=[]
        for row in rows:
            try:
                item=json.loads(unseal(row['result_json'],DATA_DIR))
                items.append({'id':row['id'],'created_at':row['created_at'],
                    'status':row['status'],'errors':row['errors'],'reviews':row['reviews'],
                    'company':item.get('company_name',''), 'stir':item.get('stir'),
                    'files_count':item.get('files_count',0)})
            except (ValueError,TypeError):continue
        return items
