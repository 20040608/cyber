"""Zero-document gateway preflight. A generic 'OK' prompt is the only payload.

No project files, company details or token are printed. This MAY incur a very
small provider charge. Never silently change the approved destination host.
"""
from __future__ import annotations
import http.client
import json
import os
import ssl
import sys

HOST='cc-vibe.com'
PATH='/v1/messages'

def check_connection(key=None, model=None, connector=None):
    key=key if key is not None else os.environ.get('ANTHROPIC_AUTH_TOKEN','')
    model=model or os.environ.get('ANTHROPIC_MODEL','claude-sonnet-4-6')
    if not key or not key.strip():
        return False,'Kalit kiritilmadi.',''
    if os.environ.get('ANTHROPIC_BASE_URL','https://cc-vibe.com').rstrip('/')!='https://cc-vibe.com':
        return False,'Manzil noto‘g‘ri. Faqat https://cc-vibe.com ishlatiladi.',''
    # Authentication method varies across third-party Anthropic-style gateways.
    conn_factory=connector or http.client.HTTPSConnection
    payload=json.dumps({'model':model,'max_tokens':12,
        'messages':[{'role':'user','content':'Reply only OK.'}]},ensure_ascii=True).encode('utf-8')
    last_status=None
    for auth in ('bearer','x-api-key'):
        headers={'content-type':'application/json','anthropic-version':'2023-06-01'}
        if auth=='bearer':headers['Authorization']='Bearer '+key
        else:headers['x-api-key']=key
        connection=None
        try:
            connection=conn_factory(HOST,443,timeout=15,context=ssl.create_default_context())
            connection.request('POST',PATH,payload,headers)
            response=connection.getresponse()
            last_status=int(response.status)
            response_body=response.read(16000)  # never print provider content (could echo secrets)
        except (OSError,TimeoutError,ValueError) as exc:
            reason='Tarmoq, DNS yoki SSL ulanishida xato. Internet va HTTPS sertifikatini tekshiring.'
            if isinstance(exc,TimeoutError):reason='CCVibe javob bermadi (15 soniya). Internetni tekshiring.'
            return False,reason,''
        finally:
            if connection is not None:
                try:connection.close()
                except OSError:pass
        if last_status==200:
            try:
                response_json=json.loads(response_body)
                if not isinstance(response_json,dict):raise ValueError('schema')
                content=response_json.get('content')
                if not isinstance(content,list) or not any(isinstance(x,dict) and x.get('type')=='text' for x in content):
                    return False,'HTTP 200 qaytdi, lekin Anthropic Messages javobi emas. CCVibe API endpointi mos emas.',''
            except (ValueError,TypeError):
                return False,'HTTP 200 qaytdi, lekin javob JSON emas. CCVibe sahifasiga emas, API endpointga ulanayotganingizni tekshiring.',''
            return True,'CCVibe API sinov xabari muvaffaqiyatli qabul qilindi.',auth
        if last_status not in (401,403):break
    explanations={
        400:'HTTP 400: so‘rov formati yoki model mos kelmayapti.',
        401:'HTTP 401: API kaliti rad etildi yoki muddati tugagan.',
        402:'HTTP 402: provayder hisobida mablag‘ yoki billing muammosi.',
        403:'HTTP 403: ushbu kalitga modeldan foydalanish ruxsati berilmagan.',
        404:'HTTP 404: API yo‘li yoki model topilmadi. CCVibe panelida model nomini tekshiring.',
        429:'HTTP 429: limit tugagan; keyin qayta urinib ko‘ring.',
        500:'HTTP 500: CCVibe serverida muammo.',
        502:'HTTP 502: CCVibe oraliq serverida muammo.',
        503:'HTTP 503: CCVibe vaqtincha band.',
        504:'HTTP 504: CCVibe javob berish vaqti tugadi.',
    }
    return False,explanations.get(last_status,f'HTTP {last_status}: CCVibe API javobi muvaffaqiyatli emas.'),''

if __name__=='__main__':
    ok,description,auth=check_connection()
    print(description)
    if ok:print('AUTH_STYLE='+auth)
    sys.exit(0 if ok else 2)
