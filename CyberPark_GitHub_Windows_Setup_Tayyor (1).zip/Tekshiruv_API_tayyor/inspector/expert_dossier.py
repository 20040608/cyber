"""Evidence-bound economic and business-plan review.

The checks are reusable patterns, NOT a LENO-specific result list. They look for
actual claims and omissions in document text and attachments. A supported
clarification is distinct from a proved numerical or document-presence error.
No tax-rate or legal-validity claim is hard-coded as a legal determination.
"""
from __future__ import annotations

import re
import unicodedata
from datetime import date
from typing import Iterable


def compact(value: str) -> str:
    return re.sub(r'\s+', ' ', unicodedata.normalize('NFKC', value or '')).strip()


def section(text: str, number: str, limit: int = 6500) -> str:
    """Find a numbered section (not a TOC row) and return body to next section.

    PDF text may include page breaks and indentation. We avoid matching title
    contents and do not turn a mere mention of '4.6' into a section boundary.
    """
    pat = re.compile(rf'(?m)^\s*{re.escape(number)}\.\s+[^\n]{{5,170}}\s*$', re.I)
    matches = list(pat.finditer(text))
    if not matches:
        return ''
    m = matches[-1]
    rest = text[m.end():]
    nxt = re.search(r'(?m)^\s*(?:[1-8]\.\d{1,2}\.|[2-8]\.\s+[А-ЯA-ZЎҚҒҲ])\s+[^\n]{4,150}$', rest)
    return compact(rest[:min(nxt.start() if nxt else len(rest), limit)])


def _match(pattern: str, text: str) -> bool:
    return bool(re.search(pattern, text, re.I | re.S))


def _quote(text: str, pattern: str, window: int = 75) -> str:
    """Short, word-boundary-safe extract; no torn-off fragments in Word."""
    m=re.search(pattern,text,re.I|re.S)
    if not m:return ''
    sample=compact(text[m.start():min(len(text),m.end()+window)])
    if len(sample)>115:
        sample=sample[:116].rsplit(' ',1)[0]
    return sample.rstrip(' ,;:.-')


# Each output is an evidence-backed request for a concrete clarification or
# supporting document, not a claim that the company necessarily broke the law.
# Confidence is intentionally restricted to medium even when pattern matching.
_MESSAGES = {
'accounting_9m': (
    '9 oylik moliyaviy hisobotlar ilova qilinmagan',
    'Biznes-rejada faoliyat 2026-yilni qamrab olgan, lekin ZIPda 2026-yilning 9 oyi uchun balans va moliyaviy natijalar hisoboti alohida aniqlanmadi.',
    '2026-yil 9 oylik buxgalteriya balansi va moliyaviy natijalar hisobotini qo‘shing yoki ular boshqa faylda bo‘lsa sahifasini ko‘rsating.'),
'staffing_capacity': (
    'Bajarilgan loyihalar va IT xodimlari resurslari izohi yetarli emas',
    'Biznes-rejada oz sonli joriy IT mutaxassislari va ko‘p bajarilgan loyihalar/mijozlar qayd qilingan; oldingi loyihalarni kim bajargani va texnik qo‘llab-quvvatlash taqsimoti bo‘yicha aniq dalillar ko‘rinmadi.',
    'Bajarilgan loyihalar davri va turlari, shtat hamda pudratchilar kesimidagi ijrochilar, shartnomalar va texnik qo‘llab-quvvatlash mexanizmini jadval bilan asoslang.'),
'marketing_targets': (
    'Marketing rejasida mijoz jalb qilishning o‘lchanadigan maqsadlari ko‘rsatilmagan',
    'Marketing kanallari va budjeti bayon qilingan, ammo maqsadli auditoriya kesimida yangi buyurtmachilar soni va kanallar bo‘yicha jalb qilish prognozi ajratilmagan.',
    'Har bir kanal uchun auditoriya, rejalangan yangi mijozlar soni, muddat, budjet va natija o‘lchovini kiriting.'),
'saas_stage': (
    'SaaS mahsulotlarining joriy va rejalashtirilgan holati ajratilmagan',
    'O‘z SaaS mahsulotlarini yaratish/ro‘yxatdan o‘tkazish rejasi bor, lekin mavjud prototip, ishga tushirilgan mahsulot va kelajakdagi rejalar aniq ajratilmagan.',
    'Har bir SaaS mahsulotini nomi, joriy tayyorlik darajasi, mavjud dalili, ishlab chiqish bosqichi va ishga tushirish sanasi bilan ko‘rsating.'),
'competitor_benchmark': (
    'Raqobatchilar bo‘yicha aniq qiyosiy tahlil yetishmaydi',
    'Bozor tavsifi va umumiy raqobat ustunliklari bor, lekin nomi ko‘rsatilgan raqobatchilar bilan narx, xizmat yoki imkoniyatlar qiyosiy jadvali ko‘rinmadi.',
    'Kamida bir nechta real raqobatchini nomma-nom ko‘rsating va ular bilan narx, xizmatlar hamda raqobat ustunligini dalilli jadvalda solishtiring.'),
'license_prices': (
    'Litsenziya/texnika daromadi narxlar va faoliyat rejasida izchil ochilmagan',
    'Litsenziya yoki texnika savdosidan tushum prognoz qilingan, ammo xizmatlar narxlari jadvalida ushbu turdagi tovar/tariflar va realizatsiya hajmining asosi ko‘rinmadi.',
    'Mahsulot turi, dona soni, sotib olish va sotish narxi, yetkazib berish xarajati, yalpi foyda va ushbu tushumning IT faoliyatiga aloqadorligini ko‘rsating.'),
'export_partners': (
    'Eksport loyihalari hamkorlar va buyurtmalar bilan asoslanmagan',
    'Eksport loyihalari prognozi va hamkor agentlik/frilans kanallari mavjud, lekin nomma-nom hamkorlar, kelishuvlar yoki potensial buyurtmalar bo‘yicha dalil topilmadi.',
    'Hamkor agentliklar va platformalarni nomlang; mavjud kelishuvlar, dastlabki buyurtmalar yoki potensial xorijiy mijozlar bo‘yicha ma’lumot ilova qiling.'),
'future_tax_assumptions': (
    '2028-yil prognozida soliq imtiyozi farazi asoslanishi kerak',
    'Biznes-rejada 2028-yil uchun imtiyozli soliq rejimi saqlanishi faraz qilingan. Bu prognozdagi soliq xarajatlari uchun qo‘llanish huquqi va muqobil hisobni talab qiladi.',
    '2028-yil imtiyozining huquqiy asosini hujjatlashtiring; zarur bo‘lsa imtiyozsiz ssenariyda ijtimoiy soliq, foyda solig‘i, QQS va boshqa tegishli soliqlarni qayta hisoblang. Stavkalarni amaldagi qonunchilikka ko‘ra tekshiring.'),
'depreciation_basis': (
    'Amortizatsiya hisobining aktivlar kesimidagi asosi yetishmaydi',
    'Moliyaviy rejada umumiy yillik amortizatsiya normasi qo‘llangan, lekin mavjud va xarid qilinadigan asosiy vositalar/nomoddiy aktivlar bo‘yicha hisoblash jadvali ko‘rinmadi.',
    'Har bir aktivni qiymati, foydalanishga topshirish sanasi, guruhi, foydali muddati va tegishli normalarga (Soliq kodeksi 306-modda doirasida) asoslangan amortizatsiya jadvalida ko‘rsating.'),
'financial_reconcile_depreciation': (
    'Amortizatsiya tuzatilgach moliyaviy prognozlarni moslashtirish zarur',
    'Amortizatsiya tannarx, davr xarajatlari, moliyaviy natija, pul oqimi va prognoz balansga ta’sir qiladi; yagona aktivlar kesimidagi hisob yo‘qligi bu jadvallar mosligini isbotlamaydi.',
    'Amortizatsiya jadvali bo‘yicha xarajatlar, sof foyda, pul oqimi va prognoz balansni qayta hisoblang va tengliklarini solishtiring.'),
'lease_agreement': (
    'Ijara xarajatiga asos bo‘luvchi shartnoma ilova qilinmagan',
    'Biznes-rejada ofis ijarasi va oylik to‘lovlar ko‘rsatilgan, lekin ZIPdagi fayllardan ijara shartnomasi aniqlanmadi.',
    'Ijara shartnomasining nusxasini ilova qiling yoki mavjud shartnomani ZIPdagi fayli va sahifasi bilan aniq ko‘rsating.'),
}

RU_TITLES = {
'accounting_9m':'Не представлены финансовые отчеты за девять месяцев',
'staffing_capacity':'Не раскрыты кадровые ресурсы выполненных проектов',
'marketing_targets':'Не определены измеримые цели привлечения клиентов',
'saas_stage':'Не разделены действующие и планируемые SaaS-продукты',
'competitor_benchmark':'Нет предметного сравнения с конкретными конкурентами',
'license_prices':'Доходы от лицензий и техники не увязаны с прайс-листом',
'export_partners':'Экспортный план не подкреплен сведениями о партнерах',
'future_tax_assumptions':'Требуется обосновать налоговый режим прогноза на 2028 год',
'depreciation_basis':'Недостаточно обоснован расчет амортизации',
'financial_reconcile_depreciation':'Требуется увязать прогнозные таблицы после пересчета амортизации',
'lease_agreement':'Не приложен договор аренды',
}
RU_FIXES = {
'accounting_9m':'Приложить бухгалтерский баланс и отчет о финансовых результатах за девять месяцев 2026 года либо указать файл и страницу их расположения.',
'staffing_capacity':'Раскрыть исполнителей прошлых проектов, роль подрядчиков, кадровые ресурсы и порядок технической поддержки.',
'marketing_targets':'Указать целевую аудиторию, план новых заказчиков, каналы, бюджет и сроки для каждого канала.',
'saas_stage':'Разделить действующие разработки, прототипы и планы SaaS по годам, указать этап и подтверждающие материалы.',
'competitor_benchmark':'Назвать реальных конкурентов и сопоставить тарифы, функции и преимущества с подтверждающими данными.',
'license_prices':'Привести товары, тарифы, объемы, закупочные и отпускные цены, маржу и обоснование связи с ИТ-деятельностью.',
'export_partners':'Назвать агентства, платформы, предполагаемых заказчиков и сведения о договоренностях или заявках.',
'future_tax_assumptions':'Подтвердить право на льготы в 2028 году или пересчитать сценарий без льгот с учетом действующего налогового режима.',
'depreciation_basis':'Подготовить расчет амортизации по каждому основному средству и НМА с учетом применимых норм статьи 306 НК.',
'financial_reconcile_depreciation':'Пересчитать расходы, финансовый результат, денежный поток и прогнозный баланс с учетом амортизации.',
'lease_agreement':'Приложить договор аренды или указать точный файл и страницу, где он находится.',
}


def _all_docs_text(files, kinds):
    return ' '.join(f.text for f in files if getattr(f, 'kind', '') in kinds and f.extraction=='ok')


def _has_attachment(files, tokens):
    for f in files:
        if getattr(f,'kind','')=='business_plan': continue
        label=compact(f.path).casefold()
        text=compact(f.text[:650]).casefold()
        if any(re.search(pattern, label+' '+text, re.I) for pattern in tokens):
            return True
    return False


def examine(files: list, issues: list, issue_factory, add_issue, as_of: date | None = None):
    plans=[f for f in files if f.kind=='business_plan' and len(f.text)>600 and f.extraction=='ok']
    findings=[]
    if not plans:return findings
    plan=max(plans,key=lambda f:len(f.text))
    as_of=as_of or date.today()
    fiscal_year=as_of.year
    txt=plan.text
    low=txt.casefold()
    s={n:section(txt,n) for n in ('1.7','1.9','3.3','4.3','4.5','4.6','5.1','5.2','6.1','7.4','7.6','7.7','7.9','7.10','7.11')}
    path=plan.path

    def add(key,section_id,quote='',level='review'):
        title,desc,fix=_MESSAGES[key]
        if key=='accounting_9m' and fiscal_year!=2026:
            desc=desc.replace('2026',str(fiscal_year))
            fix=fix.replace('2026',str(fiscal_year))
        if quote: desc+=' Dalil: «'+compact(quote)[:175]+'».'
        it=issue_factory('expert_'+key,level,title,desc,fix,path,
            'Biznes-reja '+section_id+'-band / hujjatlar to‘plami','medium')
        it['resident_actionable']=True
        it['finding_kind']='clarification' if level=='review' else 'proven_gap'
        it['expert_key']=key
        it['evidence_excerpt']=compact(quote)[:220]
        it['section']=section_id
        add_issue(issues,it)
        findings.append({'id':key,'section':section_id,'strength':it['finding_kind']})

    # Supporting records for the latest available 9-month period. The supplied
    # evaluator benchmark specifically requests 2026 nine-month statements.
    previous_year=fiscal_year-1
    company_operating=_match(rf'(?:{previous_year}.{{0,30}}(?:tashkil|ro.yxat)|{fiscal_year}.{{0,30}}(?:tijorat|faoliyat))',txt)
    nine_month_labels=[rf'balans.{{0,35}}(?:9|{fiscal_year})',rf'(?:9|{fiscal_year}).{{0,40}}balans',
                       rf'молиявий натижа.{{0,40}}{fiscal_year}',
                       rf'финансов.{{0,15}}результат.{{0,40}}{fiscal_year}']
    if (as_of.month>=10 and str(fiscal_year) in txt and company_operating
        and not _has_attachment(files,nine_month_labels)):
        add('accounting_9m','2.1 / 7.9',_quote(txt,rf'{fiscal_year}.{{0,24}}(?:boshlagan|faoliyatini|tijorat)'))

    # Staff vs completed-project throughput: a discrepancy/request for
    # supporting resource data, not a claim that the projects are impossible.
    base=s['1.7'] or txt[:14000]
    # An evidence-bound workload ratio, not an exact 50-project/LENO rule.
    # Only completed projects and CURRENT technical employees are compared.
    completed=re.search(
        r'(?:\b(\d{2,4})\s*(?:dan\s*ortiq|ta|\+)?\s*(?:bajarilgan|yakunlangan|amalga\s*oshirilgan)?\s*(?:IT\s*)?loyih\w*|'
        r'\b(?:более\s+)?(\d{2,4})\s*(?:выполненн\w*|реализованн\w*)?\s*проект\w*)',
        base,re.I)
    workforce=re.search(
        r'\b(\d{1,2})\s*(?:nafar|ta|штатн\w*|человек)?\s*(?:IT[- ]?(?:mutaxassis|xodim|specialist)|frontend[- ]?(?:dasturchi|developer)|dasturchi|разработчик\w*|программист\w*|IT[- ]специалист\w*)',
        base,re.I)
    if not workforce:
        # A current staffing figure can appear in the summary/organizational
        # chapter rather than subsection 1.7. Find a *current* assertion;
        # never mistake the projected 2028 staffing table for today's team.
        candidate_re=re.compile(
            r'\b(\d{1,2})\s*(?:nafar|ta|штатн\w*|человек)?\s*'
            r'(?:IT[- ]?(?:mutaxassis|xodim|specialist)|frontend[- ]?(?:dasturchi|developer)|'
            r'dasturchi|разработчик\w*|программист\w*|IT[- ]специалист\w*)',re.I)
        for candidate in candidate_re.finditer(txt[:30000]):
            context=txt[max(0,candidate.start()-140):candidate.start()].casefold()
            if re.search(r'(?:hozir(?:gi|da)?|mavjud|shtatdagi|shundan|'
                         r'текущ|сейчас|сегодняшн|в штате|из них)',context):
                workforce=candidate
                break
    if not workforce and re.search(r'\b(?:один|одна)\s+IT[- ]специалист',base,re.I):
        staff_count=1
    else:
        staff_count=int(workforce.group(1)) if workforce else None
    project_count=int(next((g for g in completed.groups() if g),0)) if completed else None
    # If a detailed, quantified contractor roster supports the historical
    # projects, do not imply that the current in-house team did them alone.
    contractor_roster=_match(
        r'(?:\d+\s*(?:nafar|ta)\s*(?:pudratch|frilanser|kontraktor)|'
        r'\d+\s*(?:подрядчик|фрилансер)|'
        r'(?:pudratch|подрядчик).{0,45}\d+\s*(?:loyih|проект))',base)
    if (project_count is not None and staff_count is not None
            and project_count>=20 and 0<staff_count<=3
            and project_count/staff_count>=15 and not contractor_roster):
        add('staffing_capacity','1.7 / 6.1',compact(completed.group(0)+'; '+(workforce.group(0) if workforce else 'один IT-специалист')))

    # Marketing: channels and budget are not the same as a numbered new-client
    # acquisition forecast. Do not trigger when the actual target is present.
    marketing=s['4.6'] or s['4.3']
    if marketing and _match(r'(?:Instagram|Telegram|reklama|маркетинг|marketing|advertising)',marketing):
        measurable=_match(r'(?:\d+\s*(?:[-–]\s*\d+)?\s*(?:ta\s+)?(?:yangi\s+)?(?:mijoz|buyurtmach|лидов|клиент|заказчик|интервью|пилотн|lead|pilot|interview)|(?:mijoz|buyurtmach|клиент|заказчик).{0,35}\d+)',marketing)
        growth_commitment=_match(r'(?:yiliga\s*\d{2,}\s*dan\s*ortiq\s*loyiha|\d{2,}\s*dan\s*ortiq\s*loyiha|\d{2,}\s*\+\s*loyiha)',txt[:20000])
        if growth_commitment and not measurable:
            add('marketing_targets','4.6',_quote(marketing,r'(?:Kanallar|Marketing budjeti|Instagram|Telegram)'))

    # SaaS status: mentioning a future registration or rollout does not prove
    # that an existing SaaS already works. Require per-product current status.
    saas=s['1.9']+' '+s['3.3']
    if _match(r'SaaS|саас',saas) and _match(r'2027.{0,16}2028|2027.?2028|rejalashtiril',saas):
        status_details=_match(r'(?:SaaS.{0,160}(?:MVP|prototip|ishga tushirilgan|mavjud mahsulot)|(?:SaaS.{0,100}hozirgi.{0,40}holat))',saas)
        if not status_details:add('saas_stage','1.9 / 3.3',_quote(saas,r'SaaS.{0,100}'))

    # Competitors: a generic phrase 'local IT agencies/freelancers' is not a
    # company-by-company comparison, unless named comparisons are documented.
    compet=s['4.3']
    if compet and _match(r'raqobat|конкурент|competit',compet):
        generic=_match(r'(?:Raqobatchilar\s*[—:-]\s*(?:mahalliy|veb|IT[- ]agentlik|frilanser)|конкуренты\s*[—:-]\s*(?:местные|фриланс))',compet)
        named=_match(r'(?:raqobatchi.{0,130}(?:MChJ|ООО|AJ\b)|сравнени.{0,130}(?:ООО|АО\b))',compet)
        if generic and not named:add('competitor_benchmark','4.3',_quote(compet,r'Raqobatchilar'))

    # Revenue line exists while detailed service price list excludes the goods.
    trade=(s['5.1']+' '+s['5.2']+' '+s['7.7'])
    pricing=s['4.5']
    if _match(r'(?:Litsenziya\s+va\s+texnika|лицензи.{0,15}(?:оборудован|техник))',trade) and pricing:
        if not _match(r'(?:Litsenziya\s+va\s+texnika|texnika\s+savdosi|лицензи.{0,35}(?:оборудован|техник))',pricing):
            add('license_prices','4.5 / 5.1 / 5.2',_quote(trade,r'Litsenziya\s+va\s+texnika'))

    # Export target in unit table; evidence attachments may be legitimate but
    # should explicitly name at least one agency or client/project.
    exporttext=(s['5.1']+' '+s['4.6'])
    if _match(r'(?:shundan\s+eksport|экспортн.{0,30}проект|eksport\s+loyiha)',exporttext) and _match(r'(?:hamkor\s+agentlik|фриланс|frilans)',exporttext):
        named=_match(r'(?:\b(?:Upwork|Fiverr|Toptal|Freelancer\.com)\b|(?:agentlik|партнер).{0,90}(?:MChJ|ООО|LLC))',s['4.6'])
        agreements=_has_attachment(files,[r'(?:экспорт|export|eksport).{0,25}(?:договор|shartnoma|контракт|contract|заявка|заказ)'])
        order_proof=_match(r'(?:eksport.{0,100}(?:imzolangan\s+shartnoma|dastlabki\s+buyurtma|xaridor\s+nomi)|экспорт.{0,100}(?:подписанн.{0,12}договор|предварительн.{0,12}заказ))',s['4.6'])
        if not agreements and not order_proof:
            add('export_partners','4.6 / 5.1',_quote(exporttext,r'eksport.{0,80}'))

    # Never proclaim a particular tax rate legally applicable. We only detect
    # reliance on an exemption for a future period and request a documented
    # legal basis / scenario, following the expert review reference.
    tax=s['7.6']
    if tax and _match(r'2028',tax) and _match(r'(?:2028.{0,140}imtiyoz|imtiyoz.{0,140}2028|2028.{0,120}льгот|льгот.{0,120}2028)',tax):
        if not _match(r'(?:imtiyozsiz|без\s+льгот|alternativ\s+ssenari|2028.{0,90}ijtimoiy\s+soliq\s+12)',tax):
            add('future_tax_assumptions','7.6 / 7.9',_quote(tax,r'2028.{0,115}imtiyoz'))

    # Depreciation: use observed flat rate with no individual asset schedule.
    depreciation=s['7.4']+' '+s['7.7']
    if _match(r'amortizatsiya.{0,40}20\s*%|20\s*%.{0,30}amortizatsiya|амортизац.{0,35}20\s*%',depreciation):
        breakdown=_match(r'(?:har\s+bir\s+aktiv.{0,150}amortizats|амортизац.{0,140}каждого\s+актива|306.modda)',depreciation)
        linked_model=(re.search(r'(?:амортизац|amortizatsiya).{0,180}XLSX',depreciation,re.I)
                      and any(f.suffix in ('.xlsx','.xls','.xltx') for f in files))
        if not breakdown and not linked_model:
            add('depreciation_basis','7.4 / 7.7',_quote(depreciation,r'amortizatsiya.{0,35}20\s*%'))
            if all(s[k] for k in ('7.9','7.10','7.11')):
                add('financial_reconcile_depreciation','7.7 / 7.9–7.11',_quote(s['7.7'],r'amortizatsiya'))

    # Presence of rent expense without a separately discernible lease contract.
    rent=s['6.1']+' '+s['7.7']
    if _match(r'(?:ijara\s+haqi|ofis\s+ijarasi|арендн.{0,25}плат)',rent):
        haslease=_has_attachment(files,[r'(?:ijara|аренд|lease).{0,50}(?:shartnoma|договор|agreement)',
                                        r'(?:shartnoma|договор).{0,50}(?:ijara|аренд)'])
        if not haslease:
            add('lease_agreement','6.1 / 7.7',_quote(rent,r'(?:ijara\s+haqi|ofis\s+ijarasi|арендн.{0,15}плат)'))
    return findings
