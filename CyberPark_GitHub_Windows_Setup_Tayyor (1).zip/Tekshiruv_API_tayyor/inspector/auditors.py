"""Evidence-first, deterministic checks against supplied Cyber Park 2026 samples.

Only test what the parsed data shows. Unreadable, alternative structure, unclear
identity and unsupported tables are review, never a fabricated violation.
"""
from __future__ import annotations
import re
import unicodedata
from collections import Counter
from .requirements_catalog import (BUSINESS_PARTS, SECTION_ALIASES, BUSINESS_SOURCE,
 BUSINESS_TECH_SOURCE, ELIGIBILITY_SOURCE, DOCUMENT_SOURCE, STAFF_ELIGIBILITY)

GROUP_TITLES={'1':'Loyiha rezyumesi','2':'Arizachi ma’lumotlari','3':'Loyiha faoliyati',
              '4':'Bozor va marketing','5':'Ishlab chiqarish/sotish',
              '6':'Tashkiliy reja','7':'Moliyaviy reja','8':'Xulosa'}

def _clean(v):
 return re.sub(r'\s+',' ',unicodedata.normalize('NFKC',str(v)).casefold()).strip()

def _headings(text):
 """Keep only short *lines* resembling headings; avoids number references in prose."""
 headings=[]
 for idx,line in enumerate(text.splitlines()):
  s=line.strip('•· \t')
  if not (4<=len(s)<=155):continue
  m=re.match(r'^(?P<no>[1-8](?:\.\d{1,2}){0,2})\s*\.?[\s:\-–]+(?P<name>.+)$',s)
  if m and len(m.group('name'))>=3:
   headings.append((m.group('no'),idx,s))
 return headings

def business_structure(bplan):
 """Return each original 2026 requirement's status and page; never infer content completeness."""
 if not bplan or len(bplan.text.strip())<120:
  return [{'id':id,'title':title,'source':BUSINESS_SOURCE,'source_page':p,'status':'unreadable','evidence':''}
          for id,title,p in BUSINESS_PARTS]
 headings=_headings(bplan.text)
 lines=bplan.text.splitlines()
 found_numbers={no:(index,heading) for no,index,heading in headings}
 # Content must occur BEFORE the next numbered heading; an outline or
 # table of contents is not evidence that any section is filled out.
 heading_positions=sorted({ix for _,ix,_ in headings})
 results=[]
 for id,title,page in BUSINESS_PARTS:
  data=found_numbers.get(id)
  if not data:
   # Match known original approved alternative heading names only on heading-like lines.
   # Never mark content as complete merely because the term appears in paragraphs.
   aliases=[_clean(s) for s in SECTION_ALIASES.get(id,[])]
   for ix,s in enumerate(lines):
    normalized=_clean(s)
    if len(normalized)<110 and len(normalized)>3 and any((a==normalized or normalized.startswith(a+':')) for a in aliases):
     data=(ix,s.strip());break
  found=bool(data)
  if found:
   ix,heading=data
   stop=next((h for h in heading_positions if h>ix),len(lines))
   # Limit evidence to this section, never count the NEXT section title.
   # A bare subheading and a few symbols are not substantive text.
   body=' '.join(line.strip() for line in lines[ix+1:stop] if line.strip())
   tokens=re.findall(r'[\wа-яёқғҳў]{3,}',body.casefold())
   diversity=len(set(tokens))/max(1,len(tokens))
   repeated=bool(re.search(r'(.{22,85})\1{2,}',body))
   status='found' if len(tokens)>=8 and diversity>=0.22 and not repeated else 'review_content'
   evidence=heading[:125]
  else:status='not_confirmed';evidence=''
  results.append({'id':id,'title':title,'source':BUSINESS_SOURCE,'source_page':page,
                  'status':status,'evidence':evidence})
 return results

def _issue(issues,code,level,title,description,solution,file='',source='',confidence='medium',source_page=None,evidence=''):
 if any(i.get('id')==code for i in issues):return
 item={'id':code,'level':level,'title':title,'description':description,'solution':solution,
       'file':file,'source':source,'confidence':confidence}
 if source_page:item['source_page']=source_page
 if evidence:item['evidence']=evidence[:200]
 issues.append(item)

def bplan_audit(files,issues):
 plans=[f for f in files if f.kind=='business_plan']
 records=[]
 for f in plans:
  checks=business_structure(f)
  records.append({'file':f.path,'sections':checks,
        'found':sum(c['status']=='found' for c in checks),
        'headings_detected':sum(c['status'] in ('found','review_content') for c in checks),
        'total':len(checks)})
  if f.extraction not in ('ok',) or len(f.text)<150:return records
  # One issue per parent chapter to keep human reports short but detailed evidence visible.
  for chapter,label in GROUP_TITLES.items():
   missing=[x for x in checks if x['id'].split('.')[0]==chapter and x['status']!='found']
   if missing:
    detail=', '.join(x['id'] for x in missing)
    _issue(issues,f'structure_{chapter}','review',f'Biznes-reja: {label} tarkibi to‘liq tasdiqlanmadi',
           f'2026-yilgi batafsil talablar bo‘yicha quyidagi bandlarning mavjudligi va to‘ldirilishi aniq tasdiqlanmadi: {detail}. Boshqa tasdiqlangan shaklda bo‘lishi mumkin.',
           'Ko‘rsatilgan bandlar mazmunini asl manbadagi talablar bilan solishtiring; mavjud bo‘lsa xodim tasdiqlasin.',
           f.path,BUSINESS_SOURCE,'medium',missing[0]['source_page'])
  # If the field label + long blank occurs on same line, evidence supports a warning.
  for idx,line in enumerate(f.text.splitlines()):
   if len(line)>260:continue
   if re.search(r'(?:[А-Яа-яЁёЎўҒғҚқҲҳA-Za-z]{3,}[^\n]{0,90}:)\s*(?:_{5,}|\.{7,}|…{3,})',line):
    _issue(issues,'blank_fields','review','Biznes-rejada bo‘sh shablon maydonlari bo‘lishi mumkin',
      f'Bo‘sh maydon shabloni topildi (matn qatori {idx+1}).',
      'Asl sahifani ochib tekshiring; bu chiziq ajratgich emasligini tasdiqlang.',
      f.path,BUSINESS_TECH_SOURCE,'medium',2,line.strip()[:160]);break
  # Source requires title page date, approval signature, period and calculation currency.
  preview='\n'.join(f.text.splitlines()[:85])
  if not re.search(r'(?:20\d\d|\d{1,2}[./]\d{1,2}[./]\d{2,4})',preview):
   _issue(issues,'title_date','review','Biznes-reja titulidagi tasdiqlash sanasi tekshirilsin',
     'Titul qismida aniq sana avtomatik ajratilmadi.',
     'Tituldagi tasdiqlangan sanani va imzoni asl nusxada tekshiring.',f.path,BUSINESS_TECH_SOURCE,'medium',2)
  if not re.search(r'(?:сум|so.m|so‘m|руб|usd|uzs|доллар|евро|ming|млн|тыс\.)',_clean(f.text)):
   _issue(issues,'finance_currency','review','Moliyaviy jadvallar valyutasi aniqlanmadi',
     'Hujjat matnidan hisob-kitob valyutasi ajratilmadi; jadval yoki ilovada bo‘lishi mumkin.',
     'Moliyaviy jadvalning valyutasi va birlik ko‘paytuvchisini tekshiring.',f.path,BUSINESS_TECH_SOURCE,'medium',2)
 return records

def _money(s):
 s=str(s).strip().replace('\u00a0',' ').replace('−','-').replace('–','-')
 if not s or re.search(r'[%:/]|20\d{2}\s*г',s):return None
 # Only cells entirely numeric with optional grouping. Ignore dates and headings.
 if not re.fullmatch(r'-?(?:\d{1,3}(?:[\s.,]\d{3})+|\d+)(?:[.,]\d{1,2})?',s):return None
 if '.' in s and ',' in s:
  if s.rfind(',')>s.rfind('.'):s=s.replace('.','').replace(',','.')
  else:s=s.replace(',','')
 elif ',' in s:
  s=s.replace(',','.') if len(s.split(',')[-1])<=2 else s.replace(',','')
 elif '.' in s and len(s.split('.')[-1])==3:s=s.replace('.','')
 return float(s.replace(' ',''))

# Table row labels are deliberately scoped to *same table*, not neighboring sections.
FIN_LABELS={
 'exports':('доход от экспорта','доходы от экспорта','поступления от экспорта','экспортдан даромад','eksportdan daromad'),
 'local':('доход на внутреннем','доходы на внутреннем','внутреннего рынка','ichki bozordan','ички бозордан'),
 'revenue':('общая выручка','всего поступления','валовая выручка','jami tushum','умумий тушум'),
 'inflow':('приток средств','поступления денежных средств','jami kirim'),
 'outflow':('отток средств','jami chiqim'),
 'net_cash':('чистый денежный поток','sof pul oqimi'),
 'gross_profit':('валовая прибыль','yalpi foyda'),
 'net_profit':('чистая прибыль','sof foyda'),
 'cost':('себестоимость','tannarx'),
}

def _classify(label):
 s=_clean(label)
 for key,vals in FIN_LABELS.items():
  if any(v in s for v in vals):return key
 return None

def _same(a,b):
 return abs(a-b)<=max(0.02,abs(b)*0.0001)

def financial_audit(files,issues):
 """Validate exact arithmetic only on trustworthy same-table numeric row layouts.
    Never recompute user formulas or infer missing values from prose.
 """
 results=[]
 for f in files:
  if f.kind not in ('business_plan','business_appendix'):continue
  for t_idx,table in enumerate(getattr(f,'tables',[])[:100]):
   rows={}
   for row in table:
    if len(row)<3:continue
    label=_classify(row[0]); nums=[_money(v) for v in row[1:]]
    if label and sum(x is not None for x in nums)>=2 and label not in rows:rows[label]=nums
   for formula,(a,b,c) in {
       'revenue_sum':('exports','local','revenue'),
       'net_cash':('inflow','outflow','net_cash')
     }.items():
    if not all(k in rows for k in (a,b,c)):continue
    periods=min(len(rows[a]),len(rows[b]),len(rows[c]))
    checked=0
    for col in range(periods):
     va,vb,vc=rows[a][col],rows[b][col],rows[c][col]
     if any(v is None for v in (va,vb,vc)):continue
     checked+=1
     expected=va+vb if formula=='revenue_sum' else va-vb
     if not _same(expected,vc):
      desc=f'Jadval {t_idx+1}, davr ustuni {col+1}: kutilgan {expected:g}, ko‘rsatilgan {vc:g}. Raqamlar bir jadvaldan olindi.'
      _issue(issues,f'finance_{formula}_{f.path}_{t_idx}_{col}','review',
          'Moliyaviy jadvalda arifmetik nomuvofiqlik ehtimoli',desc,
          'Jadvaldagi valyuta va davr ustunini tekshirib, yig‘indini qayta hisoblang.',
          f.path,BUSINESS_SOURCE,'high',22 if formula=='revenue_sum' else 25)
    if checked:results.append({'file':f.path,'table':t_idx+1,'formula':formula,'periods_checked':checked})
 return results

def eligible_code(code):
 """Only broad classes listed in user's 'ОСНОВНЫЕ ТРЕБОВАНИЯ' PDF.
  85 requires specific IT education and 50% income; no auto acceptance.
 """
 if not code or not re.fullmatch(r'\d{5}',code):return 'unknown'
 if code.startswith('26') or code.startswith('62'):return 'potential'
 if code.startswith(('582','631','721')):return 'potential'
 if code.startswith('85'):return 'it_education_only'
 return 'not_listed'

def eligibility_audit(files,issues):
 from .engine import _extract_stir
 oks=[]
 for f in files:
  if f.kind not in ('application','business_plan','questionnaire','charter'):continue
  vals=re.findall(r'\b(?:ОКЭД|ОКЕД|OKED|IFUT|ИФУТ)\b[^\d\n]{0,20}(\d{5})(?!\d)',f.text,re.I)
  if len(set(vals))==1:oks.append({'file':f.path,'oked':vals[0],'category':eligible_code(vals[0])})
 for rec in oks:
  if rec['category'] in ('not_listed','it_education_only'):
   txt=('Asosiy OKED berilgan faoliyat ro‘yxatiga kirmayotgandek. Biroq real faoliyat va tushum ulushini tekshirmasdan xulosa chiqarib bo‘lmaydi.' if rec['category']=='not_listed' else
        '85 guruhi IT va kiberxavfsizlik ta’limi bo‘lsa ruxsat etilishi mumkin. Haqiqiy o‘quv mazmuni hamda tushum ulushini tekshiring.')
   _issue(issues,f'oked_scope_{rec["oked"]}','review',f'OKED {rec["oked"]}: faoliyat doirasi tekshirilsin',txt,
      'Rasmiy faoliyat turini va Cyber Park yo‘nalishlari tushum ulushini (kamida 50%) tasdiqlang.',
       rec['file'],ELIGIBILITY_SOURCE,'medium',1)
 return oks

def audit(files,issues):
 return {'structure':bplan_audit(files,issues),
         'finance':financial_audit(files,issues),
         'oked':eligibility_audit(files,issues),
         'eligibility_staff':[{'id':id,'title':title,'source':s,'source_page':p} for id,title,s,p in STAFF_ELIGIBILITY]}
