"""Grounded applicant-facing explanations derived from the actual local rule findings.

Never promote OCR/model uncertainties into violations. This is an evidence renderer,
not an LLM hallucination layer. The source ZIP is never mutated or transmitted.
"""
from __future__ import annotations
import os
import re
from pathlib import PurePosixPath


def _simple_name(path: str) -> str:
    return PurePosixPath(str(path or '').replace('\\', '/')).name


def resident_items(result: dict) -> list[dict]:
    """Return confirmed defects and narrowly supported applicant clarification requests."""
    lang = result.get('language', 'uz_lat')
    ru = lang == 'ru'
    out = []
    seen = set()
    for finding in result.get('issues', []):
        if finding.get('level') != 'error' and not finding.get('resident_actionable'):
            continue
        identity = finding.get('id', '')
        if identity in seen:
            continue
        seen.add(identity)
        file = str(finding.get('file') or '')
        evidence = str(finding.get('description') or '').strip()
        source = str(finding.get('source') or '').strip()
        title = str(finding.get('title') or '').strip()
        remedy = str(finding.get('solution') or '').strip()
        if identity.startswith('expert_') and ru:
            from .expert_dossier import RU_TITLES, RU_FIXES
            key=identity.removeprefix('expert_')
            title=RU_TITLES.get(key,title)
            remedy=RU_FIXES.get(key,remedy)
            excerpt=str(finding.get('evidence_excerpt') or '').strip()
            evidence=('В разделах бизнес-плана выявлено требование дополнительного обоснования; '
                      'конкретные сведения или приложение не подтверждены представленным комплектом.'
                      + (' Фрагмент: «'+excerpt+'».' if excerpt else ''))
        if identity.startswith('zero_byte_'):
            name = _simple_name(file)
            social = bool(re.search(r'(?:social|ijtimoiy|tarmoq|соц|havola)', file, re.I))
            title = 'Пустой файл (0 байт)' if ru else 'Bo‘sh fayl (0 bayt)'
            evidence = (f'Файл «{name}» в архиве имеет размер 0 байт, данные отсутствуют.' if ru
                        else f'ZIP ichidagi «{name}» fayli 0 bayt. Unda hech qanday ma’lumot yo‘q.')
            if social:
                remedy = ('Заполните файл ссылками на социальные сети либо прямо укажите, что социальные сети отсутствуют; вложите исправленный документ в ZIP.' if ru else
                          'Faylga ijtimoiy tarmoq havolalarini kiriting yoki mavjud emasligini aniq qayd eting. To‘ldirilgan faylni ZIPga qo‘shing.')
            else:
                remedy = ('Представьте заполненную и открываемую версию. Если файл ошибочно вложен, удалите пустой дубликат из ZIP.' if ru else
                          'To‘ldirilgan va ochiladigan nusxani taqdim eting; ortiqcha nusxa bo‘lsa, bo‘sh faylni ZIPdan olib tashlang.')
            source = 'Размер: 0 байт' if ru else 'Fayl hajmi: 0 bayt'
        elif identity == 'missing_questionnaire' and ('papkasi bo‘sh' in evidence or 'papka' in evidence.lower()):
            title = 'Не заполнена папка с анкетой' if ru else 'Nomzod anketasi papkasi bo‘sh'
            evidence = ('В ZIP папка «5. Belgilangan shakldagi nomzod anketasi» не содержит файлов.' if ru else
                        'ZIPdagi «5. Belgilangan shakldagi nomzod anketasi» papkasida fayl yo‘q.')
            remedy = ('Добавьте заполненную анкету по утверждённому образцу, включая редактируемый документ Word.' if ru else
                      'Tasdiqlangan shablon asosida to‘ldirilgan anketani va uning Word nusxasini ZIPga qo‘shing.')
        elif identity == 'banner_dimensions':
            match = re.search(r'(\d+)\s*[×xх]\s*(\d+)', evidence)
            measured = f'{match.group(1)}×{match.group(2)}' if match else None
            title = 'Размер баннера не соответствует требованию' if ru else 'Banner o‘lchami noto‘g‘ri'
            evidence = (f'Фактический размер: {measured} пикселей, по применяемому правилу требуется 1192×226.' if ru else
                        f'Bannerning haqiqiy o‘lchami {measured}, qo‘llanilayotgan talab 1192×226 piksel.') if measured else evidence
            remedy = ('Представьте баннер 1192×226 пикселей в папке с баннером.' if ru else
                      'Bannerni 1192×226 piksel o‘lchamda tayyorlab, tegishli papkaga joylang.')
        elif identity == 'logo_format':
            title = 'Неверный формат логотипа' if ru else 'Logotip formati noto‘g‘ri'
            remedy = ('Приложите логотип в PNG или SVG.' if ru else 'Logotipni PNG yoki SVG formatida yuklang.')
        elif identity.startswith('blank_'):
            title = ('Незаполненный документ' if ru else title or 'To‘ldirilmagan hujjat')
            if ru: evidence='В документе обнаружены незаполненные обязательные поля либо отсутствует пригодное для проверки содержимое.'
            remedy = ('Заполните обязательные поля по образцу и приложите открываемую версию документа.' if ru else
                      remedy or 'Namunaga ko‘ra majburiy maydonlarni to‘ldiring va ochiladigan nusxani ZIPga qo‘shing.')
        elif identity=='questionnaire_word' and ru:
            title='Не представлена редактируемая анкета Word'
            evidence='Согласно перечню документов требуется заполненная анкета в редактируемом формате Word.'
            remedy='Приложите заполненную анкету в формате DOCX.'
        elif identity.startswith('empty_social_') and ru:
            title='Не заполнены сведения о социальных сетях'
            evidence='Приложенный документ не содержит ссылок на социальные сети или пометки об их отсутствии.'
            remedy='Укажите ссылки на соцсети либо отметьте, что они отсутствуют.'
        elif identity.startswith('missing_'):
            # Only genuinely proven absence should have level=error; other missing
            # items live in the internal uncertainty list, never in this section.
            if ru:
                from .report import RU_KINDS
                part=identity.removeprefix('missing_')
                specific=RU_KINDS.get(part, {'info':'Информация о компании','questionnaire':'Анкета'}.get(part,'Документ'))
                title = 'Не представлен обязательный документ: ' + specific
                evidence = 'В архиве подтверждено отсутствие обязательного документа по применяемому перечню.'
                remedy = 'Добавьте заполненный документ в ZIP в соответствии с перечнем.'
            else:
                remedy = remedy or 'Majburiy hujjatni ZIPga ilova qiling.'
        elif ru and identity.startswith('finance_v4_'):
            title='Арифметическое расхождение в финансовой таблице'
            # Actual numeric source values remain attached and never translated
            # into invented numbers by the model.
            raw=str(finding.get('description') or '')
            match=re.search(r'Jadval (\d+), ustun (\d+): hisoblangan ([0-9.eE+-]+), hujjatda ([0-9.eE+-]+)',raw)
            evidence=(f'Таблица {match.group(1)}, столбец {match.group(2)}: расчётное значение {match.group(3)}, '
                      f'указанное значение {match.group(4)}. Расчёт выполнен по строкам одной таблицы.' if match else raw)
            source='Финансовая таблица — локальная арифметическая проверка'
            remedy='Проверьте указанную таблицу и период, исправьте расчёт или поясните единицы измерения.'
        elif ru:
            # Deterministic, finite RU phrases from the existing rules.  Preserve
            # source evidence, not speculative translations of arbitrary OCR text.
            from .report import ru_issue
            title, translation, fix = ru_issue(finding)
            if translation:
                evidence = translation
            if fix and not re.search('вручную|специалист', fix, re.I):
                remedy = fix
        # All remaining error types retain their local evidence and prescribed
        # correction from the ruleset. Never emit an empty/unverifiable solution.
        if not remedy:
            remedy = ('Приложите исправленный документ по указанному требованию.' if ru else
                      'Ko‘rsatilgan talab bo‘yicha tuzatilgan hujjatni ZIPga qo‘shing.')
        if lang == 'uz_cyrl':
            from .locale import localize_generated
            protected=(_simple_name(file), file, source)
            title=localize_generated(title,lang,preserve=protected)
            evidence=localize_generated(evidence,lang,preserve=protected)
            remedy=localize_generated(remedy,lang,preserve=protected)
            if not re.search(r'\.(?:pdf|docx|doc|xls|xlsx|png|jpg|jpeg|zip)$',source,re.I):
                source=localize_generated(source,lang,preserve=(_simple_name(file),file))
        out.append({
            'id': identity, 'title': title, 'evidence': evidence,
            'fix': remedy, 'file': file, 'source': source,
            'source_page': finding.get('source_page'), 'confidence': ('supported_clarification' if finding.get('resident_actionable') and finding.get('level')!='error' else 'confirmed'),
        })
    return out


def report_overview(result: dict) -> dict:
    """UI-friendly automated explanation; independent of any human writing."""
    defects = resident_items(result)
    return {
        'files': int(result.get('files_count') or len(result.get('documents', []))),
        'passed': int(result.get('passed_files') or 0),
        'defects_count': len(defects),
        'defects': defects,
        'has_unverified_items': any(x.get('level') == 'review' for x in result.get('issues', [])),
        'meaning': ('Предварительная техническая проверка; не полная юридическая или экономическая экспертиза.' if result.get('language')=='ru' else
                    'Техник дастлабки текширув; тўлиқ ҳуқуқий ёки иқтисодий экспертиза эмас.' if result.get('language')=='uz_cyrl' else
                    'Texnik dastlabki tekshiruv natijasi; to‘liq huquqiy yoki iqtisodiy ekspertiza emas.'),
    }
