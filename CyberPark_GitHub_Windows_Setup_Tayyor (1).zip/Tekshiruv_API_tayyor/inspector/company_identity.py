"""Applicant identity from trusted local documents, without relying on ZIP name."""
from __future__ import annotations
import re
from collections import defaultdict

LEGAL = r'(?:M\s*[.\s-]*Ch\s*[.\s-]*J|МЧЖ|ООО|O[‘\']?zbek(?:iston)?|LLC|MChJ)'
LEGAL_HINT = re.compile(r'(?:\bООО\b|\bMChJ\b|\bМЧЖ\b|\bLLC\b|\bОбщество с ограниченной ответственностью\b)',re.I)
CANDIDATES=(
 re.compile(r'(?:\bООО\b|\bMChJ\b|\bМЧЖ\b|\bLLC\b)\s*[«"“](.{3,90}?)[»"”]',re.I),
 re.compile(r'[«"“](.{3,90}?)[»"”]\s*(?:MChJ|МЧЖ|ООО|LLC)\b',re.I),
 re.compile(r'(?:корхона\s+номи|компания\s+номи|наименование\s+организации|название\s+компании|название\s+организации|tashkilot\s+nomi)\s*[:—-]\s*(.{3,95})',re.I),
)
BAD = ('приложени','бизнес','план','анкета','устав','заявление','договор','заголов','свидетельство','наименование','korxona','компания','company','ariza','nomi','misol')
PRIORITY={'certificate':6,'application':5,'charter':4,'questionnaire':3,'company_info':3,'business_plan':1}

def normalize(v):
 return re.sub(r'\s+',' ',v.strip(' «»"“”\t.,:;')).strip()

def identify_applicant(files, archive_label=''):
 scores=defaultdict(int); sources=defaultdict(list); displayed={}
 for f in files:
  if f.kind not in PRIORITY or f.extraction not in ('ok','partial') or not f.text:continue
  # Company registration text is usually near the beginning, but must avoid
  # names mentioned as customers/competitors in a business plan.
  text=f.text[:5500] if f.kind!='business_plan' else f.text[:1200]
  for pattern in CANDIDATES:
   for m in list(pattern.finditer(text))[:8]:
    v=normalize(m.group(1).split('\n')[0])
    if not 3<=len(v)<=90 or any(v.casefold().startswith(x) for x in BAD) or re.fullmatch(r'[0-9\W]+',v):continue
    if re.search(r'\b(?:согласно|представлен|шартнома|улов|в составе|qayd)\b',v,re.I):continue
    key=v.casefold()
    score=PRIORITY[f.kind]
    if f.kind=='business_plan':
     near=text[max(0,m.start()-65):m.end()+25]
     if not LEGAL_HINT.search(near):continue
     # Applicant's title-page director explicitly naming the LLC is stronger
     # than a mere customer / partner mention in a later paragraph.
     if m.start()<400 and re.search(r'(?:Директор|директор|direktor|director|УТВЕРЖДАЮ)',near,re.I):
      score=7

    if f.path not in sources[key]:sources[key].append(f.path); scores[key]+=score
    displayed[key]=v
 best=sorted(scores,key=lambda k:(scores[k],len(sources[k])),reverse=True)
 if best and (scores[best[0]]>=6 or len(sources[best[0]])>=2):
  key=best[0]
  if len(best)>1 and scores[best[1]]==scores[key]:
   return None,{'status':'conflict','candidates':len(best),'source_files':sources[key][:3]}
  return displayed[key],{'status':'document_derived','source_files':sources[key][:4],'cross_document_matches':len(sources[key])}
 return None,{'status':'unverified','source_files':[],'archive_label':archive_label}
