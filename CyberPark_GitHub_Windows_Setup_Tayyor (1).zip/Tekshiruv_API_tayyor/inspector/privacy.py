"""Local encrypted audit fields. Windows: AES-GCM key wrapped with current-user DPAPI.
No external server or third-party KMS. Existing unprotected history is migrated on startup.
"""
import base64
import ctypes
import hashlib
import hmac
import os
import secrets
import threading
from pathlib import Path
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

_LOCK=threading.RLock()
_KEY=None
PREFIX='cp5:'

if os.name=='nt':
    from ctypes import wintypes
    class BLOB(ctypes.Structure):
        _fields_=[('cbData',wintypes.DWORD),('pbData',ctypes.POINTER(ctypes.c_byte))]
    def _dpapi(content,protect):
        input_buffer=ctypes.create_string_buffer(content)
        input_blob=BLOB(len(content),ctypes.cast(input_buffer,ctypes.POINTER(ctypes.c_byte)))
        output_blob=BLOB()
        api=ctypes.windll.crypt32.CryptProtectData if protect else ctypes.windll.crypt32.CryptUnprotectData
        api.restype=wintypes.BOOL
        api.argtypes=[ctypes.POINTER(BLOB),ctypes.c_wchar_p,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,wintypes.DWORD,ctypes.POINTER(BLOB)]
        ctypes.windll.kernel32.LocalFree.argtypes=[ctypes.c_void_p]
        ctypes.windll.kernel32.LocalFree.restype=ctypes.c_void_p
        # DPAPI chooses only the logged-in Windows user (no machine-wide flag).
        ok=api(ctypes.byref(input_blob),None,None,None,None,0,ctypes.byref(output_blob))
        if not ok:raise OSError('Windows DPAPI kaliti ochilmadi: Windows foydalanuvchi profili tekshirilsin')
        try:return ctypes.string_at(output_blob.pbData,output_blob.cbData)
        finally:ctypes.windll.kernel32.LocalFree(output_blob.pbData)
else:
    def _dpapi(content,protect):return content


def key(data_dir):
    global _KEY
    with _LOCK:
        if _KEY is not None:return _KEY
        path=Path(data_dir)/'history.key.dpapi'
        if path.exists():
            material=path.read_bytes()
            k=_dpapi(material,False)
        else:
            k=secrets.token_bytes(32)
            path.parent.mkdir(parents=True,exist_ok=True)
            descriptor=os.open(str(path),os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
            try:
                with os.fdopen(descriptor,'wb') as out:out.write(_dpapi(k,True))
            except Exception:
                path.unlink(missing_ok=True)
                raise
        if len(k)!=32:raise ValueError('Tarixni shifrlash kaliti yaroqsiz')
        _KEY=k
        return k


def seal(value,data_dir):
    if value is None:return None
    plain=str(value).encode('utf-8')
    iv=secrets.token_bytes(12)
    encrypted=AESGCM(key(data_dir)).encrypt(iv,plain,b'CyberPark-Audit-v5')
    return PREFIX+base64.urlsafe_b64encode(iv+encrypted).decode('ascii')


def unseal(value,data_dir):
    if value is None:return None
    if not isinstance(value,str) or not value.startswith(PREFIX):return value # legacy migrated on startup
    data=base64.urlsafe_b64decode(value[len(PREFIX):])
    return AESGCM(key(data_dir)).decrypt(data[:12],data[12:],b'CyberPark-Audit-v5').decode('utf-8')


def index(value,data_dir):
    return hmac.new(key(data_dir),str(value or '').encode('utf-8'),hashlib.sha256).hexdigest()


def protection_status():
    return 'Windows current-user DPAPI + AES-256-GCM' if os.name=='nt' else 'AES-256-GCM, file-based key (non-Windows development only)'
