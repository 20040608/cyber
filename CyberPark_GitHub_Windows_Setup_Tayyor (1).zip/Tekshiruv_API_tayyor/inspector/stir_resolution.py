"""Conservative, LOCAL applicant STIR resolution (no network calls).

Only 9-digit numbers with explicit tax-ID markers are candidates.  A contract
may contain several parties' STIRs; it is unsafe to choose the first one.
"""
from __future__ import annotations
import re
import os
import unicodedata
from collections import defaultdict

_LABEL = r'(?:STIR|СТИР|INN|ИНН|TIN|СТНН)'
_DESC = r'(?:\s+(?:предприятия|организации|корхона(?:нинг)?|компании|юридического\s+лица))?'
_NUMBER = r'(?<!\d)(\d{9})(?!\d)'
# Includes multilingual combined headings e.g. "STIR / ИНН / TIN 312065846".
_AFTER = re.compile(r'(?<!\w)' + _LABEL + r'\b(?:\s*[/,|]\s*' + _LABEL + r'\b){0,3}' + _DESC + r'\s*(?:[:№#=\-–]\s*)?' + _NUMBER, re.I)
# Uzbekistan's tax notices often say "312065846 -sonli STIR raqam".
_BEFORE = re.compile(_NUMBER + r'\s*(?:[-–]\s*(?:sonli|сонли)\s*)?(?:raqam\s*)?(?:' + _LABEL + r')\b',re.I)
# Heading and figure may be on adjacent lines; no unlimited intervening prose.
_LOOSE_AFTER = re.compile(r'(?<!\w)' + _LABEL + r'\b(?:\s*[/,|]\s*' + _LABEL + r'\b){0,3}' + _DESC + r'[\s:№#=\-–]{1,38}' + _NUMBER,re.I)


def labeled_stirs(text):
    """Return (number, offset), excluding bank account substrings and PINFLs."""
    found={}
    for rx in (_AFTER,_BEFORE,_LOOSE_AFTER):
        for m in rx.finditer(text or ''):
            number=m.group(1)
            if number == '000000000':continue
            found[(number,m.start(1))]=None
    return list(found)


def _company_regex(company):
    parts=[p for p in re.findall(r'[\wа-яёқғҳў]+',unicodedata.normalize('NFKC',company or '').lower())
           if len(p)>2 and p not in ('mchj','ооо','ooo','групп','group','ltd','the')]
    if not parts:return None
    # Two distinctive first words, so even "MILLIY POCHTA TO`LOVLARI" is recognized.
    use=parts[:2] if len(parts)>1 else parts[:1]
    return re.compile(r'\b'+r'[\W_]+'.join(re.escape(p) for p in use)+r'\b',re.I)


def resolve_stir(files,company):
    """Return (STIR or None, evidence or None, conflicts).

    Candidate needs applicant-linked evidence; avoid choosing a number from
    a supplier-only invoice, director passport, or unlabeled 9-digit field.
    """
    target=_company_regex(company)
    scores=defaultdict(float)
    traces=defaultdict(list)
    core={'application','questionnaire','business_plan','company_info','charter','certificate'}
    for doc in files:
        text=getattr(doc,'text','') or ''
        if not text:continue
        candidates=labeled_stirs(text)
        if not candidates:continue
        path=getattr(doc,'path','')
        kind=getattr(doc,'kind','')
        name_hits=[m.start() for m in target.finditer(text)] if target else []
        # PDF text extraction can preserve two-column contracts as lines with
        # indentation. Pair the applicant's "Номи" column with the STIR label
        # in that same column, never the other contractual party's STIR.
        column_numbers=set()
        if target:
            lines=text.splitlines(keepends=True)
            company_columns=[];cursor=0
            for line_idx,line in enumerate(lines):
                if target.search(line):
                    marker=list(re.finditer(r'(?:Номи\s*:|Наименование\s*:|Nomi\s*:)',line,re.I))
                    if marker:
                        company_columns.append((line_idx,marker[-1].start()))
                cursor+=len(line)
            cursor=0
            for line_idx,line in enumerate(lines):
                for label_match in re.finditer(r'(?:СТИР|STIR|ИНН|INN)\s*:\s*(\d{9})(?!\d)',line,re.I):
                    if any(0<=line_idx-target_line<=35 and abs(label_match.start()-col)<=10
                           for target_line,col in company_columns):
                        column_numbers.add(label_match.group(1))
        # Official applicant permits can be named unpredictably and classified as
        # 'other'. Their own contents should still count if they name the applicant.
        official_permit=bool(re.search(r'(?:рухсатнома|ruhsatnoma|ruxsatnoma|ruxsat|litsenziya|разрешени|лицензи|license|permit)',path,re.I))
        # A core applicant document is more reliable than a third-party contract.
        for number,pos in candidates:
            # The applicant name must precede the number; a party mentioned
            # *after* the partner's STIR does not make that earlier STIR theirs.
            distance=min((pos-p for p in name_hits if p<=pos),default=999999)
            nearby=distance<=210 or number in column_numbers
            in_doc=bool(name_hits)
            if kind not in core and not nearby and not ((kind=='license' or official_permit) and in_doc):
                # A loose partner STIR must not be mistaken for applicant STIR.
                # Official tax notices without company name can corroborate other evidence.
                if not re.search(r'(?:^|[/\\])(TAX|SOLIQ|СОЛИҚ|НАЛОГ)',path,re.I):
                    continue
            weight=3
            if kind in core:weight+=5
            if nearby:weight+=7
            elif in_doc:weight+=2
            if (kind=='license' or official_permit) and in_doc:weight+=3
            if re.search(r'(?:^|[/\\])(TAX|SOLIQ|СОЛИҚ|НАЛОГ)',path,re.I) and len(set(n for n,_ in candidates))==1:
                weight+=3
            scores[number]+=weight
            traces[number].append({'file':path,'kind':kind or 'other','near_company':nearby,'score':weight})
    if not scores:return None,None,[]
    ordered=sorted(scores,key=lambda n:scores[n],reverse=True)
    best=ordered[0]
    evidence=traces[best]
    # One high-confidence applicant-linked document, or independent corroboration.
    anchored=any(x['near_company'] or x['kind'] in core for x in evidence)
    supported=len({x['file'] for x in evidence})>=2
    if scores[best]<8 or not (anchored or supported):return None,None,ordered
    if len(ordered)>1 and scores[ordered[1]]>=scores[best]-3:return None,None,ordered
    return best,{'file':evidence[0]['file'],'sources':len(evidence),'verified_by':'labeled_applicant_documents','other_candidates':len(ordered)-1},ordered[1:]
