"""Conservative file-level verification; parsing success is not compliance."""
from __future__ import annotations
import re
CORE={'application','charter','certificate','business_plan','questionnaire','director_order','contract','company_info'}

RULES={
 'application':(r'(?i)(?:ариза|заявлени|заявка)',r'(?i)(?:резидент|rezident|Cyber\s*Park|кибер|kiber)'),
 'charter':(r'(?i)(?:устав|ustav|низом)',r'(?i)(?:уставн|та[ъ’]?сис|общество|жамият|учредител)'),
 'certificate':(r'(?i)(?:свидетельств|guvohnoma|гуво[ҳх]нома|р[ўо]йхат)',r'(?i)(?:регистрац|р[ўо]йхат|ИНН|STIR|ОГРН)'),
 'questionnaire':(r'(?i)(?:анкета|anketa)',r'(?i)(?:директор|direktor|руководител|фамили|исм|имя|телефон)'),
 'director_order':(r'(?i)(?:приказ|буйруқ|buyruq)',r'(?i)(?:назнач|тайин|tayin)'),
 'contract':(r'(?i)(?:договор|шартнома|оферта|oferta)',r'(?i)(?:услуг|хизмат|сторон|томонлар)'),
 'company_info':(r'(?i)(?:компания|корхона|tashkilot|организац)',r'(?i)(?:хизмат|услуг|narx|цен|фаолият|деятельност)'),
}

def assess_file(f,issues,detailed):
 if f.size==0:return 'defect'
 if f.extraction!='ok' or f.quality!='content_present':return 'incomplete'
 if any(x.get('level')=='error' and x.get('file')==f.path for x in issues):return 'defect'
 if any(x.get('level')=='review' and x.get('file')==f.path for x in issues):return 'incomplete'
 # Restricted checks with objective evidence, not just filename/length.
 if f.kind in RULES:
  # The historical two-keyword check does not verify all template fields.
  # Do not label the whole legal document as passed on this thin evidence.
  return 'incomplete'
 if f.kind=='business_plan':
  plans=[p for p in detailed.get('structure',[]) if p.get('file')==f.path]
  # A plan can use an approved alternative structure, but headings alone are
  # NOT evidence of filling out the required substantive sections.
  return 'validated' if any(p.get('verified_complete',0)>=8 for p in plans) else 'incomplete'
 if f.kind=='banner':return 'validated' if (f.width,f.height)==(1192,226) else 'incomplete'
 if f.kind=='logo':return 'incomplete'  # File extension alone is not content verification
 return 'incomplete'
