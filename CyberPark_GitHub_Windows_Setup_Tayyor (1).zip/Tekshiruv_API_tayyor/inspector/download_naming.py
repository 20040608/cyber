"""Safe company-and-inspection-date filenames for all report downloads.

The inspection date is rendered in Uzbekistan time (UTC+05:00) from the
persisted created_at timestamp, so downloading historical reports later
never silently changes their names.
"""
from datetime import datetime, timedelta, timezone
from urllib.parse import quote
import re
import unicodedata

UZ_TIMEZONE = timezone(timedelta(hours=5))
_BAD_WINDOWS_CHARS = re.compile(r'[<>:"/\\|?*\x00-\x1f\x7f]')
_SPACES = re.compile(r'\s+')
_WINDOWS_RESERVED = {'CON', 'PRN', 'AUX', 'NUL', *(f'COM{i}' for i in range(1, 10)), *(f'LPT{i}' for i in range(1, 10))}


def safe_company_name(value):
    """Preserve Uzbek Latin/Cyrillic names without allowing a path filename."""
    name=unicodedata.normalize('NFC',str(value or 'Korxona'))
    # A company name is a label, not a filesystem path. Replace unsafe symbols.
    name=_BAD_WINDOWS_CHARS.sub('_',name)
    name=_SPACES.sub(' ',name).strip(' ._')
    name=name[:95].rstrip(' ._') or 'Korxona'
    if name.upper() in _WINDOWS_RESERVED:
        name='Korxona_'+name
    return name


def inspection_date(record):
    raw=str(record.get('created_at') or '')
    if raw:
        try:
            when=datetime.fromisoformat(raw.replace('Z','+00:00'))
            if when.tzinfo is None:
                # Backward compatibility for old stored timestamps.
                when=when.replace(tzinfo=timezone.utc)
            return when.astimezone(UZ_TIMEZONE).date().isoformat()
        except ValueError:
            pass
    # Older imports may lack the timestamp; make fallback explicit.
    return datetime.now(UZ_TIMEZONE).date().isoformat()


def report_filename(record,extension):
    if extension not in {'docx','pdf','xlsx','csv'}:
        raise ValueError('Unsupported report format')
    name=safe_company_name(record.get('company_name'))
    return f'{name}_{inspection_date(record)}.{extension}'


def attachment_disposition(filename):
    # Correct ASCII fallback + RFC 5987 UTF-8 for Uzbek/Cyrillic in browsers.
    extension=filename.rsplit('.',1)[-1]
    return f"attachment; filename=report.{extension}; filename*=UTF-8''{quote(filename,safe='')}"
