"""Offline, evidence-first document screening; optional loopback-only local model.

Findings are NOT legal conclusions. The program never asserts unverified compliance as proven.
"""
from __future__ import annotations

import hashlib
import threading
import io
import os
import re
import subprocess
import tempfile
import time
import unicodedata
import zlib
import xml.etree.ElementTree as ET
from collections import Counter
from dataclasses import dataclass, field
from pathlib import PurePosixPath
from zipfile import ZipFile, BadZipFile
from typing import Callable

from docx import Document
try:
    import pymupdf as fitz  # Supported module name; avoids deprecated fitz import warning.
except ImportError:
    import fitz  # Older PyMuPDF releases.

MAX_UPLOAD = 500 * 1024 * 1024
MAX_MEMBERS = 180
MAX_TOTAL_UNPACKED = 900 * 1024 * 1024
MAX_MEMBER = 180 * 1024 * 1024
MAX_RATIO = 130
OCR_CONTEXT=threading.local()
MAX_PAGES = 150
MAX_TEXT = 210000
MAX_OCR_FILES = 3
MAX_OCR_PAGES_PER_PDF = 1
MAX_OCR_SECONDS_PER_PAGE = 12
MAX_TOTAL_OCR_SECONDS = 35  # Quick mode; full OCR receives a separate bounded budget
VALID_SUFFIXES = ('.pdf','.doc','.docx','.xlsx','.xls','.xltx','.txt','.csv','.png','.jpg','.jpeg','.svg','.rtf')

DOC_KINDS = [
 ('application','Ariza', ['заявление','заявка','ариза','ariza','zayavlenie','zayavka'], True),
 ('charter','Ustav', ['устав','ustav'], True),
 ('certificate','Guvohnoma', ['гувохнома','гувох','guvohnoma','guvoxnoma','свидетельство'], True),
 ('business_plan','Biznes-reja', ['бизнес-план','бизнес план','biznes-reja','biznes reja','бизнес_план','biznesplan'], True),
 ('questionnaire','Anketa', ['анкета','anketa'], True),
 ('director_order','Direktor tayinlash buyrug‘i', ['приказ','buyruq','buyrugi','buyrug‘i','буйруқ'], True),
 ('passport','Direktor va ta’sischi pasportlari', ['паспорт','pasport','passport','паспортлар'], True),
 ('contract','Xizmat shartnomasi yoki ommaviy oferta', ['договор','shartnoma','шартнома','оферта','oferta','offer'], True),
 ('founder_agreement','Ta’sis shartnomasi (shartli)', ['учредительный договор','таъсис шартнома','ta’sis shartnoma','tasis shartnoma'], False),
 ('license','Litsenziya (mavjud bo‘lsa)', ['лицензия','litsenziya','license','рухсатнома'], False),
 ('company_info','Kompaniya ma’lumoti — o‘zbek va rus', ['информация о компании','информация об организации','ma’lumotnoma','malumotnoma','kompaniya haqida','tashkilot haqida malumot','tashkilot haqida ma lumot','faoliyati tugrisida','фаолияти тугрисида','маълумотнома'], True),
 ('social','Ijtimoiy tarmoqlar yoki “mavjud emas” qaydi', ['соцсети','социальн','ijtimoiy','ссылки','links','vebsayt','вебсайт'], True),
 ('banner','1192×226 banner yoki “mavjud emas” qaydi', ['баннер','banner'], True),
 ('logo','Logo SVG/PNG yoki “mavjud emas” qaydi', ['логотип','logo'], True),
 ('vacancies','Vakansiyalar (mavjud bo‘lsa)', ['вакансии','vakansiya','bo‘sh ish','bo sh ish'], False),
]
DOC_INDEX = {x[0]: x for x in DOC_KINDS}

BPLAN_SECTIONS = [
 ('1','Loyiha qisqacha bayoni', ['резюме','loyiha qisqa','rezyume','резюме проекта']),
 ('2','Kompaniya haqida ma’lumot', ['информация о компании','информация о заявителе','сведения о заявителе','сведения об заявителе','компании','korxona haqida','kompaniya haqida','arizachi haqida']),
 ('3','Loyiha/faoliyat tavsifi', ['описание проекта','проектная деятельность','loyiha tavsifi','loyihaning tavsifi','фаолият тавсифи']),
 ('4','Bozor va marketing', ['рынок и маркетинг','маркетинг','bozor va marketing','bozor tahlili','бозор']),
 ('5','Ishlab chiqarish/sotish rejasi', ['производственный','сбытовой','план разработки, производства и реализации','план производства','план продаж','ishlab chiqarish','sotish rejasi','хизмат кўрсатиш']),
 ('6','Tashkiliy reja', ['организационный план','организационная структура','tashkiliy reja','ташкилий']),
 ('7','Moliyaviy reja', ['финансовый план','молиявий режа','moliyaviy reja','финансовые результаты','pul oqimi']),
 ('8','Xulosa', ['заключение','выводы','xulosa','хулоса']),
]

class UnsafeArchive(ValueError):
    pass

@dataclass
class DocFile:
    path: str
    suffix: str
    size: int
    text: str = ''
    pages: int = 0
    kind: str = ''
    extraction: str = 'ok'
    note: str = ''
    width: int = 0
    height: int = 0
    tables: list = field(default_factory=list)
    ocr_pages: int = 0
    has_media: bool = False
    quality: str = 'unverified'
    def to_public(self):
        return {'name':self.path,'type':self.kind or 'other','size':self.size,'characters':len(self.text),'pages':self.pages,'extraction':self.extraction,'note':self.note,'ocr_pages_attempted':self.ocr_pages,'quality':self.quality,'validation':getattr(self,'validation','unverified')}


def norm(s):
    s=unicodedata.normalize('NFKC',s).casefold()
    return re.sub(r'[^\wа-яёқғҳў]+',' ',s.replace('_',' ')).strip()


def safe_zip_members(raw: bytes):
    if len(raw)>MAX_UPLOAD: raise UnsafeArchive('ZIP hajmi 500 MB chegaradan oshgan.')
    try: z=ZipFile(io.BytesIO(raw))
    except BadZipFile as e: raise UnsafeArchive('ZIP fayli ochilmadi.') from e
    members=[i for i in z.infolist() if not i.is_dir()]
    if len(members)>MAX_MEMBERS: raise UnsafeArchive('ZIP ichidagi fayllar soni 180 tadan ko‘p.')
    if not members: raise UnsafeArchive('ZIP bo‘sh.')
    if sum(i.file_size for i in members)>MAX_TOTAL_UNPACKED: raise UnsafeArchive('ZIP arxivining ochilgan hajmi haddan tashqari katta.')
    seen=set()
    for i in members:
        name=i.filename.replace('\\','/')
        p=PurePosixPath(name)
        if name.startswith('/') or '..' in p.parts or ':' in name or any(ord(ch)<32 for ch in name):
            raise UnsafeArchive('Arxivda xavfli fayl yo‘li mavjud.')
        if i.file_size>MAX_MEMBER: raise UnsafeArchive('ZIP ichidagi fayllardan biri 180 MB dan katta.')
        if i.file_size/max(1,i.compress_size)>MAX_RATIO and i.file_size>4*1024*1024:
            raise UnsafeArchive('Juda yuqori siqilgan fayl: ZIP-bomb xavfi.')
        if i.external_attr>>16 & 0o170000 == 0o120000:
            raise UnsafeArchive('ZIP ichida symbolic link bo‘lishi mumkin emas.')
        # ZIP is never extracted to disk, but visually equivalent Unicode names
        # can still confuse dossier classification and the audit trail.
        canonical=unicodedata.normalize('NFKC',name).casefold()
        if canonical in seen: raise UnsafeArchive('ZIP ichida takrorlangan fayl nomi.')
        seen.add(canonical)
        if i.flag_bits&0x1: raise UnsafeArchive('Parollangan ZIP qo‘llab-quvvatlanmaydi.')
    return z,members


# Child binaries (OCR/LibreOffice) must not inherit the optional CCVibe key.
# These local processes do NOT need access to any authentication secret.
def helper_env():
    secret_names={'ANTHROPIC_AUTH_TOKEN','ANTHROPIC_API_KEY',
                  'OPENAI_API_KEY','CYBERPARK_API_KEY','CYBERPARK_SECRET_KEY'}
    return {k:v for k,v in os.environ.items()
            if k.upper() not in secret_names and not k.upper().startswith('CYBERPARK_AUTH_')}


def ocr_image(b:bytes, ext='.png'):
    from .local_tools import find
    exe=find('tesseract')
    if not exe: return '', 'Tesseract OCR o‘rnatilmagan'
    with tempfile.TemporaryDirectory(prefix='cpocr_') as tmp:
        path=os.path.join(tmp,'page'+ext)
        with open(path,'wb') as f:f.write(b)
        # OEM: explicit local process; timeout per image
        if getattr(OCR_CONTEXT,'preprocess',False):
            try:
                from PIL import Image, ImageOps
                with Image.open(path) as original:
                    adjusted=ImageOps.autocontrast(ImageOps.grayscale(original))
                    adjusted.save(path,format='PNG')
            except Exception:pass
        requested=getattr(OCR_CONTEXT,'language','auto')
        languages={'uz':'uzb+uzb_cyrl+rus+eng','ru':'rus+eng','auto':'uzb+uzb_cyrl+rus+eng'}.get(requested,'uzb+uzb_cyrl+rus+eng')
        try:
            p=subprocess.run([exe,path,'stdout','-l',languages,'--psm','3'],capture_output=True,timeout=MAX_OCR_SECONDS_PER_PAGE,env={**helper_env(),'OMP_THREAD_LIMIT':'1'})
            if p.returncode!=0:
                p=subprocess.run([exe,path,'stdout','-l','eng+rus','--psm','3'],capture_output=True,timeout=MAX_OCR_SECONDS_PER_PAGE,env={**helper_env(),'OMP_THREAD_LIMIT':'1'})
            return (p.stdout.decode('utf-8',errors='replace') if p.returncode==0 else ''), ('' if p.returncode==0 else 'OCR bajarilmadi')
        except (OSError,subprocess.TimeoutExpired): return '', 'OCR vaqti tugadi'


def _read_pdf(b, allow_ocr=True, max_ocr_pages=MAX_OCR_PAGES_PER_PDF, return_ocr_count=False):
    """Bounded OCR: never silently claim that unprocessed scan pages were checked."""
    d=fitz.open(stream=b,filetype='pdf')
    if d.needs_pass:return ('',0,'ocr_needed',0) if return_ocr_count else ('',0,'ocr_needed')
    texts=[];pages=len(d);ocr_pages=0;unread=0;cut=False;total_chars=0
    for i,p in enumerate(d):
        if i>=MAX_PAGES:cut=True;break
        txt=p.get_text('text',sort=True)
        if len(txt.strip())<35:
            if allow_ocr and ocr_pages<max_ocr_pages and time.monotonic()<getattr(OCR_CONTEXT,'deadline',float('inf')):
                ocr_pages+=1
                try:
                    pix=p.get_pixmap(matrix=fitz.Matrix(1.45,1.45),alpha=False)
                    if pix.width*pix.height<=8_000_000:
                        ot,why=ocr_image(pix.tobytes('png'))
                        if len(ot.strip())>len(txt.strip()):txt=ot
                except Exception:pass
            if len(txt.strip())<35:unread+=1
        texts.append(txt)
        total_chars+=len(txt)
        progress_callback=getattr(OCR_CONTEXT,'page_callback',None)
        if progress_callback:progress_callback(i+1,pages)
        if total_chars>MAX_TEXT:cut=True;break
    text='\n'.join(texts)[:MAX_TEXT]
    if cut or unread:status='partial' if text.strip() else 'ocr_needed'
    else:status='ok'
    return (text,pages,status,ocr_pages) if return_ocr_count else (text,pages,status)


def _read_docx(b):
    """Read document body in its ORIGINAL paragraph/table order.

    Reading all paragraphs followed by all tables moves section data away from
    headings, causing incorrect 51-point business-plan checks. Never execute
    macros, external links or field codes.
    """
    with ZipFile(io.BytesIO(b)) as package:
        entries=package.infolist()
        if len(entries)>700 or sum(x.file_size for x in entries)>90*1024*1024 or any(x.file_size>30*1024*1024 for x in entries):
            raise ValueError('Juda katta yoki shubhali DOCX ichki tuzilma')
    doc=Document(io.BytesIO(b))
    parts=[]
    def text_of(node):
        return ''.join((x.text or '') if x.tag.endswith('}t') else '\t' if x.tag.endswith('}tab') else ''
                       for x in node.iter())
    for child in doc.element.body.iterchildren():
        if child.tag.endswith('}p'):
            parts.append(text_of(child))
        elif child.tag.endswith('}tbl'):
            for row in child.iterchildren():
                if not row.tag.endswith('}tr'):continue
                cells=[]
                for cell in row.iterchildren():
                    if not cell.tag.endswith('}tc'):continue
                    # Keep cell internal paragraphs together, but preserve the
                    # table's place relative to adjacent headings.
                    cells.append(' '.join(text_of(x) for x in cell.iterchildren()
                                          if x.tag.endswith('}p')))
                parts.append(' | '.join(cells))
    for section in doc.sections:
        parts.extend(p.text for p in section.header.paragraphs)
        parts.extend(p.text for p in section.footer.paragraphs)
    # Textboxes are part of the body XML; text_of(parent paragraph) includes
    # their text already. No duplicate append is needed.
    joined='\n'.join(parts)
    return joined[:MAX_TEXT],0,('partial' if len(joined)>MAX_TEXT else 'ok')


def _read_xlsx(b):
    # OOXML text extraction via standard library, no macros or formula evaluation.
    with ZipFile(io.BytesIO(b)) as z:
        entries=z.infolist()
        if len(entries)>600 or sum(i.file_size for i in entries)>90*1024*1024 or any(i.file_size>30*1024*1024 for i in entries):
            raise ValueError('Juda katta yoki shubhali XLSX ichki tuzilma')
        strings=[]
        if 'xl/sharedStrings.xml' in z.namelist():
            r=ET.fromstring(z.read('xl/sharedStrings.xml'))
            for si in r:
                strings.append(''.join(el.text or '' for el in si.iter() if el.tag.endswith('}t')))
        chunks=[]
        formulas_without_cached_value=0
        for name in sorted(z.namelist()):
            if not re.fullmatch(r'xl/worksheets/sheet\d+\.xml',name):continue
            root=ET.fromstring(z.read(name))
            chunks.append(name)
            for cell in root.iter():
                if not cell.tag.endswith('}c'):continue
                ref=cell.get('r','')
                value=''
                for elem in cell:
                    if elem.tag.endswith('}v'):value=elem.text or ''
                    if elem.tag.endswith('}is'):
                        value=''.join(x.text or '' for x in elem.iter() if x.tag.endswith('}t'))
                if cell.get('t')=='s' and value.isdigit():
                    ix=int(value);value=strings[ix] if ix<len(strings) else value
                if any(elem.tag.endswith('}f') for elem in cell) and not value:
                    # A formula without a cached result cannot be validated
                    # without executing Excel. Never mark it fully readable.
                    formulas_without_cached_value+=1
                if value:chunks.append(f'{ref} {value}')
                if len(chunks)>16000:break
        joined='\n'.join(chunks)
        return joined[:MAX_TEXT],0,('partial' if len(chunks)>16000 or len(joined)>MAX_TEXT or formulas_without_cached_value else 'ok')


def _read_doc_binary(b):
    from .local_tools import find
    office=find('office')
    if not office:return '',0,'conversion_unavailable'
    with tempfile.TemporaryDirectory(prefix='cpdoc_') as tmp:
        src=os.path.join(tmp,'legacy.doc')
        out=os.path.join(tmp,'converted');os.mkdir(out)
        with open(src,'wb') as f:f.write(b)
        try:
            cmd=[office,'-env:UserInstallation=file:///'+tmp.replace('\\','/')+'/profile','--headless','--convert-to','docx','--outdir',out,src]
            subprocess.run(cmd,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=25,check=False,env=helper_env())
            out_path=os.path.join(out,'legacy.docx')
            if os.path.isfile(out_path):
                with open(out_path,'rb') as f:return _read_docx(f.read())
        except (OSError,subprocess.TimeoutExpired):pass
        return '',0,'conversion_unavailable'


def read_file(path, b, allow_ocr=True, max_ocr_pages=MAX_OCR_PAGES_PER_PDF):
    suffix=os.path.splitext(path)[1].lower()
    f=DocFile(path,suffix,len(b))
    try:
        if suffix=='.pdf':
            f.text,f.pages,f.extraction,f.ocr_pages=_read_pdf(b, allow_ocr=allow_ocr,max_ocr_pages=max_ocr_pages,return_ocr_count=True)
            if f.ocr_pages:f.note=f'OCR tekshiruviga {f.ocr_pages} sahifa yuborildi.'
        elif suffix=='.docx':
            with ZipFile(io.BytesIO(b)) as internal:
                f.has_media=any(n.startswith('word/media/') for n in internal.namelist())
            f.text,f.pages,f.extraction=_read_docx(b)
            if f.extraction=='partial':f.note='Hujjat uzun: ayrim matn va sahifalar qamrab olinmagan.'
        elif suffix=='.doc':f.text,f.pages,f.extraction=_read_doc_binary(b)
        elif suffix in ('.xlsx','.xltx'):
            f.text,f.pages,f.extraction=_read_xlsx(b)
            if f.extraction=='partial':f.note='Excel matnining qismi kesilgan yoki formulalarda hisoblangan qiymat yo‘q; barcha kataklar tekshirilmagan.'
            from .table_extract import xlsx_tables
            f.tables=xlsx_tables(b)
        elif suffix in ('.txt','.csv'):
            try:decoded=b.decode('utf-8-sig')
            except UnicodeDecodeError:decoded=b.decode('cp1251',errors='replace')
            f.extraction='partial' if len(decoded)>MAX_TEXT else 'ok'
            f.text=decoded[:MAX_TEXT]
            if f.extraction=='partial':f.note='Matn limitdan uzun: oxirgi qism o‘qilmadi.'
        elif suffix in ('.png','.jpg','.jpeg'):
            try:
                from PIL import Image
                Image.MAX_IMAGE_PIXELS=20_000_000
                with Image.open(io.BytesIO(b)) as im:
                    f.width,f.height=im.size
                    im.verify()  # Header alone is insufficient: reject broken image data.
            except Exception:
                f.note='Rasm o‘lchami o‘qilmadi.'
                f.extraction='error'
                return f
            f.text,why=ocr_image(b,suffix) if allow_ocr else ('','OCR rejasiga kiritilmadi; xodim tekshirsin')
            if allow_ocr:f.ocr_pages=1
            if not f.text.strip():f.extraction='ocr_needed';f.note=why
        elif suffix=='.svg':
            decoded=b.decode('utf-8',errors='replace')
            f.text=decoded[:MAX_TEXT]
            if len(decoded)>MAX_TEXT:f.extraction='partial';f.note='SVG matni qisqartirildi.'
        elif suffix=='.rtf':
            try:
                from striprtf.striprtf import rtf_to_text
                decoded=rtf_to_text(b.decode('cp1251',errors='replace'))
                f.text=decoded[:MAX_TEXT]
                if len(decoded)>MAX_TEXT:f.extraction='partial'
            except ImportError:f.extraction='conversion_unavailable';f.note='striprtf o‘rnatilmagan.'
        elif suffix=='.xls':
            try:
                import xlrd
                book=xlrd.open_workbook(file_contents=b,on_demand=True)
                lines=[];tables=[];cut=False
                for sh in book.sheets():
                    lines.append(f'Sheet: {sh.name}')
                    for ri in range(sh.nrows):
                        vals=[str(sh.cell_value(ri,ci))[:250] for ci in range(min(sh.ncols,45))]
                        lines.append(' | '.join(vals))
                        if ri<180:tables.append(vals[:22])
                        if len(lines)>16000 or sum(len(x) for x in lines[-200:])>MAX_TEXT:
                            cut=True;break
                    if cut:break
                decoded='\n'.join(lines)
                f.text=decoded[:MAX_TEXT];f.extraction='partial' if cut or len(decoded)>MAX_TEXT else 'ok'
                f.tables=[tables] if tables else []
            except ImportError:f.extraction='conversion_unavailable';f.note='xlrd o‘rnatilmagan.'
            except Exception:f.extraction='error';f.note='Eski Excel faylini ochib bo‘lmadi.'
        else:f.extraction='unsupported'
    except Exception as e:
        f.extraction='error';f.note=f'Faylni o‘qib bo‘lmadi ({type(e).__name__}).'
    return f


def identify_kind(f, rules=None):
    """Classify across flat, renamed and nested applicant packages.

    Strong filename/title evidence takes priority over unambiguous folder hints.
    A document's mere *mention* inside an unrelated file is never a type match.
    Mixed folders (founding documents, director/passports, licences and general
    attachment folders) are not treated as proof of any individual document.
    """
    # Actual document title/structure wins over a misleading ZIP filename.
    # A business plan named "Ariza.pdf" must not become an application simply
    # because a filename matches one alias.  This never proves completeness.
    from .content_classifier import detect_by_content
    fname=norm(f.path.replace(chr(92), "/").rsplit("/",1)[-1])
    first_page=norm(' '.join(f.text.splitlines()[:18]))[:1600]
    unrelated_applications=('заявление на отпуск','заявление об увольнении',
                            'заявление в банк','заявление на выдачу кредита',
                            'ta til arizasi','ishdan bo shash haqida ariza',
                            'loan application','leave application')
    if any(x in fname or x in first_page[:290] for x in unrelated_applications):
        return 'other_application'
    content_kind = detect_by_content(f.text)
    if content_kind:
        return content_kind
    name = norm(f.path.replace(chr(92), "/").rsplit("/", 1)[-1])
    opening = norm(' '.join(f.text.splitlines()[:14]))[:1400]
    # A supplier/lease/loan agreement is not the applicant's service contract.
    # Likewise, dismissal/holiday/order-of-purchase is not appointment proof.
    if any(x in name for x in ('договор', 'shartnoma', 'contract', 'оферта', 'oferta')):
        irrelevant=('договор поставки','договор аренды','договор купли','договор займа',
                    'договор кредита','договор лизинга','ijara shartnomasi',
                    'oldi sotdi shartnomasi','purchase agreement','supply agreement',
                    'loan agreement','lease agreement')
        if any(x in name or x in opening[:280] for x in irrelevant):
            return 'supporting_contract'
    # Do not trust a director-order filename when the CONTENT is about dismissal
    # or leave rather than entering/appointing a director.
    if (f.extraction=='ok'
        and any(x in name for x in ('buyrugi','buyrug','buyruq','приказ','буйруқ'))
        and re.search(r'(?:увольнени|отпуск|ishdan\W*bo\W*shatish|ishdan\W*bo\W*shash)',f.text[:850],re.I)
        and not re.search(r'(?:direktor\s+lavozimiga\s+kirishish|direktori\s+lavozimiga\s+kirishdim|назначении\s+директора)',f.text[:850],re.I)):
        return 'other_order'
    if (f.extraction=='ok'
        and any(x in name for x in ('buyrugi','buyrug','buyruq','приказ','буйруқ'))
        and re.search(r'(?:direktor\s+lavozimiga\s+kirishish|direktori\s+lavozimiga\s+kirishdim|назначении\s+директора|директорни\s+тайинлаш)',f.text[:3500],re.I)
        and not re.search(r'(?:увольнени|отпуск|ishdan\s+bo\s+shatish)',f.text[:500],re.I)):
        return 'director_order'
    if any(x in name for x in ('приказ','buyruq','буйруқ')) and f.extraction=='ok' and len(opening)>60:
        appointment=('назначени','тайинлаш','tayinlash','назначить','вазифасига тайин')
        other=('увольнени','отпуск','командировк','закуп','освобождени',
               'ishdan bo shatish','mehnat ta tili','сокращени')
        if any(x in opening[:300] for x in other) and not any(x in opening[:300] for x in appointment):
            return 'other_order'
    # Business-plan attachments cannot satisfy the actual business plan.
    if any(x in name for x in ('приложени', 'ilova', 'илова', 'appendix', 'attachment')) and any(
        x in name for x in ('бизнес', 'biznes', 'business', 'финансов', 'moliyaviy')):
        return 'business_appendix'
    financial_signals = ('бухгалтерия баланси', 'бухгалтерский баланс',
                         'молиявий натижалар', 'отчет о финансовых результатах',
                         'отчёт о финансовых результатах', 'financial statements')
    peek = norm(' '.join(f.text.splitlines()[:35]))[:3000]
    if any(norm(a) in name or norm(a) in peek for a in financial_signals):
        return 'financial_statement'
    # Founder/director decisions are not the same legal document as an order.
    if any(x in name for x in ('решение на директора', 'reshenie na direktora',
                               'директор тайинлаш карори', 'direktor qarori')):
        return 'director_resolution'
    if any(x in name for x in ('ijara', 'аренд', 'трудовой', 'трудов', 'mehnat')):
        # A labour or rent agreement is supporting evidence, not necessarily
        # the service agreement/oferta required by the reference checklist.
        return ''

    def exact_aliases(segment, aliases):
        return any(norm(a) in segment for a in aliases if norm(a))

    # First take an explicit, purposeful filename. Folder names can describe a
    # collection containing several types (e.g. director order and passports).
    for kind, label, aliases, required in DOC_KINDS:
        if kind=='contract' and exact_aliases(name, DOC_INDEX['founder_agreement'][2]):
            continue
        if exact_aliases(name, aliases + (rules or {}).get(kind, [])):
            return kind

    # Meaningful titles within a few early lines. Do not scan the whole text:
    # a business plan might mention an application or bank certificate later.
    lines=[line.strip() for line in f.text.splitlines() if line.strip()]
    heading=norm(' '.join(lines[:5]))[:420]
    content_titles=(
       ('application',('заявление о регистрации', 'заявление на резидентство',
                       'заявление о вступлении', 'ариза', 'rezidentlikka ariza', 'заявка на резидентство')),
       ('business_plan',('бизнес план', 'biznes reja', 'business plan', 'бизнес проекта')),
       ('questionnaire',('анкета кандидата', 'анкета заявителя', 'nomzod anketasi', 'anketa')),
       ('charter',('устав общества', 'устав ооо', 'ustav', 'низом')),
       ('certificate',('свидетельство о государственной регистрации',
                       'davlat ro yxatidan o tganlik guvohnomasi', 'гувохнома')),
       ('director_order',('приказ о назначении', 'direktorni tayinlash haqida buyruq',
                          'директорни тайинлаш', 'tayinlash to g risida buyruq')),
       ('company_info',('информация о компании', 'сведения о компании',
                        'tashkilot haqida ma lumot', 'kompaniya haqida ma lumot')),
    )
    for kind, titles in content_titles:
        # Title on one of the first lines; an unrelated paragraph that merely
        # mentions another document cannot change the document's type.
        first_lines=[norm(line) for line in lines[:2]]
        if any((line == norm(t) or line.startswith(norm(t)+' '))
               for line in first_lines if len(line)<=145
               for t in titles if norm(t)):
            return kind

    # Folders are secondary hints when the file itself is opaque (e.g. 001.pdf).
    # No numbering requirement; every nested directory can be interpreted.
    # Do not use the outer company name as a category.
    directory_parts=[norm(p) for p in f.path.replace('\\','/').split('/')[:-1]]
    hint_patterns=(
       ('business_plan', ('biznes reja','бизнес план','business plan','biznes loyiha')),
       ('questionnaire', ('nomzod anketasi','belgilangan shakldagi nomzod','анкета','anketa')),
       ('company_info', ('tashkilot haqida ma lumot','компания ҳақида','информация о компании',
                          'kompaniya haqida ma lumot','company information','company profile')),
       ('social', ('ijtimoiy tarmoql','социальные сети','социальные ссылки','social media','socseti')),
       ('banner', ('banner','баннер')),
       ('logo', ('kompaniya logotipi','логотип','logo','logotip')),
       ('financial_statement', ('balans va moliyaviy','бухгалтерский баланс',
                                'financial statements','финансовые отчеты','moliyaviy natijalar')),
       ('application', ('ariza','заявление','заявка','application')),
       ('charter', ('ustav','устав','низом')),
       ('certificate', ('guvohnoma','гувохнома','свидетельство о регистрации')),
    )
    for parent in reversed(directory_parts):
        matches=[kind for kind, hints in hint_patterns if exact_aliases(parent,hints)]
        if len(set(matches))==1:
            # An explicit nested file can be a supporting attachment, even in a
            # business plan or company information folder. Those are not plans.
            if any(x in name for x in ('приложени', 'ilova', 'appendix', 'attachment')):
                return 'business_appendix' if matches[0]=='business_plan' else ''
            return matches[0]
    return ''


def issue(code,level,title,description,solution,file='',source='',confidence='high'):
    return {'id':code,'level':level,'title':title,'description':description,'solution':solution,'file':file,'source':source,'confidence':confidence}


def _add(issues, i):
    if i['id'] not in {it['id'] for it in issues}:issues.append(i)


def _matches(text, aliases):
    n=norm(text)
    return any(norm(x) in n for x in aliases)


def _extract_stir(t):
    # Keep the compatibility wrapper used by historical audit modules.
    from .stir_resolution import labeled_stirs
    return list(dict.fromkeys(number for number,_ in labeled_stirs(t)))


def _extract_accounts(t):
    # Only accept 20-digit payment accounts adjacent to an account label.
    matches=re.findall(r'(?:\b(?:х\s*/\s*р|h\s*/\s*r|р\s*/\s*с|hisob\s*raqam|hisobvaraq|расч[её]тн\w*\s+сч[её]т|bank\s+account|сч[её]т)\b)[^\d]{0,35}(\d{20})(?!\d)',t,flags=re.I)
    return list(dict.fromkeys(matches))


def detect_language(text):
    """Keyword heuristic for report language; no external translation or AI."""
    n=norm(text[:50000])
    vocab={
        'ru':['бизнес план','планируемый','заявителя','реализации','производства','выручки','расходов','финансовый','предприятия','организационный','себестоимость','прогноз'],
        'uz_cyrl':['лойиҳа','корхона','даромад','молиявий','режа','маблағ','фаолият','сотиш','иқтисодий','иш ўринлари'],
        'uz_lat':['loyiha','korxona','daromad','moliyaviy','reja','mablag','faoliyat','sotish','iqtisodiy','ish o rinlari'],
    }
    score={lang:sum(n.count(norm(word)) for word in words) for lang,words in vocab.items()}
    preferred=max(score,key=score.get)
    return preferred if score[preferred]>=3 else 'uz_lat'

def analyze_zip(raw:bytes, filename:str, rules:dict|None=None, progress:Callable|None=None, ocr_mode:str="quick", ai_capture=None):
    def step(v,s):
        if progress:progress(v,s)
    step(5,'ZIP xavfsizligi tekshirilmoqda')
    # The full mode can inspect larger scanned dossiers without claiming 100%
    # completion when the bounded OCR budget is exhausted.
    try:
        requested_budget=int(os.environ.get('CYBERPARK_FULL_OCR_MAX_SECONDS','120'))
    except (ValueError,OverflowError):
        requested_budget=120
    full_budget=min(240,max(35,requested_budget)) if ocr_mode=='full' else MAX_TOTAL_OCR_SECONDS
    OCR_CONTEXT.deadline=time.monotonic()+full_budget
    z,members=safe_zip_members(raw)
    archive_label=os.path.splitext(os.path.basename(filename))[0].strip()[:100]
    company='Korxona nomi tasdiqlanmadi'; company_evidence={'status':'unverified','archive_label':archive_label}
    files=[]
    # Page budget, not file-count budget: text PDFs do not consume OCR quota.
    remaining_ocr_pages=0 if ocr_mode=='off' else (3 if ocr_mode!='full' else 100)
    content_hashes=[]
    with z:
        for n,i in enumerate(members):
            suffix=os.path.splitext(i.filename)[1].lower()
            if suffix not in VALID_SUFFIXES:
                files.append(DocFile(i.filename,suffix,i.file_size,kind='',
                    extraction='unsupported',note='Ushbu fayl formati avtomatik o‘qilmaydi.'))
                step(9+int(63*(n+1)/len(members)),f'{n+1}/{len(members)} fayl ajratildi')
                continue
            try:
                # Corrupt CRC/deflate streams are per-file defects, not reasons
                # to discard every healthy document in the same package.
                try:
                    b=z.read(i, pwd=None)
                except (BadZipFile, EOFError, OSError, RuntimeError, ValueError, zlib.error) as exc:
                    failed=DocFile(i.filename,suffix,i.file_size,extraction='error',
                        note='ZIP ichidagi fayl shikastlangan yoki CRC tekshiruvidan o‘tmadi.')
                    failed.kind=identify_kind(failed,rules)
                    files.append(failed)
                    step(9+int(63*(n+1)/len(members)),f'{n+1}/{len(members)} fayl yaxlitligi tekshirildi')
                    continue
                content_hashes.append(hashlib.sha256(b).digest())
                guessed_kind=identify_kind(DocFile(i.filename,os.path.splitext(i.filename)[1].lower(),len(b)),rules)
                # OCR is slow and untrusted input: budget it for primary documents only.
                allow_ocr=(remaining_ocr_pages>0 and time.monotonic()<OCR_CONTEXT.deadline and (ocr_mode=='full' or guessed_kind in ('application','questionnaire','business_plan','charter','certificate','company_info','director_order','passport') or (not guessed_kind and i.filename.lower().endswith('.pdf'))))
                max_file_ocr=min(100,remaining_ocr_pages) if ocr_mode=='full' else 1
                OCR_CONTEXT.page_callback=lambda current,total:step(
                    9+int(63*((n+min(1,current/max(1,total)))/len(members))),
                    f'{n+1}/{len(members)} fayl, {current}/{total} sahifa')
                f=read_file(i.filename,b,allow_ocr=allow_ocr,max_ocr_pages=max_file_ocr)
                OCR_CONTEXT.page_callback=None
                remaining_ocr_pages=max(0,remaining_ocr_pages-f.ocr_pages)
                f.kind=identify_kind(f,rules)
                # A real zero-byte file is demonstrably empty, even if the OCR
                # pipeline cannot parse its nominal DOCX/PDF/image extension.
                if f.size==0:
                    f.extraction='error'
                    f.note='Fayl hajmi 0 bayt; mazmun mavjud emas.'
                if not f.kind and f.suffix in ('.xlsx','.xltx') and re.search(r'(?:финанс|finance|rasch|расч|hisob|расчет|план|forecast)',norm(f.path),re.I):
                    f.kind='business_appendix'
                # Tables are parsed only in memory, never added in full to history.
                if f.kind in ('business_plan','business_appendix') and f.suffix=='.pdf' and f.extraction=='ok':
                    from .table_extract import pdf_tables
                    f.tables=pdf_tables(b)
                if f.kind in ('business_plan','business_appendix') and f.suffix=='.docx' and f.extraction=='ok':
                    try:
                        d=Document(io.BytesIO(b))
                        f.tables=[[[c.text[:160] for c in row.cells[:22]] for row in table.rows[:180]] for table in d.tables[:100]]
                    except Exception:pass
                # Optional in-memory AI source: capture the text that the FIRST
                # parser/OCR pass actually read.  Never serialize it in history
                # and never send the raw content to the remote model.
                if (ai_capture is not None and f.kind=='business_plan' and
                    f.extraction=='ok' and bool(f.text.strip())):
                    ai_capture(f)
                files.append(f)
            except (MemoryError,OverflowError):raise UnsafeArchive('Arxiv ichidagi fayl qayta ishlashga juda katta.')
            step(9+int(63*(n+1)/len(members)),f'{n+1}/{len(members)} fayl tahlil qilindi')
    from .company_identity import identify_applicant
    resolved_name, company_evidence = identify_applicant(files,archive_label)
    if resolved_name:
        company=resolved_name
    step(75,'Hujjatlarning to‘liqligi tekshirilmoqda')
    issues=[]
    for f in files:
        if f.extraction=='error' and 'CRC' in f.note:
            _add(issues,issue('damaged_member_'+hashlib.sha1(f.path.encode()).hexdigest()[:12],
                'error','ZIP ichidagi fayl shikastlangan',
                f'«{os.path.basename(f.path)}» fayli ZIP arxivida mavjud, ammo uning yaxlitligi (CRC) tasdiqlanmadi.',
                'Faylning asl nusxasini qayta saqlab, yangi ZIPga joylang va tekshiruvni takrorlang.',
                f.path,'ZIP fayl yaxlitligi / CRC nazorati','high'))
        if f.size==0:
            _add(issues,issue('zero_byte_'+hashlib.sha1(f.path.encode()).hexdigest()[:12],
                'error','0 baytli bo‘sh fayl',
                f'«{os.path.basename(f.path)}» fayli ZIP ichida mavjud, lekin hajmi 0 bayt. Unda tekshiriladigan ma’lumot yo‘q.',
                'Fayl zarur bo‘lsa, ochiladigan va to‘ldirilgan nusxasini yuklang; ortiqcha yoki takroriy bo‘lsa, bo‘sh faylni ZIPdan chiqarib tashlang.',
                f.path,'Fayl hajmi: 0 bayt'))
    docs={key: [f for f in files if f.kind==key] for key,_,_,_ in DOC_KINDS}
    # A bilingual company profile can contain its own social-links section.
    # Require a real URL in that section: a heading alone is not evidence.
    for f in docs['company_info']:
        social_part=re.search(r'(?:ijtimoiy\s+tarmoq|социальн.{0,12}сет)',f.text,re.I)
        if social_part and re.search(r'https?://(?:t\.me|instagram\.com|facebook\.com|linkedin\.com|[\w.-]+\.[a-z]{2,})/\S+',f.text[social_part.start():social_part.start()+1200],re.I):
            if f not in docs['social']:docs['social'].append(f)
    # Supporting statements remain visible without implying their values
    # were reconciled or treating an appointment resolution as an order.
    supporting=[f for f in files if f.kind=='financial_statement']
    director_resolutions=[f for f in files if f.kind=='director_resolution']
    # A file named 'certificate and passport' satisfies the filename-presence check for both.
    docs['passport'] += [f for f in files if f.kind!='passport' and _matches(os.path.basename(f.path),DOC_INDEX['passport'][2])]
    others=[f for f in files if not f.kind]
    # Unclassified readable/scanned documents might contain the missing item.
    # If such candidates exist, a name-based absence is only a review finding.
    ambiguous_docs=[f for f in others if f.suffix in ('.pdf','.doc','.docx','.rtf') or (f.extraction!='ok' and f.suffix in ('.png','.jpg','.jpeg'))]
    missing_level='review' if ambiguous_docs else 'error'  # Archive-level absence, irrespective of recognized file count.
    # Record explicit empty applicant folders. A mere undetected basename is
    # uncertain, but an empty questionnaire folder proves that no questionnaire
    # was placed in its required location. Do not infer missing originals from
    # partial OCR of combined PDFs.
    empty_questionnaire_folder=any(
        entry.is_dir()
        and any(x in norm(entry.filename.rstrip('/').split('/')[-1])
                for x in ('anketa','анкета','nomzod anketasi','belgilangan shakldagi nomzod'))
        and not any(m.filename.replace('\\','/').startswith(entry.filename.replace('\\','/')) for m in members)
        for entry in z.infolist()
    ) and not docs['questionnaire']
    for kind,label,aliases,required in DOC_KINDS:
        if kind in ('founder_agreement','license','vacancies','social','banner','logo','company_info','contract','passport'):
            continue
        if required and not docs[kind]:
            explicitly_empty=(kind=='questionnaire' and empty_questionnaire_folder)
            evidence=('ZIP ichidagi anketa uchun ajratilgan papka bo‘sh.'
                       if explicitly_empty else f'ZIP fayldagi fayl nomlari va aniqlangan turlar bo‘yicha «{label}» hujjati ajratilmadi.')
            action=('Belgilangan shablon bo‘yicha to‘ldirilgan anketani va talab etiladigan Word nusxasini ZIPga qo‘shing.'
                    if explicitly_empty else 'Talab etilgan hujjatni qo‘shing yoki u birlashtirilgan faylda bo‘lsa, aynan qaysi fayl va sahifada ekanini ko‘rsating.')
            _add(issues,issue('missing_'+kind,('error' if explicitly_empty else missing_level),
                              f'{label} aniqlanmadi',evidence,action,'',
                              'ПЕРЕЧЕНЬ ДОКУМЕНТОВ ДЛЯ ЗАЯВКИ.pdf'))
    if supporting:
        _add(issues,issue('financial_statements_review','review',
             'Buxgalteriya hisobotlari o‘qildi, ammo ekspert hisob-kitobi kerak',
             f'{len(supporting)} ta balans yoki moliyaviy natijalar hisoboti aniqlangan. Hisobotlar biznes-rejaning prognoz jadvallariga avtomatik tenglashtirilmaydi.',
             'Bu hisobotlarni biznes-reja prognozlari bilan qo‘lda solishtiring; zarur raqamlarni manba hujjatdan qayta hisoblang.',
             supporting[0].path,'Haqiqiy ilova — moliyaviy hisobot', 'medium'))
    if director_resolutions and not docs['director_order']:
        _add(issues,issue('director_resolution_review','review',
             'Direktor qarori mavjud, tayinlash buyrug‘i alohida aniqlanmadi',
             'Arxivda direktor haqida qaror topilgan. U aniq talab qilingan buyruq o‘rnini bosishi avtomatik isbotlanmaydi.',
             'Xodim qaror mazmunini va direktor tayinlash uchun talab etilgan hujjat turini tasdiqlasin.',
             director_resolutions[0].path,'ПЕРЕЧЕНЬ ДОКУМЕНТОВ ДЛЯ ЗАЯВКИ.pdf', 'medium'))
    if not docs['contract']:
        _add(issues,issue('missing_contract',missing_level,'Shartnoma/oferta namunasi aniqlanmadi','Talablar ro‘yxatidagi xizmat shartnomasi yoki ommaviy oferta namunasi ajratib topilmadi.','Xizmat shartnomasi yoxud ommaviy oferta faylini qo‘shing.','', 'ПЕРЕЧЕНЬ ДОКУМЕНТОВ ДЛЯ ЗАЯВКИ.pdf'))
    if not docs['passport']:
        _add(issues,issue('missing_passport','review','Pasport nusxalari avtomatik tasdiqlanmadi','Pasportlar alohida yoki birlashtirilgan PDF ichida bo‘lishi mumkin; fayl nomi asosida tasdiqlab bo‘lmadi.','Fayllarni qo‘lda tekshiring. Yo‘q bo‘lsa tegishli pasport nusxalarini so‘rang.','', 'ПЕРЕЧЕНЬ ДОКУМЕНТОВ ДЛЯ ЗАЯВКИ.pdf', 'medium'))
    # Conditional presence checks belong to the staff checklist until conditions
    # (number of founders, licensed activity) are established with evidence.
    if not docs['company_info']:
        _add(issues,issue('missing_info',missing_level,'Kompaniya haqidagi alohida ma’lumot aniqlanmadi','Sayt uchun rus va o‘zbek tilidagi faoliyat, xizmatlar va narx ma’lumotlari ajratib topilmadi.','Kompaniya haqida o‘zbek va rus tilida qisqa ma’lumot kiriting.','', 'ПЕРЕЧЕНЬ ДОКУМЕНТОВ ДЛЯ ЗАЯВКИ.pdf'))
    elif len(docs['company_info'])<2:
        _add(issues,issue('review_languages','review','Ikki tildagi ma’lumotni tekshiring','Kompaniya ma’lumotlari birgina faylda bo‘lishi mumkin; ikki til mavjudligini qoidaviy usulda tasdiqlash qiyin.','O‘zbek va rus tillaridagi ma’lumotlar mavjudligini xodim tekshirsin.','', 'ПЕРЕЧЕНЬ ДОКУМЕНТОВ ДЛЯ ЗАЯВКИ.pdf','medium'))
    # "Absent" is item-specific: a missing social network does not excuse a missing logo.
    absent_labels={
      'social':r'(?:соц(?:иальн)?|ijtimoiy|телеграм|instagram|telegram|сети|tarmoq)',
      'banner':r'(?:баннер|banner)',
      'logo':r'(?:логотип|logo)',
    }
    small_lines='\n'.join(f.text[:3500] for f in files if f.suffix in ('.txt','.docx','.doc') and len(f.text)<12000).splitlines()
    def absent_for(k):
        return any(re.search(absent_labels[k],line,re.I) and re.search(r'(?:отсутству|mavjud\s+emas|йўқ|yo.q|нет\b)',line,re.I) for line in small_lines if len(line)<350)
    for k,l in [('social','Ijtimoiy tarmoq havolalari'),('banner','1192×226 banner'),('logo','SVG/PNG logo')]:
        if not docs[k] and not absent_for(k):
            _add(issues,issue('missing_'+k,'review',f'{l} aniqlanmadi',f'{l} fayli yoki aynan shu band uchun “mavjud emas” qaydi topilmadi.','Faylni qo‘shing yoki tegishli bandda “mavjud emas” deb yozing.','', 'ПЕРЕЧЕНЬ ДОКУМЕНТОВ ДЛЯ ЗАЯВКИ.pdf','medium'))
    for f in docs['social']:
        if f.extraction=='ok' and not f.text.strip():
            _add(issues,issue('empty_social_'+hashlib.sha1(f.path.encode()).hexdigest()[:8],'error','Ijtimoiy tarmoq ma’lumotlari bo‘sh','Fayl mavjud, lekin matn yo‘q. Havolalar yoki “mavjud emas” qaydi kiritilmagan.','Havolalarni yozing yoki tarmoqlar mavjud bo‘lmasa shuni aniq qayd eting.',f.path,'ПЕРЕЧЕНЬ ДОКУМЕНТОВ ДЛЯ ЗАЯВКИ.pdf'))
    for f in docs['banner']:
        if f.width and (f.width,f.height)!=(1192,226):
            _add(issues,issue('banner_dimensions','error','Banner o‘lchami mos emas',f'Banner {f.width}×{f.height}; talab 1192×226.','Rasmni 1192×226 o‘lchamda tayyorlang.',f.path,'ПЕРЕЧЕНЬ ДОКУМЕНТОВ ДЛЯ ЗАЯВКИ.pdf'))
    for f in docs['logo']:
        if f.suffix not in ('.svg','.png'):
            _add(issues,issue('logo_format','error','Logo formati mos emas','Ro‘yxatga ko‘ra logo SVG yoki PNG formatida bo‘lishi kerak.','Logoni SVG/PNG formatida taqdim qiling.',f.path,'ПЕРЕЧЕНЬ ДОКУМЕНТОВ ДЛЯ ЗАЯВКИ.pdf'))
    # Candidate questionnaire must include editable Word version plus signed original.
    if docs['questionnaire'] and not any(x.suffix in ('.doc','.docx') for x in docs['questionnaire']):
        _add(issues,issue('questionnaire_word','review','Anketaning Word varianti aniqlanmadi','Anketa qog‘ozda imzolangan nusxa bilan birga Word formatida ham talab etiladi.','Anketaning tahrirlanadigan Word versiyasini qo‘shing.','', 'ПЕРЕЧЕНЬ ДОКУМЕНТОВ ДЛЯ ЗАЯВКИ.pdf'))
    unreadable=[]
    for f in files:
        if f.extraction in ('ocr_needed','conversion_unavailable','error','partial'):
            unreadable.append(os.path.basename(f.path))
        if f.suffix in ('.docx','.doc','.pdf','.txt') and f.extraction=='ok' and len(f.text.strip())==0:
            unreadable.append(os.path.basename(f.path))
    if unreadable:
        details='; '.join(unreadable[:8])
        if len(unreadable)>8:details+=f'; ... (+{len(unreadable)-8})'
        _add(issues,issue('unreadable_files','review',f'{len(unreadable)} ta faylning matni to‘liq tekshirilmadi',
             details,'Fayllarni qo‘lda ochib tekshiring yoki OCR/Word nusxasini qo‘shing.',
             '', 'Texnik tekshiruv','medium'))
    unsupported=[i.filename for i in members if os.path.splitext(i.filename)[1].lower() not in VALID_SUFFIXES]
    if unsupported:
        _add(issues,issue('unsupported_files','review','Ayrim fayl formatlari tekshirilmadi',
             f'{len(unsupported)} ta fayl dastur tanimaydigan formatda.',
             'Bu fayllarni ochib mazmunini xodim tekshirsin yoki qo‘llab-quvvatlanadigan formatga o‘tkazing.',
             '', 'Texnik tekshiruv', 'medium'))
    step(85,'Biznes-reja va o‘zaro moslik tekshirilmoqda')
    for f in docs['business_plan']:
        if len(f.text)<200:
            _add(issues,issue('business_unreadable','review','Biznes-reja mazmuni tekshirilmadi','Biznes-reja matni yetarli darajada olinmadi.','OCR yoki Word nusxasida tekshiring.',f.path,'БИЗНЕС ПЛАН ШАБЛОН.pdf','medium'));continue
        # Detailed 2026 subsection validation is performed by auditors.bplan_audit.
        if re.search(r'_{4,}|…{3,}|\.{7,}',f.text):
            _add(issues,issue('bplan_placeholders','review','Biznes-rejada to‘ldirilmagan shablon joylari bo‘lishi mumkin','Uzun pastki chiziqlar yoki nuqtalar aniqlangan; ular haqiqiy bo‘sh maydon yoki sahifa chizig‘i bo‘lishi mumkin.','Bo‘sh maydonlarni va imzo sanasini ko‘zdan kechiring.',f.path,'БИЗНЕС ПЛАН ШАБЛОН.pdf','medium'))
        if not re.search(r'\b(?:20\d{2}|202\d)\b',f.text):
            _add(issues,issue('bplan_period','review','Biznes-rejaning rejalashtirish davrini tekshiring','Matnda rejalashtirish yilini avtomatik ajratib bo‘lmadi.','Davr boshlanishi, tugashi va moliyaviy jadvallar davrlarini solishtiring.',f.path,'ТРЕБОВАНИЯ К СОДЕРЖАНИЮ БИЗНЕС ПЛАНУ.pdf','medium'))
    # Compare STIR only when labeled in core applicant docs, never partner invoices.
    company_core=[]
    for kind in ('application','questionnaire','business_plan','company_info'):
        for f in docs[kind]:
            inns=_extract_stir(f.text)
            if len(inns)==1: company_core.append((f.path,inns[0]))
    seen=Counter(stir for _,stir in company_core)
    if len(seen)>1:
        detail='; '.join(f'{os.path.basename(p)}: {v}' for p,v in company_core[:8])
        _add(issues,issue('mismatch_stir','review','STIR raqamlarida nomuvofiqlik ehtimoli',detail,'Ariza, anketa va biznes-rejadagi aynan arizachi STIRini tasdiqlang; sheriklarning STIRi bilan adashtirmang.','', 'Hujjatlararo solishtirish','medium'))
    stir=seen.most_common(1)[0][0] if seen and (len(seen)==1 or seen.most_common(1)[0][1]>1) else None
    # Scan all successfully extracted documents for applicant-linked, labeled
    # tax IDs. This covers multilingual headings and certificate/permit/tax
    # documents which may have a different filename or be in a subfolder.
    from .stir_resolution import resolve_stir
    resolved_stir,stir_evidence,stir_conflicts=resolve_stir(files,company)
    if resolved_stir:
        if stir and stir!=resolved_stir:
            _add(issues,issue('stir_conflict_sources','review',
                'Arizachining STIR manbalarida tafovut','Asosiy hujjatlar va boshqa dalillarda turlicha STIR aniqlangan.',
                'Guvohnoma yoki davlat soliq ma’lumotnomasi bilan tekshiring.',
                stir_evidence['file'],'Hujjatlararo solishtirish','medium'))
            stir=None
        else:
            stir=resolved_stir
    else:
        stir_evidence=None
    accounts=[]
    for f in docs['business_plan']+docs['questionnaire']+docs['application']:
        acts=_extract_accounts(f.text)
        if acts:accounts.append((f.path,acts))
    # Example-based evidence: an account in a payment order absent from the
    # applicant's identified declaration is a REVIEW, not a confirmed fault.
    payment_files=[f for f in files if re.search(r'(?:плат[её]ж|тўлов|to.lov|payment|квитанц|toʻlov|tolov)',norm(f.path),re.I)]
    payment_accounts=[(f.path,_extract_accounts(f.text)) for f in payment_files if _extract_accounts(f.text)]
    declared_accounts=set(a for _,vs in accounts for a in vs)
    unlisted=[(p,a) for p,vs in payment_accounts for a in vs if a not in declared_accounts]
    if declared_accounts and unlisted:
        labels='; '.join(f'{os.path.basename(p)}: …{a[-4:]}' for p,a in unlisted[:4])
        _add(issues,issue('payment_account_review','review','To‘lovdagi hisobvaraq rekvizitlarda tekshirilsin',
             'To‘lov faylida topilgan ayrim hisobvaraqlar ariza/anketa/biznes-rejada ajratilgan hisobvaraqlar orasida ko‘rinmadi: '+labels,
             'To‘lovchi kimligini tekshiring; agar hisobvaraq arizachiniki bo‘lsa, rekvizitlarga qo‘shing yoki yopilganligini qayd eting.',
             '', 'Hujjatlararo hisobvaraq mosligi (tasdiqlangan e’tiroz namunasi)','medium'))
    # Distinguish applicant's OKED in core docs; registration API is NOT available.
    oked_claims=[]
    for kind in ('application','questionnaire','business_plan'):
        for f in docs[kind]:
            vals=re.findall(r'(?:(?:ОКЭД|OKED|ОКЕД|OKЭD|IFUT)\b)[^0-9]{0,16}([0-9]{5})(?![0-9])',f.text,re.I)
            if len(set(vals))==1:oked_claims.append((f.path,vals[0]))
    if len({v for _,v in oked_claims})>1:
        summary='; '.join(f'{os.path.basename(p)}: {v}' for p,v in oked_claims[:6])
        _add(issues,issue('oked_documents_review','review','Hujjatlar orasida OKED nomuvofiqligi ehtimoli',summary,
             'Arizachi OKEDini taqqoslang; davlat reyestrida haqiqiy joriy kodini va ustavning ro‘yxatdan o‘tganini tekshiring.',
             '', 'Hujjatlararo OKED mosligi (tasdiqlangan e’tiroz namunasi)','medium'))
    # Bank accounts can legitimately be different, so don't create spurious errors.
    if len(accounts)>1 and len(set(a for _,vs in accounts for a in vs))>1:
        _add(issues,issue('bank_accounts_review','review','Bank hisobvaraqlarini o‘zaro solishtiring','Bir nechta bank hisobvaraqlari aniqlandi; ular turli hisobvaraqlar bo‘lishi mumkin.','Hisobvaraqlar barcha tegishli rekvizitlarda va to‘lovlarda to‘g‘ri aks etganini tekshiring.','', 'Hujjatlararo solishtirish','medium'))
    # Additional audit modules: source-page traceability, finance, eligibility,
    # explicitly staff-approved phrases and optional dated registry snapshots.
    from .auditors import audit as detailed_audit
    detailed=detailed_audit(files,issues)
    detailed['ocr_mode']=ocr_mode
    from .finance_v4 import check as check_finance_v4
    detailed['finance'] = list(detailed.get('finance', [])) + check_finance_v4(files, issues)
    if docs['business_plan'] and not detailed.get('finance'):
        _add(issues,issue('finance_not_checked','review','Moliyaviy jadvallar avtomatik qayta hisoblanmadi',
            'Moliyaviy tengliklar faqat tuzilmasi ishonchli ajratilgan Word jadvalida tekshiriladi. PDF, Excel yoki boshqa tuzilmalardagi raqamlar bo‘yicha xulosa chiqarilmadi.',
            'Hisob-kitoblarni asl biznes-reja va moliyaviy ilovalardan xodim qayta tekshirsin.',
            docs['business_plan'][0].path,'ТРЕБОВАНИЯ К СОДЕРЖАНИЮ БИЗНЕС ПЛАНУ.pdf','medium'))
    # Economic dossier checks: missing evidence, cross-section and operational
    # plausibility. Only supported, concrete clarification requests are issued.
    from .expert_dossier import examine as expert_examine
    detailed['expert_dossier'] = expert_examine(files, issues, issue, _add)
    from .verification import apply as apply_evidence_gate
    detailed['document_evidence']=apply_evidence_gate(files,issues,detailed,docs)
    from .v4_assessment import assess
    # Evidence gate must set f.quality before coverage is assessed.
    automation=assess(files, issues, detailed, docs)
    # Optional local semantic cross-check: do not convert suggestions to proven errors.
    from .local_semantic import review_local
    automation['semantic']=review_local(files, issues)
    step(92,'Rasmiy bandlar va moliyaviy jadvallar tekshirilmoqda')
    # Staff checklist is separate from actual file-specific findings.
    staff_checks=[
      'Ariza, anketa va biznes-rejaning tirik imzo/muhrini ko‘z bilan tekshirish',
      'Ta’sis shartnomasi ta’sischilar soni birdan ortiq bo‘lsa, litsenziya mavjud yoki faoliyat uchun zarur bo‘lsa, vakansiya ro‘yxati mavjud bo‘lsa talab etiladi',
      'STIR, OKED, direktor va ustavning amaldagi ro‘yxatdan o‘tgan holatini rasmiy davlat reyestrida tasdiqlash',
      'Biznes-rejaning IT-faoliyatga mosligi, moliyaviy prognozlar va talab etilgan tushum ulushini ekspert baholash',
      'Elektron fayllardan aniqlab bo‘lmaydigan sahifalar, tasdiqlash va ilovalarni tekshirish',
    ]
    step(96,'Natija va qayta tekshiruv uchun ma’lumotlar tayyorlanmoqda')
    errors=sum(x['level']=='error' for x in issues)
    reviews=sum(x['level']=='review' for x in issues)
    unreadable_core=any(f.extraction!='ok' for k in ('application','business_plan','questionnaire') for f in docs[k])
    high_priority_review=any(x['id'] in ('mismatch_stir','oked_documents_review','payment_account_review','business_unreadable') or x['id'].startswith(('structure_','finance_','registry_snapshot_','oked_scope_','staff_rule_')) for x in issues)
    # Green means *no specific finding is outstanding*, even a review finding.
    # Staff checks still apply; no automated conclusion is a residence decision.
    status='needs_fix' if errors else ('manual_review' if reviews else 'staff_review')
    from .report_language import detect_dossier
    language, language_evidence=detect_dossier(files)
    # Never equate readable text with a completed mandatory document.
    from .document_validation import assess_file
    for f in files:
        f.validation=assess_file(f, issues, detailed)
    passed_files=sum(f.validation=='validated' for f in files)
    return {'automation':automation,'detailed':detailed,'company_name':company,'company_identity':company_evidence,'language':language,'language_evidence':language_evidence,'stir':stir,'stir_evidence':stir_evidence,'status':status,'errors':errors,'reviews':reviews,'issues':issues,
            'passed_files':passed_files,'count_definition':'Faqat hujjat turi uchun belgilangan dalilli lokal tekshiruvdan o‘tganlar; qolganlari tekshiruvdan o‘tgan deb sanalmaydi.',
            'documents':[f.to_public() for f in files], 'files_count':len(members),'unsupported_count':sum(f.extraction=='unsupported' for f in files),
            'checksum':hashlib.sha256(raw).hexdigest(), 'content_fingerprint':hashlib.sha256(b''.join(sorted(content_hashes))).hexdigest(), 'checked_items':len(DOC_KINDS)+len(BPLAN_SECTIONS),
            'engine':'cyberpark-evidence-v6.4-stress', 'staff_checks':staff_checks, 'note':'Avtomatik texnik tekshiruv. O‘qilmagan yoki manbasiz bandlar avtomatik tasdiqlanmaydi; yakuniy rezidentlik qarori emas.'}
