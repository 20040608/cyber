"""Per-Windows-user CCVibe credentials, opt-in only; no secrets in installer."""
from __future__ import annotations
import os
from pathlib import Path
from threading import RLock
from .privacy import _dpapi
from .store import DATA_DIR

LOCK = RLock()
SECRET_FILE = DATA_DIR / 'ccvibe.key.dpapi'
consent = False
verified = False
style = 'bearer'

def has_key():
    return SECRET_FILE.is_file()

def read_key():
    if not has_key(): return ''
    return _dpapi(SECRET_FILE.read_bytes(), False).decode('utf-8')

def save_key(value):
    global verified, consent
    value = value.strip()
    if not value or len(value) > 8192 or '\n' in value or '\r' in value:
        raise ValueError('API kaliti bitta qatorda bo‘lishi kerak.')
    if os.name != 'nt':
        raise RuntimeError('Kalitni saqlash Windows DPAPI talab qiladi.')
    with LOCK:
        SECRET_FILE.parent.mkdir(parents=True, exist_ok=True)
        import tempfile
        with tempfile.NamedTemporaryFile(dir=SECRET_FILE.parent, delete=False) as f:
            name = Path(f.name)
            f.write(_dpapi(value.encode('utf-8'), True))
        try: name.replace(SECRET_FILE)
        finally: name.unlink(missing_ok=True)
        verified = False
        consent = False
        configure()

def configure():
    enabled = bool(consent and verified and has_key())
    os.environ['CYBERPARK_ENABLE_REMOTE_AI'] = '1' if enabled else '0'
    os.environ['CYBERPARK_ALLOW_SANITIZED_CONTENT'] = '1' if enabled else '0'
    if enabled:
        os.environ['ANTHROPIC_AUTH_TOKEN'] = read_key()
        os.environ['ANTHROPIC_BASE_URL'] = 'https://cc-vibe.com'
        os.environ['ANTHROPIC_MODEL'] = 'claude-sonnet-4-6'
        os.environ['CYBERPARK_API_PROTOCOL'] = 'anthropic'
        os.environ['CYBERPARK_CCVIBE_AUTH_STYLE'] = style
    else:
        os.environ.pop('ANTHROPIC_AUTH_TOKEN', None)

def disconnect():
    global verified, consent
    with LOCK:
        verified = consent = False
        configure()

def snapshot():
    with LOCK:
        return {'configured': has_key(), 'verified': verified,
                'consent': consent, 'enabled': bool(consent and verified and has_key())}

def probe():
    global verified, style, consent
    from .ccvibe_probe import check_connection
    with LOCK:
        consent = verified = False
        configure()
        key = read_key()
    ok, desc, auth = check_connection(key=key, model='claude-sonnet-4-6')
    with LOCK:
        verified, style = ok, auth or 'bearer'
        consent = False
        configure()
    return {'ok': ok, 'message': desc}

def set_consent(allow):
    global consent
    with LOCK:
        if allow and not verified:
            raise ValueError('Avval API ulanishini tekshiring.')
        consent = bool(allow)
        configure()
        return snapshot()
