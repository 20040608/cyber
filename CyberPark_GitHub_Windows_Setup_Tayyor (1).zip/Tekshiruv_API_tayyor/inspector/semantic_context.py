"""Privacy-first, content-based review helpers.

Never serializes file names, financial tables, identifiers, scan images, source
ZIPs or the original business plan to a remote model.  The only remote-eligible
payload is a bounded set of *non-identifying business-plan narrative excerpts*.
Even these excerpts may reveal proprietary ideas: explicit operator opt-in
remains mandatory and no anonymity guarantee is made.
"""
from __future__ import annotations
import re
from typing import Iterable

# A line containing one of these identifying or financial cues is excluded
# rather than pseudonymized and risking accidental disclosure.
IDENTIFIERS = re.compile(
    r'(?:\b(?:passport|pasport|паспорт|pinfl|пинфл|jshshir|жшшир|inn|инн|'
    r'stir|стир|bank|банк|hisob(?:varaq)?|сч[её]т|telefon|телефон|'
    r'email|e-mail|manzil|адрес|direktor|директор|mchj|мчж|ооо|'
    r'tashkilot nomi|kompaniya nomi|yuridik manzil|pin|password|пароль|'
    r'secret|token|shartnoma raqami|договор №)\b|'
    r'https?://|www\.|@|\bIBAN\b)', re.I)
TECH = re.compile(r'(?:dastur|dasturiy|platforma|xizmat|loyiha|mahsulot|'
    r'texnologiya|foydalanuvchi|raqamli|bozor|marketing|tizim|servis|'
    r'avtomatlashtirish|daromad|xarajat|ishlab|chiqarish|'
    r'сервис|услуг|разработ|программ|платформ|проект|продукт|цифров|'
    r'система|рынок|маркетинг|финанс|производ|прибыл|расход|автоматиз|'
    r'технолог|mijoz|клиент|raqobat|конкурент|jamoa|команд|sotuv|продаж)',re.I)
ID_SHAPES = re.compile(r'(?:\+?\d[\d\s().-]{6,}|\b\d{5,}\b|'
    r'\b[A-ZА-ЯЁҚҒҲЎ]{2,}(?:[\s\-]+[A-ZА-ЯЁҚҒҲЎ]{2,})+\b|'
    r'\b[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}\b|https?://\S+)',re.U)
SAFE_CHARACTERS = re.compile(r"^[\w\s.,;:!?()«»\-'‘’–—№%/\[\]]+$",re.U)
PROMPT_PATTERN = re.compile(r'(?:ignore (?:all |previous )?instructions|system prompt|'
    r'не выполняй инструк|забудь инструк|инструкция для модели|'
    r'ko.rsatmalarni unut|modelga buyruq)', re.I)
CAMEL_PROPER = re.compile(r'(?<!\w)[A-ZА-ЯЁҚҒҲЎ][a-zа-яёқғҳў]{2,}[A-ZА-ЯЁҚҒҲЎ][A-Za-zА-Яа-яЁёҚқҒғҲҳЎў]*')
LONG_TOKEN = re.compile(r'\b\S{48,}\b')


def eligible_line(raw: str, company_terms: Iterable[str]) -> str:
    line=' '.join(str(raw).strip().split())
    if not 35<=len(line)<=480:return ''
    if IDENTIFIERS.search(line) or ID_SHAPES.search(line) or PROMPT_PATTERN.search(line):return ''
    if re.search(r'\d',line):return ''
    if any(term in line.casefold() for term in company_terms):return ''
    if CAMEL_PROPER.search(line) or LONG_TOKEN.search(line):return ''
    if not SAFE_CHARACTERS.fullmatch(line):return ''
    if re.search(r'(?<!\.)\b[A-ZА-ЯЁҚҒҲЎ]{3,}\b',line):return ''
    return line


def select_anonymized_excerpts(files,company_name='',max_snippets=18,max_total=7400):
    company_terms=[x.casefold() for x in re.findall(r'[\wа-яёқғҳў]{4,}',company_name or '',re.I)]
    candidates=[]
    for f in files:
        if getattr(f,'kind','')!='business_plan' or getattr(f,'extraction','')!='ok':continue
        # Drop unsafe lines completely, so they cannot leak through concatenation.
        pending=[]
        def flush():
            if pending:
                item=' '.join(pending).strip()
                if len(item)>=75 and TECH.search(item):candidates.append(item[:480])
                pending.clear()
        for raw in str(getattr(f,'text','')).splitlines():
            safe=eligible_line(raw,company_terms)
            if not safe:
                flush()
                continue
            if len(safe)>=75:
                flush()
                if TECH.search(safe):candidates.append(safe)
            else:
                if len(' '.join(pending+[safe]))>480:flush()
                pending.append(safe)
        flush()
    # Sample across the full plan instead of only the first few lines.
    # IDs are ephemeral and are not paths/filenames/sheet names.
    if not candidates:return []
    unique=list(dict.fromkeys(candidates))
    if len(unique)>max_snippets:
        indices=sorted({round(i*(len(unique)-1)/(max_snippets-1)) for i in range(max_snippets)})
        unique=[unique[i] for i in indices]
    selected=[]; used=0
    for s in unique:
        if used+len(s)>max_total:break
        selected.append({'id':f'B{len(selected)+1}','text':s})
        used+=len(s)
    return selected


def quote_is_supported(quote, selected):
    """Only exact, sufficiently informative source quotes count as evidence."""
    return (isinstance(quote,str) and 25<=len(quote)<=200 and
            quote in selected and not IDENTIFIERS.search(quote) and
            not ID_SHAPES.search(quote))
