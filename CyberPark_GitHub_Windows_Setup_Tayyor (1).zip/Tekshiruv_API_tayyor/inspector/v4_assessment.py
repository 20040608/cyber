"""Explainable coverage assessment. Never interpret parse success as legal compliance.

This is intentionally separate from legal eligibility. Incomplete source evidence
produces a request for more evidence, not a fabricated objection or green pass.
"""
from __future__ import annotations

CORE=('application','charter','certificate','business_plan','questionnaire','director_order','contract','company_info')


def assess(files, issues, detailed, docs):
    known=[]
    absent=[]
    unverified=[]
    for kind in CORE:
        found=docs.get(kind,[])
        if not found:
            absent.append(kind)
            continue
        if any(f.extraction=='ok' and f.quality=='content_present' for f in found):
            known.append(kind)
        else:
            unverified.append(kind)
    read_ok=sum(f.extraction=='ok' for f in files)
    counted=len(files)
    sections=[s for plan in detailed.get('structure',[]) for s in plan.get('sections',[])]
    with_text=sum(s.get('status') in ('found','text_unverified') for s in sections)
    any_errors=[x for x in issues if x.get('level')=='error']
    unresolved=[x for x in issues if x.get('level')=='review']
    if any_errors:
        result='correction_required'
    elif unresolved or absent or unverified:
        result='additional_evidence_needed'
    else:
        # This is a purely technical screening, never a residency decision.
        result='technical_screen_clean'
    return {
        'result':result,
        'result_label':{'correction_required':'Aniq tuzatish talab etiladi',
                        'additional_evidence_needed':'Qo‘shimcha dalil yoki o‘qiladigan hujjat kerak',
                        'technical_screen_clean':'Avtomatik texnik tekshiruvda signal yo‘q'}[result],
        'verified_document_text_kinds':known,
        'not_identified_kinds':absent,
        'not_readable_kinds':unverified,
        'document_types_with_text':len(known),
        'document_types_expected':len(CORE),
        'files_read':read_ok,
        'files_total':counted,
        'business_plan_sections_with_text':with_text,
        'business_plan_sections_count':len(sections),
        'business_plan_sections_semantically_verified':0,
        'business_plan_sections_status':[
            {'id':x.get('id'),'status':x.get('status'),'source_requirement_page':x.get('source_page'),
             'meaning':'Sarlavha/matn dalili; iqtisodiy mazmun tasdiqlanmagan'} for x in sections],
        'inspection_scope':{'local_documents':'Fayl formati, ajratilgan matn va aniq qoidalardagi tafovut',
                            'external_ai':'Faqat rozilik berilgan anonimlashtirilgan biznes-reja parchalari',
                            'dossier_semantics_complete':False,
                            'registry_checked_live':False},
        'finance_periods_validated':sum(int(x.get('periods_checked',0)) for x in detailed.get('finance',[])),
        'registry_checked_live':False,
        'accuracy_percentage':None,
        'unverified_count':len(unresolved),
        'confirmed_technical_errors':len(any_errors),
        'definition':'Matn o‘qilishi, majburiy maydonlar va haqiqiy iqtisodiy moslik alohida o‘lchanadi. Bu rezidentlik qarori emas.'
    }
