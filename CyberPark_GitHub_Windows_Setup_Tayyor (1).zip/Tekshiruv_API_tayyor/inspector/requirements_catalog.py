"""Human-auditable Cyber Park checks, transcribed from user-supplied 2026 references.

No claims of law/current eligibility: the applicant/staff must verify external status.
Numbers and sections are source-document numbering, not automatically legal mandates.
Older approved business plans may use different structure; their missing headings
are *review* rather than automatic noncompliance.
"""
from __future__ import annotations

BUSINESS_SOURCE = 'ТРЕБОВАНИЯ К СОДЕРЖАНИЮ БИЗНЕС ПЛАНУ.pdf'
BUSINESS_TECH_SOURCE = 'ТРЕБОВАНИЯ К БИЗНЕС ПЛАНУ.pdf'
DOCUMENT_SOURCE = 'ПЕРЕЧЕНЬ ДОКУМЕНТОВ ДЛЯ ЗАЯВКИ.pdf'
ELIGIBILITY_SOURCE = 'ОСНОВНЫЕ ТРЕБОВАНИЯ К РЕЗИДЕНТАМ.pdf'

# id, title in original, source page; source includes more detail than the headings.
BUSINESS_PARTS = [
 ('1.1','Инициатор и суть проекта',2), ('1.2','Основной проект и предпосылки',3),
 ('1.3','Потребители и партнёры',3), ('1.4','Монетизация проекта',3),
 ('1.5','Рынок',3), ('1.6','Сроки запуска и реализации',3),
 ('1.7','Текущий статус проекта',3),('1.8','Стартовая стоимость проекта',3),
 ('1.9','Ожидаемый масштаб проекта',4),
 ('2.1','Регистрационные данные заявителя',4),('2.2','Управленческий персонал',4),
 ('2.3','Банковские реквизиты',5),('2.4','Юридическая информация',5),
 ('2.5','Текущая деятельность предприятия',6),('2.6','Офис и производственные площадки',6),
 ('3.1','Виды деятельности в планируемый период',7),('3.2','Продукты, услуги и технологии',7),
 ('3.3','Права интеллектуальной собственности',8),('3.4','Юридическое оформление сделок',9),
 ('3.5','Сертификация и лицензирование',9),('3.6','Партнёры предприятия',9),
 ('3.7','Воздействие на окружающую среду',9),
 ('4.1','Рынок и потенциальные потребители',10),('4.2','Требования потребителей',10),
 ('4.3','Конкурентоспособность',10),('4.4','Монетизация и способы продаж',10),
 ('4.5','Ценообразование',11),('4.6','План маркетинга',11),
 ('5.1','Прогноз плана производства',11),('5.2','Объёмы производства / услуг',12),
 ('5.3','Прогноз реализации',12),
 ('6.1','Организационная структура',13),('6.2','Команда и кадровый план',13),
 ('6.3','Месторасположение офиса и площадок',14),
 ('7.1','Календарный план',15),('7.2','Капитальные вложения',15),
 ('7.3','Стартовая стоимость',16),('7.4','Операционные затраты',16),
 ('7.4.1','Сырьё и материалы',16),('7.4.2','Другие производственные расходы',16),
 ('7.4.3','Оплата труда',17),('7.4.4','Прочие операционные расходы',17),
 ('7.5','Финансовые расходы',18),('7.6','Налоги',18),
 ('7.7','Полная стоимость',18),('7.8','Источники финансирования',19),
 ('7.9','Прогноз финансовых результатов',19),('7.10','Прогноз движения денежных средств',20),
 ('7.11','Прогнозный баланс',20),('7.12','Анализ рисков',20),
 ('8','Выводы',20),
]

# Fallback for approved older structures; aliases must be specific enough to
# identify a section, not an incidental mention in the text body.
SECTION_ALIASES = {
 '1.1':['инициатор проекта','инициатор и суть','loyiha tashabbuskori','ташаббускор'],
 '1.2':['обоснование проекта','предпосылки проекта','loyiha asoslari'],
 '1.3':['потребители и партнёры','основные потребители','isteʼmolchilar va hamkorlar'],
 '1.4':['монетизация','daromad modeli'],
 '1.5':['рынок','bozor'],
 '1.6':['сроки реализации','сроки запуска','amalga oshirish muddatlari'],
 '1.7':['текущий статус','loyiha holati'],
 '1.8':['стартовая стоимость','бошланғич қиймат','boshlang‘ich qiymat'],
 '1.9':['масштаб проекта','loyiha ko‘lami'],
 '2.1':['регистрационные данные','ro‘yxatdan o‘tish maʼlumotlari'],
 '2.2':['руководство','управленческий персонал','rahbariyat'],
 '2.3':['банковские реквизиты','bank rekvizitlari'],
 '2.4':['юридическая информация','yuridik maʼlumotlar'],
 '2.5':['текущая деятельность','joriy faoliyat'],
 '2.6':['офис и производственные','ofis va ishlab chiqarish'],
 '3.1':['виды деятельности','faoliyat turlari'],
 '3.2':['описание продукта','описание проектной деятельности','mahsulot tavsifi'],
 '3.3':['интеллектуальная собственность','правообладатели','intellektual mulk'],
 '3.4':['юридическое оформление сделок','bitimlar'],
 '3.5':['сертификация','лицензированию','litsenziyalash'],
 '3.6':['партнёры предприятия','korxona hamkorlari'],
 '3.7':['окружающую среду','ekologiya'],
 '4.1':['целевая аудитория','описание рынка','maqsadli auditoriya'],
 '4.2':['требования потребителей','isteʼmolchi talablari'],
 '4.3':['конкуренты','конкурентоспособность','raqobatchilar'],
 '4.4':['каналы продаж','способы продаж','sotuv kanallari'],
 '4.5':['ценовая политика','ценообразование','narx siyosati'],
 '4.6':['маркетинговая стратегия','план маркетинга','marketing rejasi'],
 '5.1':['прогноз производства','ishlab chiqarish prognozi'],
 '5.2':['объемы производства','hajmi'],
 '5.3':['прогноз реализации','прогноз продаж','sotuv prognozi'],
 '6.1':['организационная структура','tashkiliy tuzilma'],
 '6.2':['команда проекта','кадровый план','loyiha jamoasi'],
 '6.3':['месторасположение офиса','ofis joylashuvi'],
 '7.1':['календарный план','график проекта','loyiha jadvali'],
 '7.2':['капитальные вложения','kapital qo‘yilmalar'],
 '7.3':['стартовая стоимость','boshlang‘ich qiymat'],
 '7.4':['операционные затраты','операционные расходы','operatsion xarajatlar'],
 '7.5':['финансовые расходы','moliyaviy xarajatlar'],
 '7.6':['уплачиваемые налоги','налоги','soliqlar'],
 '7.7':['полной стоимости','to‘liq tannarx'],
 '7.8':['источники финансирования','moliyalashtirish manbalari'],
 '7.9':['прогноз финансовых результатов','финансовые результаты','moliyaviy natijalar'],
 '7.10':['прогноз потока денежных средств','движения денежных средств','pul oqimi'],
 '7.11':['балансовый отчёт','balans'],
 '7.12':['анализ рисков','risklar tahlili'],
 '8':['заключение','выводы','xulosa'],
}

# Scope checks separate from scoring: absolute truth depends on records outside ZIP.
STAFF_ELIGIBILITY = [
 ('EL-01','O‘zbekiston hududida ro‘yxatdan o‘tgan yuridik shaxs',ELIGIBILITY_SOURCE,1),
 ('EL-02','Ruxsat etilgan faoliyatlar: 26; 58.2; 62; 63.1; 72.1 yoki 85 (faqat IT/kiberxavfsizlik ta’limi)',ELIGIBILITY_SOURCE,1),
 ('EL-03','Ruxsat etilgan yo‘nalishlar tushumning kamida 50 foizini tashkil etishi',ELIGIBILITY_SOURCE,1),
 ('EL-04','Biznes-reja iqtisodiy asoslanganligi va barcha faoliyatlarni qamrab olishi',ELIGIBILITY_SOURCE,1),
 ('EL-05','Davlat reyestridagi amaldagi OKED, direktor, ustav ro‘yxatdan o‘tgan holati',ELIGIBILITY_SOURCE,1),
 ('EL-06','Tirik imzo, muhr, ta’sischi pasporti va skaner to‘liqligi',DOCUMENT_SOURCE,1),
 ('EL-07','Rasmiy rekvizitlar va to‘lovdagi hisobvaraqning arizachiga tegishliligi',BUSINESS_SOURCE,5),
 ('EL-08','Moliyaviy prognozlarning iqtisodiy realistikligi va amaldagi talablar',BUSINESS_SOURCE,19),
]

DOC_REQUIREMENTS = [
 ('D-01','Ariza: original imzo + muhr + firma blankida',DOCUMENT_SOURCE,1),
 ('D-02','Ustav va ro‘yxat guvohnomasi',DOCUMENT_SOURCE,1),
 ('D-03','Ta’sischilar soni > 1 bo‘lsa ta’sis shartnomasi',DOCUMENT_SOURCE,1),
 ('D-04','Xizmat shartnomasi namunasi yoki ommaviy oferta',DOCUMENT_SOURCE,1),
 ('D-05','Biznes-reja: original imzo va muhr',DOCUMENT_SOURCE,1),
 ('D-06','Litsenziya yoki ruxsatnoma (mavjud bo‘lsa)',DOCUMENT_SOURCE,1),
 ('D-07','Direktor buyrug‘i, direktor va ta’sischi pasport nusxalari',DOCUMENT_SOURCE,1),
 ('D-08','Anketa: imzolangan original va Word fayli',DOCUMENT_SOURCE,1),
 ('D-09','Kompaniya haqida o‘zbek va rus tilida xizmatlar/narxlar',DOCUMENT_SOURCE,1),
 ('D-10','Ijtimoiy tarmoqlar yoki mavjud emas qaydi',DOCUMENT_SOURCE,1),
 ('D-11','1192×226 banner yoki mavjud emas qaydi',DOCUMENT_SOURCE,1),
 ('D-12','SVG/PNG logo yoki mavjud emas qaydi',DOCUMENT_SOURCE,1),
 ('D-13','Vakansiyalar ro‘yxati (mavjud bo‘lsa)',DOCUMENT_SOURCE,1),
]

def catalog():
    return {
      'sources':[DOCUMENT_SOURCE, BUSINESS_SOURCE, BUSINESS_TECH_SOURCE,ELIGIBILITY_SOURCE,'БИЗНЕС ПЛАН ШАБЛОН.pdf','Tasdiqlangan e’tirozning shaxssizlantirilgan namunasi'],
      'documents':[{'id':x,'title':t,'source':s,'page':p} for x,t,s,p in DOC_REQUIREMENTS],
      'business':[{'id':x,'title':t,'source':BUSINESS_SOURCE,'page':p} for x,t,p in BUSINESS_PARTS],
      'staff':[{'id':x,'title':t,'source':s,'page':p} for x,t,s,p in STAFF_ELIGIBILITY],
    }
