"""Evidence-based first-pass workflow; never send conjectures as resident objections.

A machine-readable first-pass 'ready' means only that supported deterministic
checks finished. It is not a residency approval or a substantive assessment.
"""
from __future__ import annotations

from copy import deepcopy

# A source-document-independent model limitation cannot be corrected by an
# applicant. Do not turn these findings into a resident's invented violations.
OPERATOR_ONLY = {
    'semantic_review_required', 'financial_statements_review',
    'finance_not_checked', 'passport_identity_review', 'bank_accounts_review',
    'payment_account_review', 'oked_documents_review', 'registry_not_verified',
    'registry_snapshot_oked', 'director_resolution_review',
    'review_languages', 'questionnaire_word', 'conditional_founder_agreement',
    'conditional_license', 'optional_vacancies', 'title_date', 'finance_currency',
    'business_unreadable', 'unreadable_files', 'unsupported_files',
    'mismatch_stir', 'staff_stir_review', 'staff_stir_conflict',
}
# Claims about missing files are uncertainty when alternative filenames,
# combined PDFs, or previously approved dossiers may contain them.
UNCERTAIN_REVIEW_PREFIXES = (
    'missing_', 'structure_', 'unverified_', 'kind_unverified_',
    'signature_', 'bplan_', 'finance_', 'oked_scope_', 'staff_rule_',
    'empty_social_', 'review_',
)
# Items the local installation/reader must resolve before any auto-ready status.
TECHNICAL_BLOCKERS = {'unreadable_files', 'unsupported_files', 'business_unreadable'}
MANDATORY_EVIDENCE_IDS = {
    'missing_application','missing_charter','missing_certificate',
    'missing_business_plan','missing_questionnaire','missing_director_order',
    'missing_contract','missing_info','questionnaire_word','missing_passport',
    'missing_social','missing_banner','missing_logo','review_languages',
}


def resident_findings(result):
    """Only observed, rule-backed defects, not review/uncertain signals."""
    return [deepcopy(x) for x in result.get('issues',[]) if x.get('level') == 'error' or x.get('resident_actionable')]


def workflow_state(result):
    definitive=resident_findings(result)
    reviews=[x for x in result.get('issues',[]) if x.get('level')=='review']
    blockers=[]
    for x in reviews:
        ident=x.get('id','')
        if ident in MANDATORY_EVIDENCE_IDS or ident in TECHNICAL_BLOCKERS:
            blockers.append({'id':ident,'title':x.get('title',''),'reason':'Hujjat mavjudligi yoki o‘qilishi avtomatik tasdiqlanmadi'})
        elif ident.startswith(('read_','unverified_','kind_unverified_')):
            # This applies only to core files and cannot be silently marked green.
            blockers.append({'id':ident,'title':x.get('title',''),'reason':'Asosiy hujjatdan yetarli dalil ajratilmadi'})
    documents=result.get('documents',[])
    core={'application','charter','certificate','business_plan','questionnaire','director_order','contract','company_info'}
    for f in documents:
        if f.get('type') in core and f.get('extraction')!='ok':
            ident='unreadable:'+str(f.get('name',''))
            if ident not in {x['id'] for x in blockers}:
                blockers.append({'id':ident,'title':f.get('name',''),'reason':'Fayl to‘liq o‘qilmadi'})
    if definitive:
        stage='correction_required'
        label='Aniq kamchilik va asosli aniqlashtirishlar bor — tuzatilgan ZIP qayta topshirilsin'
    elif blockers:
        stage='evidence_incomplete'
        label='Tekshiruv yakunlanmagan — avval hujjat va OCR dalillarini to‘ldirish kerak'
    else:
        stage='ready_for_staff'
        label='Dastlabki avtomatik tekshiruv tugadi — yakuniy ekspertizaga o‘tadi'
    return {
        'stage':stage, 'label':label,
        'resident_objection_count':len(definitive),
        'technical_blockers':blockers,
        'technical_blockers_count':len(blockers),
        'expert_scope_count':max(0,len(reviews)-len({x['id'] for x in blockers if not x['id'].startswith('unreadable:')})),
        'resident_report_policy':'Dalilli kamchiliklar va manbaga bog‘langan aniq to‘ldirish so‘rovlari; texnik/OCR cheklovlari rasmiy e’tiroz emas.',
        'is_residency_approval':False,
    }


def apply_workflow(result):
    result['workflow']=workflow_state(result)
    result['status']={
        'correction_required':'needs_fix',
        'evidence_incomplete':'evidence_incomplete',
        'ready_for_staff':'staff_review',
    }[result['workflow']['stage']]
    result['engine']='rules-v5.1-resident-workflow'
    return result
