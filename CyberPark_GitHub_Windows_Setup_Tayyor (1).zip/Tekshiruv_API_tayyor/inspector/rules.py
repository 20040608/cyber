"""Read-only optional aliases for previously confirmed document names."""
import json
from pathlib import Path
from .store import DATA_DIR,LOCK
from .engine import DOC_KINDS

RULES_PATH=DATA_DIR/'file_aliases.json'
VALID_KINDS={kind for kind,_,_,_ in DOC_KINDS}

def load():
    with LOCK:
        if not RULES_PATH.exists():return {}
        try:
            rules=json.loads(RULES_PATH.read_text(encoding='utf-8'))
            if not isinstance(rules,dict):return {}
            return {k:[str(x) for x in v if isinstance(x,str)] for k,v in rules.items() if k in VALID_KINDS and isinstance(v,list)}
        except (ValueError,OSError):return {}

