"""High-confidence document role detection from parsed CONTENT, not filename.

A document type is assigned here only with strong positive evidence.  Ambiguous
or image-only documents fall back to the existing filename/folder hints, never
receive a fabricated assertion that their content was verified.
"""
from __future__ import annotations
import re
import unicodedata


def n(s):
    s=unicodedata.normalize('NFKC',str(s)).casefold().replace('_',' ')
    return re.sub(r'[^\wа-яёқғҳў]+',' ',s).strip()

TITLES={
 'business_plan': ('бизнес план','business plan','biznes reja','бизнес режа'),
 'questionnaire': ('анкета заявителя','анкета кандидата','anketa','анкета','nomzod anketasi'),
 'application': ('заявление о вступлении','заявление на резидентство',
                 'заявление о регистрации резидента','rezidentlikka ariza',
                 'ariza','заявление'),
 'charter': ('устав общества','устав ооо','устав','ustav','низом'),
 'certificate': ('свидетельство о государственной регистрации',
                 'guvohnoma','давлат рўйхатидан ўтганлик'),
 'director_order': ('приказ о назначении директора','direktorni tayinlash haqida buyruq',
                    'директорни тайинлаш', 'приказ о назначении'),
 'company_info': ('информация о компании','сведения о компании','tashkilot haqida ma lumot',
                  'kompaniya haqida ma lumot'),
 'contract': ('договор об оказании услуг','договор на оказание услуг',
              'xizmat ko rsatish shartnomasi','публичная оферта','ommaviy oferta'),
}


def detect_by_content(text):
    lines=[n(x) for x in str(text).splitlines() if x.strip()][:14]
    # Titles should be on a SHORT standalone line, not a mention halfway
    # through a long description of another document.
    for line in lines[:7]:
        if len(line)>105:continue
        for kind,phrases in TITLES.items():
            for p in phrases:
                key=n(p)
                if line==key or (line.startswith(key+' ') and len(line)-len(key)<=60
                                and not re.search(r'\b(?:mavjud|bor|существует|имеется|представлен|отсутствует)\b',line)):
                    if kind=='application' and key in ('ariza','заявление'):
                        if not any(n(x).startswith(key) for x in lines[:4]):continue
                    return kind
    # Some business plans omit the literal title.  Multiple *distinct* short
    # headings are stronger evidence than a random mention of one term.
    if len(text)>=900:
        groups=(('маркетинг','marketing','bozor'),
                ('финансов','moliyaviy','financial'),
                ('производствен','ishlab chiqarish','production','реализац'),
                ('организацион','tashkiliy','organizational'),
                ('описание проекта','loyiha tavsifi','project description'))
        hits=set()
        for line in lines:
            if len(line)>95:continue
            for i,group in enumerate(groups):
                if any(n(term) in line for term in group):hits.add(i)
        if len(hits)>=4:return 'business_plan'
    return ''
