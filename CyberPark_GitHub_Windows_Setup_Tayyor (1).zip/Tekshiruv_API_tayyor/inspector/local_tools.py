"""Find optional OCR/conversion executables locally, including normal Windows install dirs."""
import os,shutil,subprocess
import importlib.util
from pathlib import Path

def find(name):
 choices={'tesseract':['tesseract.exe'], 'office':['soffice.exe','libreoffice.exe']}
 names=choices.get(name,[])
 for executable in names:
  p=shutil.which(executable) or shutil.which(executable.removesuffix('.exe'))
  if p:return p
 roots=[os.getenv('ProgramFiles'),os.getenv('ProgramFiles(x86)'),os.getenv('LOCALAPPDATA')]
 for root in filter(None,roots):
  for suffix in ({'tesseract':['Tesseract-OCR/tesseract.exe'],
               'office':['LibreOffice/program/soffice.exe']}[name]):
   p=Path(root)/suffix
   if p.is_file():return str(p)
 return None

def diagnostics():
 t=find('tesseract');o=find('office')
 out={'tesseract_installed':bool(t),'libreoffice_installed':bool(o),
      'tesseract_languages':[], 'ocr_required':['uzb','uzb_cyrl','rus','eng'],
      'network_enabled':bool(os.environ.get('CYBERPARK_ENABLE_REMOTE_AI')=='1'),
      'xlrd_available':bool(importlib.util.find_spec('xlrd')),
      'striprtf_available':bool(importlib.util.find_spec('striprtf')),
      'history_encryption':'Windows DPAPI + AES-GCM' if os.name=='nt' else 'AES-GCM local key'}
 if t:
  try:
   p=subprocess.run([t,'--list-langs'],capture_output=True,timeout=5,check=False)
   out['tesseract_languages']=[x for x in p.stdout.decode('utf8',errors='replace').splitlines() if x.strip() and 'available languages' not in x]
  except (OSError,subprocess.TimeoutExpired):pass
 return out
