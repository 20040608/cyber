"""Conservative evidence gate for Cyber Park first-pass checks.

This layer never turns the absence of a *recognized filename* into a proven
legal deficiency. It also refuses to treat a title, a scan, or boilerplate as
proof that a form was completed. Rules remain reviewable by a person.
"""
from __future__ import annotations
import re
import os
import hashlib
from collections import Counter

CORE = ('application','charter','certificate','business_plan','questionnaire','director_order','contract','company_info')


def _words(text):
    return re.findall(r'[\wа-яёқғҳў]{3,}',text.casefold(),flags=re.I)


def quality(f):
    """Reasoned qualitative reading status, not an unvalidated probability."""
    text=f.text.strip()
    if f.extraction != 'ok':
        return 'unverified', 'Matn to‘liq ajratilmadi yoki OCR yetarli emas'
    if f.suffix in ('.png','.jpg','.jpeg','.svg'):
        return 'unverified', 'Rasm mavjud; shaxs/tasdiqlovchi hujjat mazmuni tasdiqlanmagan'
    if f.suffix in ('.docx','.doc') and len(_words(text))<2 and not getattr(f,'has_media',False):
        return 'empty', 'Word faylda mazmunli to‘ldirilgan matn aniqlanmadi'
    if f.suffix == '.pdf' and len(_words(text))<7:
        return 'unverified', 'PDF bo‘sh yoki skaner bo‘lishi mumkin'
    if f.suffix in ('.txt','.csv','.xlsx','.xltx') and len(_words(text))<4:
        return 'unverified', 'Fayldan mazmunli matn ajratilmadi'
    if text and (len(_words(text))<12) and not getattr(f,'has_media',False):
        return 'unverified', 'Matn juda qisqa; haqiqiy to‘ldirilganini tasdiqlab bo‘lmadi'
    return 'content_present', 'Matn olindi; barcha majburiy maydonlar va mazmun tekshiruvdan o‘tgan emas'


def apply(files,issues,detailed,docs):
    from .engine import issue, _add
    evidence=[]
    for f in files:
        state,note=quality(f)
        f.quality=state
        evidence.append({'file':f.path,'kind':f.kind or 'unknown','content_state':state,
                         'note':note,'extraction':f.extraction})
        # Actual blank editable forms are a verified document-level defect.
        if state=='empty' and f.kind in CORE:
            _add(issues,issue('blank_'+f.kind+'_'+hashlib.sha256(f.path.encode()).hexdigest()[:10],
                'error','Bo‘sh Word hujjat aniqlangan',
                f'«{f.kind}» sifatida tanilgan Word fayldan mazmunli maydonlar ajratilmadi. Bu avtomatik to‘ldirilgan deb qabul qilinmaydi.',
                'Asl faylni ko‘ring, to‘ldirilgan variantini yuklang; faqat rasm bo‘lsa xodim tekshirsin.',
                f.path,'Fayl matni va tarkibi tekshiruvi','high'))
        if state=='unverified' and f.kind in CORE and f.suffix in ('.pdf','.docx','.doc','.jpg','.jpeg','.png'):
            _add(issues,issue('unverified_'+f.kind+'_'+hashlib.sha256(f.path.encode()).hexdigest()[:10],
                'review','Hujjatning mazmuni avtomatik tasdiqlanmadi',
                f'«{f.kind}» deb tanilgan faylning majburiy maydonlari mavjudligi tasdiqlanmadi: {note}.',
                'Faylni ochib mazmuni, imzo va talab etilgan maydonlarini qo‘lda tekshiring.',
                f.path,'Fayl mazmuni tekshiruvi','low'))
    # ZIP-only presence check: a missing mandatory document is an actionable
    # package deficiency when every file was classified and no combined/unknown
    # possible source remains. Other routes are outside the checked ZIP.
    core_missing={
        'missing_application','missing_business_plan','missing_questionnaire',
        'missing_charter','missing_certificate','missing_director_order',
        'missing_contract','missing_info',
    }
    possible_combined=any(f.kind in ('', 'other') and
        f.suffix in ('.pdf','.doc','.docx','.rtf') for f in files)
    for it in issues:
        if it.get('id') not in core_missing:continue
        if it['id']=='missing_questionnaire' and ('papka bo‘sh' in it.get('description','') or 'papkasi bo‘sh' in it.get('description','')):
            it['level']='error';it['confidence']='high'
            continue
        if it['id']=='missing_info':
            # Requirement may be met by a bilingual section inside the plan or
            # an accepted company profile, not necessarily a separate file.
            it['level']='review';it['confidence']='low'
            continue
        if possible_combined:
            it['level']='review';it['confidence']='low'
            it['description']+=' Arxivdagi tanilmagan hujjat ichida bo‘lishi mumkin; mavjudligi aniqlanmadi.'
        else:
            it['level']='error';it['confidence']='high'
            it['description']+=' Tekshirilgan ZIP ichida ushbu majburiy turga mos hujjat topilmadi; boshqa kanallar bu tekshiruv doirasida emas.'
            it['solution']='Majburiy hujjatni ushbu ZIPga qo‘shing yoki alohida taqdim etilganini hujjatli tasdiqlang.'
    # Never let a blank/editable questionnaire clear the Word requirement.
    candidate=docs.get('questionnaire',[])
    editable=[f for f in candidate if f.suffix in ('.doc','.docx')]
    if candidate and not any(getattr(f,'quality','unverified')=='content_present' for f in editable):
        if not any(x['id']=='questionnaire_word' for x in issues):
            _add(issues,issue('questionnaire_word','review','Anketaning to‘ldirilgan Word varianti tasdiqlanmadi',
                'ZIP ichida anketa bilan bog‘liq tahrirlanadigan, mazmuni tasdiqlangan Word fayl topilmadi.',
                'Word anketani yoki oldin boshqa kanal bilan topshirilganini xodim tekshirsin.',
                '', 'ПЕРЕЧЕНЬ ДОКУМЕНТОВ ДЛЯ ЗАЯВКИ.pdf — 5-band','low'))
    if docs.get('passport'):
        _add(issues,issue('passport_identity_review','review',
            'Shaxsni tasdiqlovchi hujjat xodim ko‘rigidan o‘tishi kerak',
            'Fayl nomi, surat yoki OCR matni pasportning to‘g‘ri shaxsga tegishli va amal qilishini tasdiqlamaydi.',
            'Asl pasport nusxalarini xavfsiz lokal ko‘ring; direktor va ta’sischi hujjatlarini solishtiring.',
            docs['passport'][0].path,'Shaxsni tasdiqlovchi hujjat','high'))
    # Filename-only matches with content we cannot verify are not proof of compliance.
    for kind in CORE:
        # A file-specific unreadable warning is already actionable; do not create
        # a second generic warning for exactly the same missing evidence.
        already_flagged=any(x.get('id','').startswith('unverified_'+kind+'_') for x in issues)
        if docs.get(kind) and not already_flagged and not any(getattr(f,'quality','unverified')=='content_present' for f in docs[kind]):
            _add(issues,issue('kind_unverified_'+kind,'review',
                f'«{kind}» hujjatining to‘ldirilganligi tasdiqlanmadi',
                'Fayl nomi yoki sarlavha mavjudligi hujjatning talab bo‘yicha to‘ldirilganligini isbotlamaydi.',
                'Hujjatni oching, majburiy maydonlar va ilovalarni shablon bilan solishtiring.',
                docs[kind][0].path,'Mazmuniy tasdiq cheklovi','low'))
    if docs.get('business_plan'):
        _add(issues,issue('semantic_review_required','review',
            'Biznes-rejaning mazmuniy ekspertizasi xodim tomonidan bajariladi',
            'AI’siz tizim bo‘limda matn mavjudligini aniqlashi mumkin, lekin biznes modeli, prognozlar va faoliyatning amaliy mosligini mustaqil tasdiqlay olmaydi.',
            'Biznes-reja mazmuni, ruxsat etilgan faoliyat va moliyaviy dalillarni mas’ul mutaxassis tekshirsin.',
            docs['business_plan'][0].path,'Mazmuniy ekspertiza cheklovi','high'))
    # A business plan outline cannot be represented as completed chapters.
    for obj in detailed.get('structure',[]):
        count=0
        for item in obj['sections']:
            if item['status']=='found':
                item['status']='text_unverified'
                count+=1
        obj['text_evidence']=count
        obj['verified_complete']=0
        obj['found']=0
        obj['meaning']='Text mavjudligi mazmun va talablarga muvofiqlikni tasdiqlamaydi'
    return evidence
