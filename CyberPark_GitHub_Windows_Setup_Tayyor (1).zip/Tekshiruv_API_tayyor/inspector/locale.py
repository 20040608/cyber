"""Fixed report wording in Uzbek Latin/Cyrillic and Russian, source-grounded only."""
from __future__ import annotations
import re
from .report_language import detect_text

TRANSLATIONS={
 'uz_lat':{
  'heading':'Hujjatlar bo‘yicha e’tiroz','files':'Jami fayl','passed':'Texnik tekshiruvdan o‘tgan',
  'defects':'Kamchiliklar','intro':'ZIP hujjatlarini dastlabki tekshirish jarayonida quyidagi aniq kamchiliklar aniqlandi:',
  'file':'Fayl','basis':'Asos','page':'Sahifa','fix':'Bartaraf etish',
  'none':'Avtomatik qoidalar bo‘yicha aniq kamchilik aniqlanmadi.',
  'next':'Keyingi qadam','next_fix':'Ko‘rsatilgan kamchiliklarni tuzating va yangilangan ZIPni qayta tekshiruvga yuklang.',
  'next_no':'Hujjatlar belgilangan tekshiruvlarning qolgan qismi yakunlangach keyingi bosqichga o‘tadi.',
  'warning':'Muhim','disclaimer':'Bu belgilangan qoidalar bo‘yicha avtomatik natija, rezidentlik qarori emas. Tekshirilmagan bandlar tekshiruvdan o‘tgan hisoblanmaydi.',
  'sheet':'Fayllar','col_name':'Fayl nomi','col_kind':'Hujjat turi','col_format':'Format','col_size':'Hajm (bayt)','col_state':'O‘qilish holati','col_chars':'Matn (belgi)',
  'internal':'ICHKI HISOBOT (KOMPANIYAGA YUBORILMASIN) — ',
 },
 'ru':{
  'heading':'Замечания по документам','files':'Всего файлов','passed':'Технически проверено',
  'defects':'Недостатки','intro':'По результатам предварительной проверки ZIP выявлены следующие подтверждённые недостатки:',
  'file':'Файл','basis':'Основание','page':'Страница','fix':'Как исправить',
  'none':'Подтверждённых недостатков автоматические правила не обнаружили.',
  'next':'Следующий шаг','next_fix':'Исправьте указанные недостатки и повторно загрузите обновлённый ZIP.',
  'next_no':'Документы могут перейти на следующий этап после завершения всех необходимых проверок.',
  'warning':'Важно','disclaimer':'Это автоматический результат по заданным правилам, не решение о резидентстве. Непроверенные пункты не считаются успешно пройденными.',
  'sheet':'Файлы','col_name':'Имя файла','col_kind':'Тип документа','col_format':'Формат','col_size':'Размер (байт)','col_state':'Статус чтения','col_chars':'Текст (символов)',
  'internal':'ВНУТРЕННИЙ ЧЕРНОВИК — ',
 },
}

# Only generated phrase text may be converted; identifiers and document
# filenames/paths must retain their original script and exact spelling.
PROTECTED=re.compile(r'(?<!\w)(?:ZIP|DOCX|DOC|PDF|PNG|SVG|Word|Excel|OCR|STIR|OKED|MChJ|XLSX|XLS|CSV)(?!\w)',re.I)


def localize_generated(text, lang, *, preserve=()):
    if lang!='uz_cyrl':return str(text)
    from .report import uz_cyrillic
    raw=str(text)
    # Exact user-supplied names and paths enclosed in guillemets must not be
    # transliterated (even when folder names happen to be in Uzbek Latin).
    quoted=[m.group(0) for m in re.finditer(r'«[^»]+»',raw)
            if any(ch.isdigit() for ch in m.group(0)) or '/' in m.group(0)
            or '.' in m.group(0) or re.search(r'[A-Z]{2,}',m.group(0))]
    reserved=sorted((str(x) for x in list(preserve)+quoted if x),key=len,reverse=True)
    placeholder={}
    def protect(match):
        key=f'§{len(placeholder)}§'
        placeholder[key]=match.group(0)
        return key
    for element in reserved:
        if element in raw:
            raw=raw.replace(element, protect(re.match(r'.+', element, re.S)))  # preserved exactly
    raw=PROTECTED.sub(protect,raw)
    result=uz_cyrillic(raw)
    for key,val in placeholder.items():result=result.replace(key,val)
    return result


def labels(lang):
    if lang=='uz_cyrl':
        return {k:localize_generated(v,'uz_cyrl') for k,v in TRANSLATIONS['uz_lat'].items()}
    return TRANSLATIONS.get(lang,TRANSLATIONS['uz_lat'])


KIND_TRANSLATION={
 'ru':{'application':'Заявление','business_plan':'Бизнес-план','questionnaire':'Анкета','charter':'Устав','certificate':'Свидетельство','director_order':'Назначение директора','company_info':'Информация о компании','contract':'Договор или оферта','other':'Другой документ','banner':'Баннер','logo':'Логотип','financial_statement':'Финансовая отчетность','business_appendix':'Приложение к бизнес-плану','passport':'Копия паспорта'},
 'uz_lat':{'application':'Ariza','business_plan':'Biznes-reja','questionnaire':'Anketa','charter':'Ustav','certificate':'Guvohnoma','director_order':'Direktorni tayinlash','company_info':'Kompaniya ma’lumoti','contract':'Shartnoma yoki oferta','other':'Boshqa hujjat','banner':'Banner','logo':'Logotip','financial_statement':'Moliyaviy hisobot','business_appendix':'Biznes-reja ilovasi','passport':'Pasport nusxasi'}
}
STATES={
 'ru':{'ok':'Текст извлечён','partial':'Прочитано частично','empty':'Пустой документ','unsupported':'Формат не поддерживается','failed':'Ошибка чтения','ocr_skipped':'OCR не выполнено','encrypted':'Защищённый документ'},
 'uz_lat':{'ok':'Matn ajratilgan','partial':'Qisman o‘qilgan','empty':'Bo‘sh hujjat','unsupported':'Format qo‘llanmaydi','failed':'O‘qish xatosi','ocr_skipped':'OCR bajarilmagan','encrypted':'Himoyalangan hujjat'}
}

def file_kind(kind, lang):
    if lang=='uz_cyrl':return localize_generated(KIND_TRANSLATION['uz_lat'].get(kind,kind),lang)
    return KIND_TRANSLATION.get(lang,KIND_TRANSLATION['uz_lat']).get(kind,kind)

def file_status(status, lang):
    if lang=='uz_cyrl':return localize_generated(STATES['uz_lat'].get(status,status),lang)
    return STATES.get(lang,STATES['uz_lat']).get(status,status)
