"""Offline language choice for ZIP contents, never inferred from filenames alone.

The supported applicant-report languages are Uzbek Latin, Uzbek Cyrillic, Russian.
Mixed dossiers choose the prevailing *substantive primary documents*, using
content and an explicit confidence margin.  Original files are never changed.
"""
from __future__ import annotations
import re
import unicodedata

UZ_LAT=set('loyiha korxona daromad moliyaviy reja faoliyat tadbirkorlik xizmat ishchi xarajat kapital investitsiya boshqaruv taqdim etilgan ish o rinlar yangi dasturiy mahsulot maqsad tarmoq tashkiliy amalga oshirish muddati yil bozor kompaniya uchun bilan bo yicha tomonidan hisoblash zarur mavjud aniqlash imkoniyat yilning loyiha doirasida'.split())
UZ_CYRL=set('лойиҳа корхона даромад молиявий режа фаолият тадбиркорлик хизмат ишчи харажат сармоя инвестиция бошқарув тақдим этилган иш ўринлари янги дастурий маҳсулот мақсад тармоқ ташкилий амалга ошириш муддати йил бозор компания учун билан бўйича томонидан ҳисоблаш зарур мавжуд аниқлаш имконият асосида ташкил этилади'.split())
RU=set('бизнес проект компания предприятие предприятия организация организации план финансовый финансовая финансовые расходы выручка прибыль доход деятельность услуг услуги производство разработка рынок анализ основные основная реализовать реализация обеспечение технологии программное программных управление сотрудников сотрудник период затраты оборудования стоимость инвестиции инвестиционных расчеты согласно предусмотрено предусматривается при этом данные предоставляется сведения является состав сумма следующий могут будет для также целью в течение за счет на основании основные требования подтверждение заявитель описание таблица планируется'.split())

_TOKEN=re.compile(r"[A-Za-zА-Яа-яЁёҚқҒғҲҳЎўʼʻ‘’']{2,}")
CYR=re.compile('[а-яёқғҳў]',re.I)
LAT=re.compile('[a-z]',re.I)
# Keep short function words as supporting evidence, not decisive identifiers.
LAT_SHORT={'va','bu','ham','esa','bilan','uchun','emas','bor','yo‘q','yoʻq','yoki'}
CYRL_SHORT={'ва','бу','ҳам','эса','билан','учун','эмас','бор','йўқ','ёки'}
RU_SHORT={'и','не','по','что','из','или','это','для','как','при','от','до','его','их','на','но'}


def _word(t):
    return unicodedata.normalize('NFKC',t).casefold().replace('ʻ', '‘').replace('’','‘')


def scores(text):
    """Evidence counts, not file size or a keyword substring repeated inside a name."""
    words=[_word(w) for w in _TOKEN.findall(str(text or '')[:140000])]
    val={'uz_lat':0,'uz_cyrl':0,'ru':0}
    chars={'uz_lat':0,'uz_cyrl':0,'ru':0}
    for word in words:
        is_cyr=bool(CYR.search(word))
        is_lat=bool(LAT.search(word))
        if is_cyr:
            distinctive=any(ch in word for ch in 'ўқғҳ')
            if distinctive:val['uz_cyrl']+=4
            if word in UZ_CYRL:val['uz_cyrl']+=4
            if word in CYRL_SHORT:val['uz_cyrl']+=1
            if word in RU:val['ru']+=4
            if word in RU_SHORT:val['ru']+=1
            if any(ch in word for ch in 'ыъэё'):val['ru']+=1
            if word.endswith(('ского','ских','ский','ного','ных','ция','ции','тель','ется')):val['ru']+=1
            chars['uz_cyrl']+=1
        elif is_lat:
            if word in UZ_LAT:val['uz_lat']+=4
            if word in LAT_SHORT:val['uz_lat']+=1
            if word.endswith(('ning','lari','ligi','larda','lardan','ningiz','imiz')):val['uz_lat']+=1
            chars['uz_lat']+=1
    return val


def detect_text(text):
    values=scores(text)
    preferred=max(values,key=values.get)
    highest=values[preferred]
    ordered=sorted(values.values(),reverse=True)
    if highest<5:return ('',0.0)
    confidence=(highest-ordered[1])/(highest+ordered[1]+1)
    return preferred,round(confidence,3)


def detect_dossier(files):
    """Return language plus a coarse, auditable basis for this choice.

    Never trust path, filename or a single language word. In mixed folders use
    substantive content of *core* docs (particularly application and plan).
    """
    points={'uz_lat':0.0,'uz_cyrl':0.0,'ru':0.0}
    evidence=[]
    weights={'business_plan':3.0,'application':2.4,'questionnaire':2.0,'company_info':1.5,
             'charter':1.2,'contract':0.9,'director_order':0.9,'certificate':0.8}
    for f in files:
        raw=str(getattr(f,'text','') or '')
        if len(raw.strip())<75:continue
        lang,confidence=detect_text(raw)
        if not lang:continue
        # Reliable core documents outrank incidental annexes or OCR noise;
        # each document casts at most one weighted vote even if very long.
        kind=getattr(f,'kind','')
        weight=weights.get(kind,0.4)
        contribution=weight*(0.3+min(1.,confidence))
        points[lang]+=contribution
        evidence.append((lang,kind,round(contribution,2)))
    if not evidence:return 'uz_lat',{'method':'fallback_no_text','confidence':'low','documents':0}
    ranked=sorted(points.items(),key=lambda p:p[1],reverse=True)
    primary,top=ranked[0]
    runner=ranked[1][1]
    # Ambiguous majority: prefer source business-plan language, not ZIP name.
    if (top-runner)/(top+runner+0.01)<0.12:
        primary_docs=[x for x in evidence if x[1]=='business_plan']
        if primary_docs:primary=max(primary_docs,key=lambda x:x[2])[0]
    margin=(top-runner)/(top+runner+0.01)
    return primary,{'method':'content_weighted','confidence':'high' if margin>=0.30 else 'mixed',
                    'documents':len(evidence), 'detected':{k:sum(1 for e in evidence if e[0]==k) for k in points}}
