"""Local Word objections: Uzbek Latin / Uzbek Cyrillic / Russian, no AI translation."""
from io import BytesIO
import os
import re
from docx import Document
from docx.shared import Cm, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH

from .engine import DOC_INDEX,BPLAN_SECTIONS

RU_KINDS={
 'application':'Заявление','charter':'Устав','certificate':'Свидетельство о регистрации',
 'business_plan':'Бизнес-план','questionnaire':'Анкета кандидата',
 'director_order':'Приказ о назначении директора','contract':'Типовой договор или публичная оферта',
 'company_info':'Информация о компании на узбекском и русском языках',
}
RU_SECTIONS={'1':'Резюме проекта','2':'Информация о компании','3':'Описание проекта','4':'Рынок и маркетинг',
             '5':'Производственный и сбытовой план','6':'Организационный план','7':'Финансовый план','8':'Заключение'}


def ru_issue(x):
    """Deterministic finite vocabulary; do not pretend free-text translation."""
    code=x['id']; name=x.get('file','')
    if code in ('missing_passport','missing_social','missing_banner','missing_logo'):
        special={
         'missing_passport':('Проверить наличие копий паспортов','Копии паспортов могут находиться внутри объединённых PDF-файлов.','Проверить копии паспорта директора и учредителя.'),
         'missing_social':('Не найдены сведения о соцсетях','Не обнаружены ссылки или явное указание об их отсутствии.','Предоставить ссылки или указать «отсутствуют».'),
         'missing_banner':('Не найден баннер','Не выявлен баннер 1192×226 или явное указание об отсутствии.','Приложить баннер либо указать его отсутствие.'),
         'missing_logo':('Не найден логотип','Не найден логотип SVG/PNG или указание об отсутствии.','Приложить логотип либо указать его отсутствие.'),
        }
        if code=='banner_dimensions':
            match=re.search(r'(\d+)×(\d+)',str(x.get('description','')))
            if match:
                return ('Размер баннера не соответствует требованиям',
                        f'Фактический размер: {match.group(1)}×{match.group(2)} пикселей; требуемый размер: 1192×226.',
                        'Предоставьте баннер размером 1192×226 пикселей.')
        return special[code]
    if code.startswith('zero_byte_'):
        return ('Пустой файл (0 байт)',
                'В ZIP обнаружен файл размером 0 байт. В нём отсутствуют данные для проверки.',
                'Если файл необходим — приложите заполненную и открываемую версию; если дубликат — удалите пустой файл из ZIP.')
    if code=='missing_questionnaire' and 'papkasi bo‘sh' in x.get('description',''):
        return ('Не заполнена папка с анкетой кандидата',
                'Папка «5. Belgilangan shakldagi nomzod anketasi» в предоставленном ZIP пуста.',
                'Приложите заполненную анкету по образцу и редактируемую копию Word.')
    if code.startswith('missing_'):
        key=code.removeprefix('missing_')
        title=RU_KINDS.get(key,'Не найден обязательный документ')
        if key=='info':title='Информация об организации на узбекском и русском языках'
        return f'Не найден документ: {title}', 'При автоматической проверке архива соответствующий документ не обнаружен.', 'Приложить документ или уточнить название файла; при сомнении проверить вручную.'
    if code.startswith('bplan_section_'):
        label=RU_SECTIONS.get(code.rsplit('_',1)[-1],'соответствующий раздел')
        return f'Проверить раздел бизнес-плана: {label}', 'Раздел не был уверенно определён по типовым ключевым словам; он может называться иначе.', 'Проверить наличие раздела и соответствие утверждённой форме.'
    if code.startswith('signature_'):
        key=code.split('_',1)[1]
        return f'Проверить подпись и печать: {RU_KINDS.get(key,key)}', 'Автоматически подтвердить подлинность подписи или печати невозможно.', 'Проверить подписанный оригинал вручную.'
    static={
     'conditional_founder_agreement':('Проверить необходимость учредительного договора','При наличии более одного учредителя требуется учредительный договор. Количество учредителей автоматически не подтверждено.','Проверить количество учредителей и запросить договор, если их больше одного.'),
     'conditional_license':('Проверить необходимость лицензии','Лицензия прилагается при наличии / если она необходима для деятельности.','Проверить применимые разрешительные требования.'),
     'review_languages':('Проверить наличие информации на двух языках','Не удалось однозначно подтвердить наличие узбекской и русской версий.','Проверить сведения на обоих языках.'),
     'questionnaire_word':('Отсутствует анкета в формате Word','Согласно перечню анкета представляется также в редактируемом формате Word.','Приложить файл анкеты .doc или .docx.'),
     'banner_dimensions':('Размер баннера не соответствует требованиям','Обнаруженный баннер имеет размер, отличный от 1192×226 пикселей.','Предоставить баннер размером 1192×226 пикселей.'),
     'logo_format':('Неверный формат логотипа','Логотип должен быть представлен в формате SVG либо PNG.','Приложить логотип в SVG/PNG.'),
     'optional_vacancies':('Проверить наличие вакансий','Список вакансий прилагается при их наличии.','Уточнить наличие вакансий и приложить список при необходимости.'),
     'bank_accounts_review':('Проверить банковские реквизиты','Обнаружено несколько расчётных счетов; это не обязательно ошибка.','Убедиться, что все используемые счета корректно отражены в реквизитах.'),
     'payment_account_review':('Сверить платёжный счёт с реквизитами','Счёт, найденный в платёжном документе, не совпал с обнаруженными реквизитами заявителя. Это ещё не подтверждённое нарушение.','Проверить плательщика; если счёт принадлежит заявителю, добавить его или указать закрытие.'),
     'oked_documents_review':('Проверить расхождение ОКЭД','В документах заявителя найдены разные коды ОКЭД; актуальность реестра автоматически не подтверждена.','Сверить код и регистрацию новой редакции устава с официальным реестром.'),
     'unreadable_files':('Не все файлы распознаны полностью','Для некоторых файлов не удалось извлечь весь текст; это ограничение автоматической обработки, а не доказанный недостаток документов.','При необходимости повторить OCR локально.'),
     'unsupported_files':('Некоторые форматы не обработаны','Обнаружены файлы неподдерживаемого формата.','Проверить эти файлы вручную или преобразовать в читаемый формат.'),
     'mismatch_stir':('Возможное расхождение ИНН','В отдельных документах выявлены разные значения ИНН.','Убедиться, что сравниваются ИНН самого заявителя, а не партнёров.'),
     'registry_not_verified':('Сведения государственного реестра не проверены','В этой офлайн-версии отсутствует подключение к государственному реестру.','Проверить актуальность ИНН, ОКЭД и регистрации устава вручную.'),
     'content_not_verified':('Необходима содержательная экспертиза бизнес-плана','Правила без ИИ не проверяют реалистичность финансовых прогнозов и соответствие фактической деятельности критерию 50% выручки.','Передать бизнес-план специалисту для экономической и содержательной проверки.'),
     'bplan_placeholders':('Возможны незаполненные поля бизнес-плана','Обнаружены длинные подчёркивания или многоточия; они не всегда означают пропуск.','Проверить незаполненные поля и дату утверждения.'),
     'bplan_period':('Проверить период планирования','Период планирования не удалось однозначно определить.','Сверить даты и периоды расчётных таблиц.'),
     'business_unreadable':('Текст бизнес-плана не извлечён полностью','Недостаточно текста для проверки разделов.','Использовать OCR либо редактируемый Word-файл.'),
     'missing_passport':('Проверить наличие копий паспортов','Копии паспортов могут находиться внутри объединённых PDF-файлов.','Проверить копии паспорта директора и учредителя.'),
     'missing_social':('Не найдены сведения о соцсетях','Не обнаружены ссылки или явное указание об их отсутствии.','Предоставить ссылки или указать «отсутствуют».'),
     'missing_banner':('Не найден баннер','Не выявлен баннер 1192×226 или явное указание об отсутствии.','Приложить баннер либо указать его отсутствие.'),
     'missing_logo':('Не найден логотип','Не найден логотип SVG/PNG или указание об отсутствии.','Приложить логотип либо указать его отсутствие.'),
    }
    if code in static:return static[code]
    if code.startswith('structure_'):
        numbers=re.findall(r'(?<!\d)(?:[1-8]\.\d+(?:\.\d+)?|8)(?!\d)',x.get('description',''))
        return ('Проверить структуру бизнес-плана: '+RU_SECTIONS.get(code[-1],code[-1]),
                'Не удалось подтвердить наличие и заполнение пунктов по требованиям 2026 года: '+', '.join(numbers)+'. Утверждённый старый образец может отличаться.',
                'Сверить перечисленные пункты с содержанием документа и утвердить вручную, если сведения представлены в другой структуре.')
    if code.startswith('finance_'):
        return ('Возможное арифметическое расхождение в финансовой таблице',
                'При проверке числовых значений одной таблицы выявлено возможное несоответствие (см. период и числовые показатели в оригинале).',
                'Проверить период и единицы измерения; пересчитать соответствующую строку.')
    if code.startswith('oked_scope_'):
        code_value=code.rsplit('_',1)[-1]
        return (f'Проверить допустимый вид деятельности (ОКЭД {code_value})',
                'Соответствие направления Cyber Park нельзя установить только по ОКЭД, в том числе для ИТ-образования (группа 85).',
                'Проверить фактическую деятельность и долю выручки не менее 50%, затем сверить с реестром.')
    if code=='registry_snapshot_oked':
        return ('ОКЭД отличается от значения в импортированном реестровом снимке',
                'Код в документах отличается от значения в предоставленном датированном файле. Это не живой запрос к государственному реестру.',
                'Проверить регистрацию новой редакции устава в официальном реестре.')
    if code=='blank_fields':
        return ('Возможно, часть полей бизнес-плана не заполнена',
                'Найдены строки, похожие на незаполненные шаблонные поля.',
                'Проверить соответствующие страницы в оригинальном документе.')
    if code=='title_date':
        return ('Проверить дату утверждения на титульном листе',
                'Дата на титульном листе не определена автоматически.',
                'Проверить дату и подпись руководителя по оригиналу.')
    if code=='finance_currency':
        return ('Проверить валюту и единицы в финансовых таблицах',
                'В тексте не определена валюта или кратность расчётов.',
                'Проверить валюту и кратность по расчётным таблицам и приложениям.')
    if code=='financial_statements_review':
        return ('Финансовая отчётность требует отдельного сопоставления',
                'Обнаруженные финансовые отчёты не тождественны прогнозным таблицам бизнес-плана.',
                'Сопоставить даты и итоговые показатели с бизнес-планом.')
    if code=='director_resolution_review':
        return ('Проверить документ о назначении директора',
                'Документ о назначении может быть оформлен решением учредителя или приказом.',
                'Проверить смысл документа независимо от его названия.')
    if code.startswith('kind_unverified_') or code.startswith('unverified_'):
        kind=code.split('_',2)[-1]
        return ('Не удалось подтвердить заполненность документа: '+RU_KINDS.get(kind,'соответствующий документ'),
                'Текст документа не извлечён полностью либо обязательные поля не удалось распознать.',
                'Повторить локальное распознавание и сопоставить поля с утверждённым образцом.')
    if code=='semantic_review_required':
        return ('Содержательная экспертиза бизнес-плана не завершена',
                'Наличие разделов ещё не подтверждает экономическую обоснованность и соответствие модели деятельности.',
                'Проанализировать обоснования, расчёты и фактическую деятельность по доступным данным.')
    if code=='finance_not_checked':
        return ('Финансовые таблицы не пересчитаны автоматически',
                'Структуру таблиц не удалось надёжно извлечь для арифметической проверки.',
                'Повторно прочитать исходные таблицы и сверить формулы локально.')
    if code=='passport_identity_review':
        return ('Данные удостоверения личности не подтверждены',
                'Автоматическая обработка не проверяет подлинность паспортных данных.',
                'Проверить документ по разрешённым локальным правилам.')
    if code.startswith('staff_rule_'):
        return ('Проверить дополнительное правило сотрудника',
                'Ключевая фраза не была найдена; возможно, информация сформулирована иначе.',
                'Сверить содержание документа с подтверждённым локальным правилом.')
    if code.startswith('empty_social_'):return ('Пустой файл со сведениями о социальных сетях','Файл обнаружен, но не содержит ссылок или отметки об отсутствии.','Заполнить ссылками либо указать «отсутствуют».')
    if code.startswith('read_') or code.startswith('empty_'):
        return ('Не удалось прочитать документ полностью','Из файла не извлечён пригодный для проверки текст.','Проверить файл вручную или приложить читаемую копию.')
    return ('Дополнительная проверка документа',
            'Автоматическая проверка не смогла подтвердить соответствие данного пункта; это не доказанное нарушение.',
            'Сопоставить относящиеся к пункту документы с действующими правилами.')


def uz_cyrillic(s):
    """Deterministic Uzbek Latin -> Cyrillic for fixed report phrases.

    Cannot disambiguate every foreign proper noun; source filenames stay original.
    """
    multi=[('yo‘','йў'),('yoʻ','йў'),("yo'",'йў'),('g‘','ғ'),('gʻ','ғ'),("g'",'ғ'),('o‘','ў'),('oʻ','ў'),("o'",'ў'),
           ('sh','ш'),('ch','ч'),('yo','ё'),('yu','ю'),('ya','я'),('ng','нг')]
    singles={'a':'а','b':'б','d':'д','e':'е','f':'ф','g':'г','h':'ҳ','i':'и','j':'ж','k':'к','l':'л',
             'm':'м','n':'н','o':'о','p':'п','q':'қ','r':'р','s':'с','t':'т','u':'у','v':'в',
             'x':'х','y':'й','z':'з', '‘':'ъ','ʻ':'ъ', "'":'ъ','’':'ъ'}
    out='';i=0
    while i<len(s):
        found=False
        for pattern,rep in multi:
            chunk=s[i:i+len(pattern)]
            if chunk.casefold()==pattern:
                out+=rep.upper() if chunk[:1].isupper() else rep
                i+=len(pattern);found=True;break
        if found:continue
        x=s[i]
        if x.lower()=='e' and (i==0 or not s[i-1].isalpha() or (i+1<len(s) and s[i+1] in '‘ʻ’\'')):
            ch='э'
        else:ch=singles.get(x.lower(),x)
        out+=ch.upper() if x.isupper() else ch
        i+=1
    return out




def _resident_word(result, strict=False):
    """Applicant-facing Word; language follows substantive ZIP document content.

    Structural source references (original file/path/company) are never
    transliterated. Only explanatory wording is localized.
    """
    from .actionable_report import resident_items, report_overview
    from .locale import labels
    items=resident_items(result)
    data=report_overview(result)
    lang=result.get('language','uz_lat')
    L=labels(lang)
    company=str(result.get('company_name') or 'Korxona')[:110]
    doc=Document()
    sec=doc.sections[0]
    sec.top_margin=Cm(1.55);sec.bottom_margin=Cm(1.55)
    sec.left_margin=Cm(2.3);sec.right_margin=Cm(2.0)
    normal=doc.styles['Normal'];normal.font.name='Times New Roman';normal.font.size=Pt(10.5)
    normal.paragraph_format.space_after=Pt(4)
    title=doc.add_paragraph();title.alignment=WD_ALIGN_PARAGRAPH.CENTER
    heading=(f'{L["heading"]} «{company}»' if lang=='ru' else f'«{company}» {L["heading"]}')
    run=title.add_run(heading);run.bold=True;run.font.size=Pt(13)
    overview=doc.add_paragraph()
    overview.add_run(f'{L["files"]}: {data["files"]}')
    overview.add_run(f'  |  {L["passed"]}: {data["passed"]}')
    overview.add_run(f'  |  {L["defects"]}: {data["defects_count"]}')
    if items:
        intro=('Quyidagi kamchiliklar va asoslangan to‘ldirish talablari aniqlandi:' if lang=='uz_lat' else
               'Қуйидаги камчиликлар ва асосланган тўлдириш талаблари аниқланди:' if lang=='uz_cyrl' else
               'Выявлены следующие недостатки и обоснованные запросы на уточнение:')
        doc.add_paragraph(intro)
        for number,item in enumerate(items,1):
            para=doc.add_paragraph()
            para.add_run(f'{number}. {item["title"]}. ').bold=True
            para.add_run(item['evidence'])
            if item.get('file'):para.add_run(f' {L["file"]}: {item["file"]}.')
            if item.get('source'):para.add_run(f' {L["basis"]}: {item["source"]}.')
            if item.get('source_page'):para.add_run(f' {L["page"]}: {item["source_page"]}.')
            fix=doc.add_paragraph();fix.paragraph_format.left_indent=Cm(.45)
            fix.add_run(f'{L["fix"]}: ').bold=True
            fix.add_run(item['fix'])
    else:
        doc.add_paragraph(L['none'])
    footer=doc.add_paragraph()
    footer.add_run(f'{L["next"]}: ').bold=True
    footer.add_run(L['next_fix'] if items else L['next_no'])
    note=doc.add_paragraph()
    note.add_run(f'{L["warning"]}: ').bold=True
    note.add_run(L['disclaimer'])
    doc.core_properties.author='Cyber Park Document Inspector'
    doc.core_properties.subject=L['heading']
    out=BytesIO();doc.save(out)
    return out.getvalue()

def generate_docx(result,mode="internal"):
    # User-controlled text from archives must not break XML-based Word creation.
    # Preserve readable content; remove only Unicode code points illegal in XML.
    def xmlsafe(v):
        if not isinstance(v,str):return v
        return ''.join(ch for ch in v if (ord(ch) in (9,10,13) or 32<=ord(ch)<=0xD7FF or 0xE000<=ord(ch)<=0xFFFD or 0x10000<=ord(ch)<=0x10FFFF))
    result={**result,'issues':[{k:xmlsafe(v) for k,v in item.items()} for item in result.get('issues',[])]}
    if mode not in ('internal','confirmed','automatic','resident'):raise ValueError('Noto‘g‘ri hisobot rejimi')
    if mode in ('automatic','resident'):
        return _resident_word(result,strict=(mode=='resident'))
    decisions=result.get('issue_decisions',{})
    if mode=='confirmed':
        approved=[]
        for item in result['issues']:
            decision=decisions.get(item['id'],{})
            if decision.get('decision')=='approve':
                approved.append({**item, 'level':'error','staff_note':xmlsafe(decision.get('note',''))})
        if not approved:raise ValueError('Tasdiqlangan e’tiroz yo‘q')
        result={**result,'issues':approved}
    company=xmlsafe(result.get('company_name') or 'Korxona').strip()
    lang=result.get('language','uz_lat')
    ru=lang=='ru';cy=lang=='uz_cyrl'
    from .locale import localize_generated, labels
    tr=(lambda value: localize_generated(value,'uz_cyrl', preserve=[result.get('company_name','')]+[i.get('file','') for i in result.get('issues',[])])) if cy else (lambda value:value)
    def shown_source(value):
        if ru:
            return {'Fayl hajmi: 0 bayt':'Размер файла: 0 байт',
                    'Haqiqiy ilova — moliyaviy hisobot':'Финансовая отчётность — фактическое приложение',
                    'Texnik tekshiruv':'Техническая проверка',
                    'Fayl mazmuni tekshiruvi':'Проверка содержания файла',
                    'Mazmuniy ekspertiza cheklovi':'Ограничение содержательной экспертизы',
                    'Hujjatlararo solishtirish':'Сопоставление документов'}.get(value,value)
        return tr(value) if cy else value
    d=Document();sec=d.sections[0]
    sec.top_margin=Cm(2.1);sec.bottom_margin=Cm(2.1)
    sec.left_margin=Cm(2.6);sec.right_margin=Cm(2.0)
    style=d.styles['Normal'];style.font.name='Times New Roman';style.font.size=Pt(12)
    style.paragraph_format.space_after=Pt(8)
    title=d.add_paragraph();title.alignment=WD_ALIGN_PARAGRAPH.CENTER
    title_text=(f'Замечания по документам «{company}»' if ru else f'«{company}» {tr("bo‘yicha e’tiroz")}')
    if mode=='automatic':
        title_text=(f'Автоматическая проверка документов «{company}»' if ru else f'«{company}» '+tr('bo‘yicha avtomatik tekshiruv natijasi'))
    if mode=='internal':
        title_text=labels(lang)['internal']+title_text
    run=title.add_run(title_text);run.bold=True;run.font.size=Pt(13)
    intro=d.add_paragraph()
    intro.add_run(('Ниже перечислены обнаруженные технические недостатки и отдельно неподтверждённые условия.' if ru else tr('Aniq texnik kamchiliklar va avtomatik tasdiqlanmagan holatlar alohida keltirilgan.')) if mode=='automatic' else (f'В ходе предварительной автоматизированной проверки документов «{company}» обнаружены следующие замечания:' if ru else f'«{company}» {tr("korxonasi hujjatlarini dastlabki avtomatik tekshirish jarayonida quyidagi kamchiliklar aniqlandi:")} '))
    mistakes=[i for i in result['issues'] if i['level']=='error']
    reviews=[i for i in result['issues'] if i['level']=='review']
    if mistakes:
        for n,x in enumerate(mistakes,1):
            p=d.add_paragraph()
            title,description,solution=ru_issue(x) if ru else (x['title'],x['description'],x['solution'])
            p.add_run(f'{n}. {tr(title)}. ').bold=True
            p.add_run(tr(description))
            if x['file']:p.add_run(f' {"Файл" if ru else tr("Fayl")}: {x["file"]}.')
            if x.get('source'):p.add_run(f' {"Основание" if ru else tr("Asos")}: {shown_source(x["source"])}' + (f' ({x["source_page"]}-{ "стр." if ru else tr("sahifa")})' if x.get('source_page') else '') + '.')
            p.add_run(f' {"Устранение" if ru else tr("Bartaraf etish")}: {tr(solution)}')
            if x.get('staff_note'):p.add_run(' | '+('Подтверждение сотрудника' if ru else 'Xodim tasdig‘i')+': '+tr(x['staff_note'][:500]))
    else:d.add_paragraph('Подтверждённых автоматических ошибок не обнаружено; это не означает полного соответствия.' if ru else tr('Aniq avtomatik xatolik aniqlanmadi. Bu barcha talablar to‘liq tekshirilganini yoki rezidentlikka moslikni anglatmaydi.'))
    if reviews:
        d.add_paragraph('Не подтверждено автоматической проверкой:' if ru else tr('Avtomatik tasdiqlanmagan holatlar:')).runs[0].bold=True
        for n,x in enumerate(reviews,1):
            p=d.add_paragraph()
            title,description,solution=ru_issue(x) if ru else (x['title'],x['description'],x['solution'])
            if mode=='automatic' and x.get('id')=='semantic_review_required':
                title='Экономическая обоснованность бизнес-плана не подтверждена автоматикой' if ru else 'Biznes-rejaning iqtisodiy asoslanganligi avtomatik tasdiqlanmadi'
            p.add_run(f'{n}. {tr(title)}. ').bold=True
            if mode=='automatic':
                # Unverified does not imply an objection; keep it brief.
                if x['file']:p.add_run(f' {"Файл" if ru else tr("Fayl")}: {os.path.basename(x["file"])}.')
                if x.get('source_page'):p.add_run(f' {"Требование, стр." if ru else tr("Manba sahifasi")}: {x["source_page"]}.')
            else:
                p.add_run(tr(description)[:250])
                if x['file']:p.add_run(f' {"Файл" if ru else tr("Fayl")}: {os.path.basename(x["file"])}.')
                if x.get('source'):p.add_run(f' {"Основание" if ru else tr("Asos")}: {shown_source(x["source"])}' + (f' ({x["source_page"]}-{ "стр." if ru else tr("sahifa")})' if x.get('source_page') else '') + '.')
                p.add_run(f' {"Рекомендация" if ru else tr("Tavsiya")}: {tr(solution)[:190]}')
    note=d.add_paragraph()
    note.add_run('Примечание: ' if ru else tr('Izoh: ')).bold=True
    note.add_run('Отчёт создан автоматически по проверяемым правилам. Необработанные пункты не считаются пройденными. Это не решение о резидентстве.' if ru else tr('Hisobot avtomatik yaratilgan. Tekshirilmagan bandlar muvaffaqiyatli o‘tgan hisoblanmaydi. Bu rezidentlik to‘g‘risidagi yakuniy qaror emas.'))
    out=BytesIO();d.save(out);return out.getvalue()
