"""Safe local structured table extraction from XLSX and selected PDF pages.
No spreadsheet formula execution, macros or external links.
"""
import io, re, xml.etree.ElementTree as ET
from zipfile import ZipFile


def _col_index(ref):
    s=re.match('[A-Z]+',ref or '')
    if not s:return None
    n=0
    for ch in s.group():n=n*26+(ord(ch)-64)
    return n-1


def xlsx_tables(data):
    tables=[]
    with ZipFile(io.BytesIO(data)) as z:
        entries=z.infolist()
        if len(entries)>600 or sum(i.file_size for i in entries)>90*1024*1024:
            return []
        strings=[]
        if 'xl/sharedStrings.xml' in z.namelist():
            root=ET.fromstring(z.read('xl/sharedStrings.xml'))
            strings=[''.join(e.text or '' for e in si.iter() if e.tag.endswith('}t')) for si in root]
        for name in sorted(z.namelist()):
            if not re.fullmatch(r'xl/worksheets/sheet\d+\.xml',name):continue
            root=ET.fromstring(z.read(name));table=[]
            for row in root.iter():
                if not row.tag.endswith('}row'):continue
                cells=[]
                for c in row:
                    if not c.tag.endswith('}c'):continue
                    idx=_col_index(c.attrib.get('r',''))
                    if idx is None or idx>40:continue
                    v=''
                    for el in c:
                        if el.tag.endswith('}v'):v=el.text or ''
                        elif el.tag.endswith('}is'):v=''.join(t.text or '' for t in el.iter() if t.tag.endswith('}t'))
                    if c.attrib.get('t')=='s' and v.isdigit() and int(v)<len(strings):v=strings[int(v)]
                    while len(cells)<=idx:cells.append('')
                    cells[idx]=v[:180]
                if cells:table.append(cells[:40])
                if len(table)>=350:break
            if table:tables.append(table)
            if len(tables)>=30:break
    return tables


def pdf_tables(data, max_pages=12):
    try:
        import pymupdf as fitz
    except ImportError:
        try: import fitz
        except ImportError: return []
    try:
        # Optional layout package is not required; no advisory in worker stdout.
        if hasattr(fitz,'no_recommend_layout'):fitz.no_recommend_layout()
        d=fitz.open(stream=data,filetype='pdf')
        if d.needs_pass:return []
        tables=[]
        for i in range(min(max_pages,len(d))):
            if len(tables)>=30:break
            page=d[i]
            try:found=page.find_tables()
            except (AttributeError,ValueError):continue
            for t in found.tables[:8]:
                rows=t.extract() or []
                if 2<=len(rows)<=350:
                    tables.append([[(cell or '')[:180] for cell in row[:40]] for row in rows])
                if len(tables)>=30:break
        return tables
    except Exception:return []
