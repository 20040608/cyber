"""Auditable financial identities within a single applicant table.

No formula execution, tax assumptions, predictive economic judgment, or
cross-period reconciliation unless the matching row labels are unambiguous.
"""
import re
from collections import defaultdict
from .engine import norm,issue,_add


def number(value):
    v=str(value or '').strip().replace('\u00a0',' ').replace('−','-').replace('–','-')
    if not v or v in ('-','—','–'):return None
    negative=False
    if v.startswith('(') and v.endswith(')'):
        negative=True;v=v[1:-1].strip()
        if v.startswith(('+','-')):return None
    if '%' in v or re.search(r'\b(?:год|year)\b',v,re.I):return None
    if not re.fullmatch(r'[+-]?(?:\d[\d\s.,]*)',v):return None
    # A space-separated number must use real 3-digit thousand groups.
    # Otherwise '1 2 3' was silently converted into 123.
    if ' ' in v:
        candidate=v.lstrip('+-')
        if not re.fullmatch(r'\d{1,3}(?: \d{3})+(?:[.,]\d+)?',candidate):
            return None
    v=v.replace(' ','')
    # Repeated separators are valid only as properly grouped thousands.
    for mark in (',','.'):
        if v.count(mark)>1:
            groups=v.lstrip('+-').split(mark)
            if not (1<=len(groups[0])<=3 and all(len(g)==3 for g in groups[1:])):return None
    if v.count(',') and v.count('.'):
        decimal=',' if v.rfind(',')>v.rfind('.') else '.'
        thousand='.' if decimal==',' else ','
        v=v.replace(thousand,'').replace(decimal,'.')
    elif ',' in v:
        if v.count(',')>1 or len(v.rsplit(',',1)[1])==3:v=v.replace(',','')
        else:v=v.replace(',','.')
    elif '.' in v and (v.count('.')>1 or len(v.rsplit('.',1)[1])==3):v=v.replace('.','')
    try:return -float(v) if negative else float(v)
    except ValueError:return None


# Multilingual row captions. Exact matching prevents incidental prose matches.
CAPTIONS={
 'revenue': ['выручка','валовая выручка от реализации','чистая выручка от реализации','jami tushum','умумий тушум'],
 'cost':['производственная себестоимость','себестоимость реализованных услуг','tannarx','ишлаб чиқариш таннархи'],
 'gross_profit':['валовая прибыль','yalpi foyda','ялпи фойда'],
 'expense':['расходы периода','итого расходы периода','davr xarajatlari','давр харажатлари'],
 'pretax':['прибыль до налогов и процентов','прибыль до уплаты налогов и процентов','прибыль до выплаты налогов','soliqdan oldingi foyda'],
 'profit':['чистая прибыль','sof foyda','соф фойда'],
 'profit_cumulative':['накопленная чистая прибыль','накопленная прибыль','jamg arilgan foyda'],
 'cash_operating':['операционный денежный поток','operatsion pul oqimi'],
 'cash_capex':['capex','капитальные расходы'],
 'cash_equity':['собственный капитал','xususiy kapital','ўз капитали'],
 'cash_net':['чистый денежный поток','sof pul oqimi'],
 'cash_begin':['остаток денежных средств на начало','davr boshidagi pul qoldig i'],
 'cash_end':['остаток денежных средств на конец','davr oxiridagi pul qoldig i'],
 'net_fixed':['чистые основные активы'],
 'fixed_original':['основные активы и нма первоначально'],
 'depreciation':['накопленная амортизация'],
 'assets':['итого активы'],
 'liabilities':['итого пассивы'],
 'exports':['всего экспорт','экспортдан жами тушум'],
 'local':['всего внутренний рынок','ички бозордан жами тушум'],
}
CAPTION_KEYS={norm(v):k for k,vs in CAPTIONS.items() for v in vs}


def extract_rows(table):
    result={}
    conflicting=set()
    width=0
    for row in table:
        if len(row)<3:continue
        caption=norm(str(row[0]).replace('\n',' '))
        key=CAPTION_KEYS.get(caption)
        if key is None:continue
        values=[number(v) for v in row[1:]]
        if sum(x is not None for x in values)<2:continue
        # Duplicate captions with disagreeing values make that accounting row
        # ambiguous. Never silently choose one and issue a false arithmetic error.
        if key in result:
            previous=result[key]
            overlap=[(a,b) for a,b in zip(previous,values) if a is not None and b is not None]
            if any(abs(a-b)>0.0001 for a,b in overlap):
                conflicting.add(key)
            elif sum(v is not None for v in values)>sum(v is not None for v in previous):
                result[key]=values
        else:
            result[key]=values
        width=max(width,len(values))
    for key in conflicting:
        result.pop(key,None)
    return result,width


def _close(actual,expected):
    return abs(actual-expected)<=max(0.51,abs(expected)*0.001)


CHECKS=[
 ('gross_margin',('revenue','cost','gross_profit'),lambda r:r['revenue']-r['cost']),
 ('operating_margin',('gross_profit','expense','pretax'),lambda r:r['gross_profit']-r['expense']),
 ('fixed_assets',('fixed_original','depreciation','net_fixed'),lambda r:r['fixed_original']-r['depreciation']),
 ('balance',('assets','liabilities'),lambda r:r['assets']),
 ('cash_closing',('cash_begin','cash_net','cash_end'),lambda r:r['cash_begin']+r['cash_net']),
 ('cash_net_from_operating',('cash_operating','cash_capex','cash_equity','cash_net'),lambda r:r['cash_operating']+r['cash_capex']+r['cash_equity']),
]


def check(files,issues):
    diagnostics=[]
    for f in files:
        if f.kind not in ('business_plan','business_appendix'):continue
        for ti,table in enumerate(getattr(f,'tables',[])[:100],1):
            rows,width=extract_rows(table)
            if not rows:continue
            for code,needed,formula in CHECKS:
                if not all(k in rows for k in needed):continue
                tested=0
                for j in range(min(len(rows[k]) for k in needed)):
                    values={k:rows[k][j] for k in needed}
                    if any(v is None for v in values.values()):continue
                    expected=formula(values)
                    actual=values[needed[-1]]
                    tested+=1
                    if not _close(actual,expected):
                        _add(issues,issue(f'finance_v4_{code}_{ti}_{j}_{norm(f.path)[:24]}','error',
                            'Moliyaviy jadvalda arifmetik tafovut aniqlandi',
                            f'Jadval {ti}, ustun {j+2}: hisoblangan {expected:g}, hujjatda {actual:g}. '+
                             'Bu bir jadval va bir xil ustundagi arifmetik tenglik; raqamlar mos kelmayapti. Jadval birligi va davr sarlavhasi boshqa ma’noni anglatishi mumkin.',
                            'Jadvaldagi summa va formulani tekshirib, xato raqamni tuzating yoki turli hisob birligi/davr bo‘lsa uni aniq belgilang.',
                            f.path,'Biznes-reja jadvali — mahalliy arifmetik formula','high'))
                if tested:diagnostics.append({'file':f.path,'table':ti,'formula':code,'periods_checked':tested})
            if 'profit' in rows and 'profit_cumulative' in rows:
                profit=rows['profit']; accum=rows['profit_cumulative']
                tested=0
                for j in range(1,min(len(profit),len(accum))):
                    if any(v is None for v in (accum[j-1],profit[j],accum[j])):continue
                    tested+=1
                    expected=accum[j-1]+profit[j]
                    if not _close(accum[j],expected):
                        _add(issues,issue(f'finance_v4_cumulative_{ti}_{j}_{norm(f.path)[:24]}','error',
                            'Jamg‘arilgan foyda hisobida tafovut',
                            f'Jadval {ti}, ustun {j+2}: oldingi yig‘indi + joriy foyda = {expected:g}, ko‘rsatilgan {accum[j]:g}.',
                            'Oldingi davr va joriy davr summalarini solishtiring.',f.path,
                            'Moliyaviy reja — lokal hisoblash','high'))
                if tested:diagnostics.append({'file':f.path,'table':ti,'formula':'cumulative_profit','periods_checked':tested})
    return diagnostics
