@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  where py >nul 2>nul
  if errorlevel 1 (echo Python 3.12 topilmadi.& exit /b 1)
  py -3.12 -m venv .venv
  if errorlevel 1 (echo Python 3.12 o'rnatilishi kerak.& exit /b 1)
)
".venv\Scripts\python.exe" -m pip install -r requirements.txt "pyinstaller>=6.11,<7" --disable-pip-version-check
if errorlevel 1 exit /b 1
REM onedir is more reliable for webview2 than extracting all components at each run.
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --onedir --windowed --name CyberPark_Tekshiruv --icon "assets\rabbit_icon.ico" --add-data "static;static" --add-data "assets;assets" --collect-all webview --collect-all docx --collect-all pymupdf --collect-all fitz --hidden-import=app --hidden-import=xlrd --hidden-import=striprtf --hidden-import=PIL --hidden-import=cryptography --hidden-import=inspector.ccvibe_probe --hidden-import=uvicorn.protocols.http.h11_impl --hidden-import=uvicorn.lifespan.on --hidden-import=uvicorn.loops.asyncio desktop_webview.py
if errorlevel 1 (echo EXE yig'ishda xato.& exit /b 1)
if not exist "dist\CyberPark_Tekshiruv\CyberPark_Tekshiruv.exe" (echo EXE topilmadi.& exit /b 1)
echo TAYYOR: dist\CyberPark_Tekshiruv\CyberPark_Tekshiruv.exe
exit /b 0
