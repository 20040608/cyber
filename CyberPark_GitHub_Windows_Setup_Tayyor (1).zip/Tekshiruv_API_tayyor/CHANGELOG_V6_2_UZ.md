# Cyber Park Document Inspector v6.2 — o‘zgarishlar

1. Wordning sarlavha, matn va jadvallarini manbadagi navbatda o‘qish.
2. Hujjat vazifasini adashtirmaslik: ta’til arizasi, yetkazib berish/ijara shartnomasi va ishdan bo‘shatish buyrug‘i majburiy rezidentlik hujjati hisoblanmaydi.
3. API kaliti yordamchi OCR/LibreOffice/brauzer jarayonlariga meros bo‘lib o‘tishini bartaraf etish.
4. Bo‘sh faylning o‘lchamini foydalanuvchiga to‘g‘ri ko‘rsatish.
5. 168 ta sintetik va regressiya sinovi; 4 haqiqiy ZIP bilan OCRsiz qayta tekshirish.
6. Tasdiqlangan ikki sahifali dizayn, 3 natija kartasi, Word hisoboti va lokal/CCVibe ulanishi saqlandi.

**Chegara:** mustaqil huquqiy-iqtisodiy ekspertiza va 98% aniqlik tasdiqlanmagan.
