"""Cyber Park Inspector: genuine native Tk Windows desktop application.

No web browser, localhost server, or secret embedded in the distribution.
Remote content review is disabled unless the operator gives explicit per-session consent.
"""
from __future__ import annotations
import os
import queue
import threading
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from inspector.engine import MAX_UPLOAD, analyze_zip
from inspector.report import generate_docx
from inspector.rules import load as load_rules
from inspector.store import init, save, get, list_checks
from inspector.download_naming import report_filename

API_HOST = 'https://cc-vibe.com'
MODEL = 'claude-sonnet-4-6'


def read_key_file(filename: str) -> str:
    """Read only on this machine. Never log/store the key in application settings."""
    if not filename:
        raise ValueError('Avval API kaliti saqlangan TXT faylni tanlang.')
    key = Path(filename).read_text(encoding='utf-8-sig').strip()
    if (not key or '\n' in key or '\r' in key or key == 'KALITNI_SHU_YERGA_YOZING'
            or len(key) > 8192):
        raise ValueError('Kalit TXT faylida bitta qatorda haqiqiy kalit bo‘lishi kerak.')
    return key


def setup_api(key: str, enable_content: bool = False, auth_style: str = 'bearer'):
    os.environ.update({
        'ANTHROPIC_BASE_URL': API_HOST,
        'ANTHROPIC_MODEL': MODEL,
        'ANTHROPIC_AUTH_TOKEN': key,
        'CYBERPARK_API_PROTOCOL': 'anthropic',
        'CYBERPARK_CCVIBE_AUTH_STYLE': auth_style,
        'CYBERPARK_ENABLE_REMOTE_AI': '1' if enable_content else '0',
        'CYBERPARK_ALLOW_SANITIZED_CONTENT': '1' if enable_content else '0',
    })


def disable_api():
    for k in ('ANTHROPIC_AUTH_TOKEN', 'CYBERPARK_ENABLE_REMOTE_AI',
              'CYBERPARK_ALLOW_SANITIZED_CONTENT', 'CYBERPARK_CCVIBE_AUTH_STYLE'):
        os.environ.pop(k, None)


class Desktop(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('Cyber Park — Hujjatlar tekshiruvi')
        self.geometry('960x700')
        self.minsize(760, 560)
        self.configure(bg='#f4f7f9')
        self.events = queue.Queue()
        self.running = False
        self.api_approved = False
        self.api_auth_style = 'bearer'
        self.selected_zip = tk.StringVar()
        self.selected_key = tk.StringVar()
        self.status = tk.StringVar(value='ZIP faylni tanlang. Tekshiruv lokal bajariladi.')
        self.progress_value = tk.IntVar(value=0)
        self.remote_choice = tk.BooleanVar(value=False)
        self.last_id = None
        self._ui()
        self.after(120, self._events)
        self.protocol('WM_DELETE_WINDOW', self._close)

    def _ui(self):
        style = ttk.Style(self)
        if 'clam' in style.theme_names():
            style.theme_use('clam')
        style.configure('TButton', padding=(11, 9), font=('Segoe UI', 10))
        style.configure('TLabel', background='#f4f7f9', font=('Segoe UI', 10))
        style.configure('Title.TLabel', background='#f4f7f9', font=('Segoe UI Semibold', 19))
        style.configure('TProgressbar', thickness=15)
        main = ttk.Frame(self, padding=22)
        main.pack(fill='both', expand=True)
        ttk.Label(main, text='Hujjatlarni tekshirish', style='Title.TLabel').pack(anchor='w', pady=(0, 16))
        file_frame = ttk.LabelFrame(main, text='  Tekshiriladigan arxiv  ', padding=14)
        file_frame.pack(fill='x', pady=(0, 14))
        line = ttk.Frame(file_frame)
        line.pack(fill='x')
        ttk.Entry(line, textvariable=self.selected_zip, state='readonly').pack(side='left', fill='x', expand=True, padx=(0, 10))
        ttk.Button(line, text='ZIP tanlash', command=self._choose_zip).pack(side='right')
        ttk.Label(file_frame, text='Bitta korxonaga tegishli ZIP • maksimal 500 MB').pack(anchor='w', pady=(9, 0))
        controls = ttk.Frame(main)
        controls.pack(fill='x', pady=(0, 13))
        self.start_button = ttk.Button(controls, text='Tekshirishni boshlash', command=self._start)
        self.start_button.pack(side='left')
        self.word_button = ttk.Button(controls, text='Xulosani Word formatida saqlash', state='disabled', command=self._export)
        self.word_button.pack(side='left', padx=12)
        ttk.Progressbar(main, maximum=100, variable=self.progress_value).pack(fill='x', pady=8)
        ttk.Label(main, textvariable=self.status, wraplength=870).pack(anchor='w', pady=(0, 15))
        tabs = ttk.Notebook(main)
        tabs.pack(fill='both', expand=True)
        results = ttk.Frame(tabs, padding=12)
        api = ttk.Frame(tabs, padding=12)
        history = ttk.Frame(tabs, padding=12)
        tabs.add(results, text='Xulosa')
        tabs.add(history, text='API ulanishi')
        tabs.add(api, text='Natijalar tarixi')
        # Result view stays concise; full findings reside in the Word export.
        self.summary = tk.Text(results, height=11, wrap='word', font=('Segoe UI', 11), relief='flat', bg='#ffffff')
        self.summary.pack(fill='both', expand=True)
        self.summary.insert('1.0', 'Tekshiruv boshlanmagan. Natija tayyor bo‘lgach xulosani Word fayliga saqlashingiz mumkin.')
        self.summary.configure(state='disabled')
        self.api_status = tk.StringVar(value='API o‘chiq. Hujjatlar tashqi serverga yuborilmaydi.')
        ttk.Label(history, text='Kalit kompyuteringizdagi TXT fayldan o‘qiladi. Kalitni hech kimga yubormang.', wraplength=800).pack(anchor='w', pady=(0, 13))
        keyrow = ttk.Frame(history)
        keyrow.pack(fill='x', pady=4)
        ttk.Entry(keyrow, textvariable=self.selected_key, state='readonly').pack(side='left', fill='x', expand=True, padx=(0, 10))
        ttk.Button(keyrow, text='Kalit TXT tanlash', command=self._choose_key).pack(side='right')
        ttk.Label(history, text='Manzil: https://cc-vibe.com/v1/messages    Model: claude-sonnet-4-6').pack(anchor='w', pady=8)
        ttk.Button(history, text='API ni sinash (pullik bo‘lishi mumkin)', command=self._probe).pack(anchor='w', pady=(6, 12))
        ttk.Checkbutton(history, text='Filtrlangan biznes-reja parchalarini API ga yuborishga ruxsat beraman',
                        variable=self.remote_choice, command=self._consent).pack(anchor='w')
        ttk.Label(history, textvariable=self.api_status, wraplength=800).pack(anchor='w', pady=(12, 0))
        ttk.Label(history, text='API tekshiruvi va matn yuborish provayderda haq olinishiga olib kelishi mumkin.\n'
                 'Filtrlash to‘liq anonimlik kafolati emas. Ruxsatsiz maxfiy hujjatlarni yubormang.',
                 wraplength=800).pack(anchor='w', pady=(14, 0))
        hline = ttk.Frame(api)
        hline.pack(fill='x', pady=(0, 8))
        ttk.Button(hline, text='Tarixni yangilash', command=self._history).pack(side='left')
        self.history_list = ttk.Treeview(api, columns=('date', 'company', 'files', 'errors'), show='headings', height=11)
        for code, label, width in [('date', 'Sana', 170), ('company', 'Korxona', 350), ('files', 'Fayllar', 85), ('errors', 'Kamchiliklar', 110)]:
            self.history_list.heading(code, text=label)
            self.history_list.column(code, width=width, stretch=(code == 'company'))
        self.history_list.pack(fill='both', expand=True)
        self.history_list.bind('<<TreeviewSelect>>', self._history_pick)
        self._history()

    def _choose_zip(self):
        p = filedialog.askopenfilename(title='ZIP hujjatlar paketini tanlang', filetypes=[('ZIP arxiv', '*.zip')])
        if p: self.selected_zip.set(p)

    def _choose_key(self):
        p = filedialog.askopenfilename(title='API kaliti TXT faylini tanlang', filetypes=[('Matn fayli', '*.txt'), ('Barcha fayllar', '*.*')])
        if p:
            self.selected_key.set(p)
            self.api_status.set('Kalit fayli tanlandi. Kalit hozircha API ga yuborilmagan.')
            self.api_approved = False
            self.remote_choice.set(False)
            disable_api()

    def _probe(self):
        if self.running:
            messagebox.showwarning('Jarayon', 'Hujjat tekshiruvi davom etmoqda.')
            return
        if not messagebox.askyesno('API sinovini tasdiqlash', 'API ga faqat “Reply only OK” sinov xabari yuboriladi. Bu pullik bo‘lishi mumkin. Davom etasizmi?'):
            return
        try:
            key = read_key_file(self.selected_key.get())
        except (OSError, UnicodeError, ValueError) as exc:
            messagebox.showerror('API kaliti', str(exc))
            return
        self.api_status.set('Ulanish tekshirilmoqda...')
        def run():
            from inspector.ccvibe_probe import check_connection
            ok, description, auth = check_connection(key=key, model=MODEL)
            self.events.put(('probe', (ok, description, auth)))
        threading.Thread(target=run, daemon=True).start()

    def _consent(self):
        if self.remote_choice.get():
            if not self.api_approved:
                self.remote_choice.set(False)
                messagebox.showwarning('API', 'Avval «API ni sinash» tugmasi bilan ulanishni tasdiqlang.')
                return
            accept = messagebox.askyesno('Tashqi API uchun rozilik',
               'Faqat filtrlangan biznes-reja parchalari CCVibe API ga uzatilishi mumkin. '
               'Ma’lumotlar tashqi provayderga chiqadi, filtr esa to‘liq anonimlikni kafolatlamaydi. '
               'Har so‘rov pullik bo‘lishi mumkin. Shu sessiyada ruxsat berasizmi?')
            if not accept:
                self.remote_choice.set(False)
        self._configure_remote()

    def _configure_remote(self):
        if self.api_approved:
            try:
                setup_api(read_key_file(self.selected_key.get()), self.remote_choice.get(), self.api_auth_style)
                self.api_status.set('API ulandi. Matn yuborish: ' + ('ruxsat berilgan' if self.remote_choice.get() else 'o‘chirilgan'))
            except (OSError, UnicodeError, ValueError):
                self.remote_choice.set(False)
                self.api_approved = False
                disable_api()
        else:
            disable_api()

    def _start(self):
        if self.running: return
        p = Path(self.selected_zip.get())
        if not p.is_file() or p.suffix.lower() != '.zip':
            messagebox.showerror('ZIP', 'Yaroqli ZIP fayl tanlang.')
            return
        if p.stat().st_size > MAX_UPLOAD:
            messagebox.showerror('ZIP', 'ZIP hajmi 500 MB dan katta.')
            return
        self.running = True
        self.start_button.configure(state='disabled')
        self.word_button.configure(state='disabled')
        self.progress_value.set(2)
        self.status.set('Tekshiruv boshlandi...')
        remote = self.api_approved and self.remote_choice.get()
        self._configure_remote()
        def work():
            try:
                source = []
                def capture(f):
                    if len(source) < 3: source.append(f)
                def progress(pct, step):
                    self.events.put(('progress', (pct, step)))
                result = analyze_zip(p.read_bytes(), p.name, rules=load_rules(),
                                     progress=progress, ocr_mode='full',
                                     ai_capture=capture if remote else None)
                from inspector.remote_reviewer import review_content
                review = {'enabled': False, 'sent': False, 'message': 'API o‘chiq.'}
                if remote:
                    review = review_content(source, result.get('company_name', ''))
                source.clear()
                result.setdefault('automation', {})['external_ai'] = {k:v for k,v in review.items() if k != 'suggestions'}
                result['automation']['external_ai']['dossier_semantics_complete'] = False
                for idx, item in enumerate(review.get('suggestions', [])):
                    result['issues'].append({'id':f'ccvibe_review_{idx}','level':'review', 'confidence':'medium',
                        'title':'API mazmuniy tavsiyasi (tasdiqlanmagan)',
                        'description': item['problem']+' | Dalil: '+item['quote'],
                        'solution': item['suggestion'],'file':'',
                        'source':'Filtrlangan biznes-reja parchasi '+item['snippet_id'],
                        'evidence':item['quote']})
                result['reviews'] = sum(i['level']=='review' for i in result['issues'])
                from inspector.resident_workflow import apply_workflow
                from inspector.actionable_report import report_overview
                result = apply_workflow(result)
                result['automated_explanation'] = report_overview(result)
                import uuid
                check_id = uuid.uuid4().hex
                save(check_id, p.name, result)
                self.events.put(('done', check_id))
            except Exception:
                # Do not display file text or raw provider exceptions in an error dialog.
                self.events.put(('error', 'Tekshiruvda texnik xato. ZIP va OCR imkoniyatlarini tekshiring.'))
        threading.Thread(target=work, daemon=True).start()

    def _events(self):
        try:
            while True:
                action, data = self.events.get_nowait()
                if action == 'progress':
                    pct, step = data
                    self.progress_value.set(max(self.progress_value.get(), min(99, int(pct))))
                    self.status.set(step)
                elif action == 'probe':
                    ok, desc, auth = data
                    self.api_approved = ok
                    self.api_auth_style = auth or 'bearer'
                    self.api_status.set(desc)
                    if ok:
                        self._configure_remote()
                    else:
                        self.remote_choice.set(False)
                        disable_api()
                elif action == 'done':
                    self.running = False
                    self.last_id = data
                    self.progress_value.set(100)
                    self.start_button.configure(state='normal')
                    self.word_button.configure(state='normal')
                    self.status.set('Tekshiruv yakunlandi. Word xulosani saqlashingiz mumkin.')
                    self._show_result(get(data))
                    self._history()
                elif action == 'error':
                    self.running = False
                    self.start_button.configure(state='normal')
                    self.status.set(data)
                    messagebox.showerror('Tekshiruv', data)
        except queue.Empty: pass
        if self.winfo_exists(): self.after(120, self._events)

    def _show_result(self, result):
        if not result: return
        text = (f"Korxona: {result.get('company_name', 'Aniqlanmadi')}\n"
                f"Jami fayl: {result.get('files_count', 0)}\n"
                f"Tekshiruvdan o'tgan: {result.get('passed_files', 0)}\n"
                f"Kamchiliklar: {result.get('errors', 0)}\n"
                f"Qo‘shimcha aniqlashtirishlar: {result.get('reviews', 0)}\n\n"
                'Batafsil dalillar va tuzatish yo‘llari Word hisobotida ko‘rsatiladi.\n'
                'Avtomatik xulosa rasmiy tasdiq hisoblanmaydi.')
        self.summary.configure(state='normal')
        self.summary.delete('1.0', 'end')
        self.summary.insert('1.0', text)
        self.summary.configure(state='disabled')

    def _export(self):
        if not self.last_id: return
        result = get(self.last_id)
        if not result: return
        path = filedialog.asksaveasfilename(title='Word xulosani saqlash',
            initialfile=report_filename(result, 'docx'),
            defaultextension='.docx', filetypes=[('Word hujjati', '*.docx')])
        if not path: return
        try:
            Path(path).write_bytes(generate_docx(result, mode='automatic'))
            messagebox.showinfo('Tayyor', 'Word xulosasi saqlandi.')
        except OSError:
            messagebox.showerror('Xato', 'Word faylini saqlab bo‘lmadi.')

    def _history(self):
        for item in self.history_list.get_children(): self.history_list.delete(item)
        try:
            for item in list_checks(70):
                self.history_list.insert('', 'end', iid=item['id'],
                    values=(item.get('created_at', '')[:19], item.get('company', ''),
                            item.get('files_count', 0), item.get('errors', 0)))
        except Exception:
            pass

    def _history_pick(self, _event):
        selected = self.history_list.selection()
        if not selected or self.running: return
        self.last_id = selected[0]
        self._show_result(get(self.last_id))
        self.word_button.configure(state='normal')

    def _close(self):
        if self.running and not messagebox.askyesno('Chiqish', 'Tekshiruv davom etmoqda. Dasturni yopasizmi?'):
            return
        disable_api()
        self.destroy()


def main():
    init()
    app = Desktop()
    app.mainloop()

if __name__ == '__main__': main()
