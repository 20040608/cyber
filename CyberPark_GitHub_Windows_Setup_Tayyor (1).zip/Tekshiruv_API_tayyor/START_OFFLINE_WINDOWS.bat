@echo off
setlocal
REM Ordinary/Local-AI startup must never contact an external AI provider.
set CYBERPARK_ENABLE_REMOTE_AI=0
set CYBERPARK_ALLOW_SANITIZED_CONTENT=0
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (echo Avval START_WINDOWS.bat orqali kutubxonalarni o'rnating. & pause & exit /b 1)
".venv\Scripts\python.exe" run_local.py
pause
